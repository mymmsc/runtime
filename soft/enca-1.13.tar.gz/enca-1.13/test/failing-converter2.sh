#! /bin/sh
kill -9 $$
