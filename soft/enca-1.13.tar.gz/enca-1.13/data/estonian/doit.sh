#! /bin/bash
../doit.sh iso88594 cp1257 ibm775 iso885913 macce baltic
