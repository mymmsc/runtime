#! /bin/bash
../doit.sh koi8r cp1251 iso88595 ibm866 maccyr
