/*****  THIS IS A GENERATED FILE.  DO NOT TOUCH!  *****/
/* THIS IS A GENERATED TABLE, see data/basetoc.c. */
static const unsigned short int RAW_KOI8R[] = {
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x00 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x08 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x10 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x18 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x20 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x28 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x30 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x38 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x40 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x48 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x50 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x58 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x60 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x68 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x70 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x78 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x80 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x88 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x90 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x98 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xa0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xa8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xb0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xb8 */
   418, 4711,  935,  244, 1917, 5075,    0,  896,  /* 0xc0 */
   597, 3824,  819, 2062, 2651, 1688, 3538, 5972,  /* 0xc8 */
  1529, 1262, 2752, 2929, 3628, 1580,  570, 2406,  /* 0xd0 */
  1202, 1284,  969,  500,    0,    0,  754,    0,  /* 0xd8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xe0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xe8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xf0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char LETTER_KOI8R[] = {
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x00 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x08 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x10 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x18 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x20 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x28 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x30 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x38 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x40 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x48 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x50 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x58 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x60 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x68 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x70 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x78 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x80 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x88 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x90 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x98 */
    0,   0,   0, 255,   0,   0,   0,   0,  /* 0xa0 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0xa8 */
    0,   0,   0, 255,   0,   0,   0,   0,  /* 0xb0 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0xb8 */
    1,   2,   3,   4,   5,   6,   7,   8,  /* 0xc0 */
    9,  10,  11,  12,  13,  14,  15,  16,  /* 0xc8 */
   17,  18,  19,  20,  21,  22,  23,  24,  /* 0xd0 */
   25,  26,  27,  28,  29,  30,  31, 255,  /* 0xd8 */
   32,  33,  34, 255,  35,  36, 255,  37,  /* 0xe0 */
   38,  39,  40,  41,  42,  43,  44,  45,  /* 0xe8 */
   46,  47,  48,  49,  50,  51,  52,  53,  /* 0xf0 */
   54,  55,  56,  57,  58,  59,  60, 255,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char *PAIR_KOI8R[] = {

  (unsigned char*)"\xd0\xd3\xce\xd7\xcf\xc9\xd4\xcb\xc4\xc2\xcd\xf7\xee\xf0\xda\xd2\xf3\xde\xd5\xc7\xef\xeb\xe9\xf4\xcc\xed\xe4\xc5\xe1\xdc\xd1\xf2\xe2\xd6\xc1\xe7\xfa\xf1\xfe\xc8\xf5\xfc\xec\xdb\xe5\xe8\xc6\xf6\xe6\xc3\xfb",  /* FILLCHAR */
  (unsigned char*)".\xd4\xc4\xdd\xc2",  /* 0xc0 */
  (unsigned char*)".\xcc\xd4\xcb\xce\xda\xd3\xcd\xd7\xd2\xc4\xd1\xc5\xc0\xd6\xdb\xc8\xca\xc2\xde\xd0\xc7\xd5\xdd\xc3",  /* 0xc1 */
  (unsigned char*)"\xd9\xcf\xc5\xd2\xd5\xc1\xc9\xcc\xd1.\xce",  /* 0xc2 */
  (unsigned char*)"\xc5\xc9\xc1.\xcf",  /* 0xc3 */
  (unsigned char*)"\xc5\xc1\xcf\xc9\xd5\xce\xd2.\xd7\xd9\xd8\xcc\xd1\xd3\xcb\xc3",  /* 0xc4 */
  (unsigned char*)".\xce\xd2\xcc\xd4\xd3\xcd\xc7\xc4\xca\xcb\xd7\xda\xc2\xde\xc5\xd0\xdb\xd6\xdd\xc8\xc3\xcf",  /* 0xc5 */
  (unsigned char*)"\xcf\xc9",  /* 0xc6 */
  (unsigned char*)"\xcf\xc1\xcc\xd2\xc4\xc9.\xd5\xce\xc5",  /* 0xc7 */
  (unsigned char*)".\xcf\xc1\xc9\xce",  /* 0xc8 */
  (unsigned char*)".\xcc\xd4\xce\xcb\xcd\xd3\xd7\xda\xc5\xc8\xc4\xde\xca\xd1\xd2\xc3\xc7\xc9\xdb\xc2\xcf\xd6\xd0\xc1\xc0",  /* 0xc9 */
  (unsigned char*)".\xd3\xd4\xce\xde\xc4",  /* 0xca */
  (unsigned char*)"\xc1\xcf.\xc9\xd5\xd2\xd4\xcc\xd3\xc5\xce",  /* 0xcb */
  (unsigned char*)".\xc9\xcf\xc1\xc5\xd8\xd3\xd1\xd5\xc0\xd9\xcb\xce\xcc",  /* 0xcc */
  (unsigned char*)".\xcf\xc5\xc1\xc9\xd5\xce\xd9\xd1",  /* 0xcd */
  (unsigned char*)"\xc1\xcf\xc5\xc9.\xd9\xd5\xce\xd1\xd8\xd4\xc4\xd3\xcb\xc3",  /* 0xce */
  (unsigned char*)".\xd7\xd2\xd4\xcc\xd3\xce\xcd\xc4\xc7\xca\xc2\xcb\xd6\xde\xc5\xd0\xda\xdb\xc9\xd1\xc8\xcf\xdd\xc0",  /* 0xcf */
  (unsigned char*)"\xcf\xd2\xc5\xc1\xc9\xcc\xd5\xd9\xd1",  /* 0xd0 */
  (unsigned char*)".\xd4\xcc\xc4\xce\xd3\xcd\xd7\xda\xdd",  /* 0xd1 */
  (unsigned char*)"\xcf\xc1\xc5\xc9\xd5.\xd9\xce\xd1\xd4\xd8\xd7\xcd\xc4\xcb\xd6\xd3\xc0",  /* 0xd2 */
  (unsigned char*)"\xd4\xd1\xcb\xc5.\xd8\xcf\xcc\xc9\xd0\xc1\xce\xd7\xcd\xd3\xd5\xd9\xde",  /* 0xd3 */
  (unsigned char*)"\xcf.\xc1\xc5\xd8\xc9\xd2\xd7\xd9\xd5\xd3\xce\xcb\xd1\xcc",  /* 0xd4 */
  (unsigned char*)".\xcc\xc4\xd4\xd3\xcd\xd6\xc7\xc0\xde\xd2\xcb\xc2\xd0\xdb\xd7\xce\xc8\xda\xdd",  /* 0xd5 */
  (unsigned char*)"\xc5\xc9\xc1\xce\xc4.\xd5",  /* 0xd6 */
  (unsigned char*)"\xc1\xcf.\xc5\xc9\xd9\xd3\xce\xd2\xd5\xcc\xdb\xda\xd4\xc4\xd1\xcb",  /* 0xd7 */
  (unsigned char*)".\xce\xcb\xd3\xdb\xc5\xc0\xd1",  /* 0xd8 */
  (unsigned char*)".\xcc\xca\xc5\xcd\xc8\xd7\xd4\xd3\xdb\xd2\xc2",  /* 0xd9 */
  (unsigned char*)"\xc1\xce.\xc4\xd7\xcf\xc9\xc5\xd5\xd9\xcd\xd2\xd1\xc7\xcc",  /* 0xda */
  (unsigned char*)"\xc5\xc9\xc1\xd8\xcb\xcc\xce\xcf\xd5",  /* 0xdb */
  (unsigned char*)"\xd4",  /* 0xdc */
  (unsigned char*)"\xc5\xc9\xc1",  /* 0xdd */
  (unsigned char*)"\xc5\xd4\xc1\xc9\xce\xd5\xcb.\xd8",  /* 0xde */
  (unsigned char*)".",  /* 0xe0 */
  (unsigned char*)".\xec\xf4\xeb\xee\xfa\xf7\xf3\xed\xf2\xf1\xe4\xce",  /* 0xe1 */
  (unsigned char*)"\xf9\xef\xe5",  /* 0xe2 */
  (unsigned char*)"\xe5\xe1\xef\xc1\xe9\xf5.\xcf\xee",  /* 0xe4 */
  (unsigned char*)".\xf2\xee\xec\xf4\xf3\xed\xe4\xe7\xf7\xea\xe2",  /* 0xe5 */
  (unsigned char*)"\xef\xcf",  /* 0xe7 */
  (unsigned char*)".\xef",  /* 0xe8 */
  (unsigned char*)".\xec\xf4\xee\xf3\xeb\xed\xf7\xe4\xe5\xfa\xfe",  /* 0xe9 */
  (unsigned char*)".",  /* 0xea */
  (unsigned char*)"\xe1\xef.\xe9\xc1\xcf\xf5\xf2",  /* 0xeb */
  (unsigned char*)".\xe9\xef\xe1\xe5\xf8\xf3",  /* 0xec */
  (unsigned char*)".\xc1\xe5\xef\xe1\xe9\xf5\xcf\xee",  /* 0xed */
  (unsigned char*)"\xe5\xe1\xef\xe9\xc5.\xc1\xf9\xf5\xcf\xee\xd5\xf1",  /* 0xee */
  (unsigned char*)".\xf7\xce\xf4\xee\xf3\xec\xf2\xed\xe4\xe7\xea\xe2\xf6\xe5\xeb\xfe\xf0",  /* 0xef */
  (unsigned char*)"\xef\xf2\xcf\xd2\xe5\xc1\xe1",  /* 0xf0 */
  (unsigned char*)".\xf4",  /* 0xf1 */
  (unsigned char*)"\xef\xe1\xe5\xe9\xf5.\xd5\xc1",  /* 0xf2 */
  (unsigned char*)"\xf4.\xf1\xeb\xe5\xf8\xec\xef\xf0\xd4\xe9\xcb",  /* 0xf3 */
  (unsigned char*)"\xef.\xe1\xf8\xe5\xe9\xf2\xcf\xf7\xc1\xf9\xf5",  /* 0xf4 */
  (unsigned char*)".\xe4\xec\xf4",  /* 0xf5 */
  (unsigned char*)"\xe5",  /* 0xf6 */
  (unsigned char*)".\xef\xe1\xe5\xe9\xd9\xf9\xcf\xf3\xc9\xd3\xc1",  /* 0xf7 */
  (unsigned char*)".",  /* 0xf8 */
  (unsigned char*)".\xec\xea",  /* 0xf9 */
  (unsigned char*)"\xe1\xc1\xee.",  /* 0xfa */
  (unsigned char*)"\xe5\xe9",  /* 0xfb */
  (unsigned char*)"\xd4\xf4",  /* 0xfc */
  (unsigned char*)"\xe5",  /* 0xfd */
  (unsigned char*)"\xe5\xf4\xd4\xe1\xe9",  /* 0xfe */
};


/* THIS IS A GENERATED TABLE, see data/basetoc.c. */
static const unsigned short int RAW_CP1251[] = {
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x00 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x08 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x10 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x18 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x20 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x28 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x30 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x38 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x40 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x48 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x50 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x58 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x60 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x68 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x70 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x78 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x80 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x88 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x90 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x98 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xa0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xa8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xb0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xb8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xc0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xc8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xd0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xd8 */
  4711,  935, 2406,  896, 1917, 5075,  570,  969,  /* 0xe0 */
  3824,  819, 2062, 2651, 1688, 3538, 5972, 1529,  /* 0xe8 */
  2752, 2929, 3628, 1580,    0,  597,  244,  754,  /* 0xf0 */
   500,    0,    0, 1284, 1202,    0,  418, 1262,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char LETTER_CP1251[] = {
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x00 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x08 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x10 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x18 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x20 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x28 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x30 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x38 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x40 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x48 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x50 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x58 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x60 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x68 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x70 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x78 */
  255, 255,   0, 255,   0,   0,   0,   0,  /* 0x80 */
    0,   0, 255,   0, 255, 255, 255, 255,  /* 0x88 */
  255,   0,   0,   0,   0,   0,   0,   0,  /* 0x90 */
    0,   0, 255,   0, 255, 255, 255, 255,  /* 0x98 */
    0, 255, 255, 255,   0, 255,   0,   0,  /* 0xa0 */
  255,   0, 255,   0,   0,   0,   0, 255,  /* 0xa8 */
    0,   0, 255, 255, 255,   0,   0,   0,  /* 0xb0 */
  255,   0, 255,   0, 255, 255, 255, 255,  /* 0xb8 */
   33,  34,  53,  37,  35,  36,  52,  56,  /* 0xc0 */
   39,  40,  41,  42,  43,  44,  45,  46,  /* 0xc8 */
   48,  49,  50,  51, 255,  38, 255,  60,  /* 0xd0 */
   57,  59, 255,  55,  54,  58,  32,  47,  /* 0xd8 */
    2,   3,  24,   8,   5,   6,  23,  27,  /* 0xe0 */
   10,  11,  12,  13,  14,  15,  16,  17,  /* 0xe8 */
   19,  20,  21,  22,   7,   9,   4,  31,  /* 0xf0 */
   28,  30, 255,  26,  25,  29,   1,  18,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char *PAIR_CP1251[] = {

  (unsigned char*)"\xef\xf1\xed\xe2\xee\xe8\xf2\xea\xe4\xe1\xec\xc2\xcd\xcf\xe7\xf0\xd1\xf7\xf3\xe3\xce\xca\xc8\xd2\xeb\xcc\xc4\xe5\xc0\xfd\xff\xd0\xc1\xe6\xe0\xc3\xc7\xdf\xd7\xf5\xd3\xdd\xcb\xf8\xc5\xd5\xf4\xc6\xd4\xf6\xd8",  /* FILLCHAR */
  (unsigned char*)".\xf2\xe4\xf9\xe1",  /* 0xfe */
  (unsigned char*)".\xeb\xf2\xea\xed\xe7\xf1\xec\xe2\xf0\xe4\xff\xe5\xfe\xe6\xf8\xf5\xe9\xe1\xf7\xef\xe3\xf3\xf9\xf6",  /* 0xe0 */
  (unsigned char*)"\xfb\xee\xe5\xf0\xf3\xe0\xe8\xeb\xff.\xed",  /* 0xe1 */
  (unsigned char*)"\xe5\xe8\xe0.\xee",  /* 0xf6 */
  (unsigned char*)"\xe5\xe0\xee\xe8\xf3\xed\xf0.\xe2\xfb\xfc\xeb\xff\xf1\xea\xf6",  /* 0xe4 */
  (unsigned char*)".\xed\xf0\xeb\xf2\xf1\xec\xe3\xe4\xe9\xea\xe2\xe7\xe1\xf7\xe5\xef\xf8\xe6\xf9\xf5\xf6\xee",  /* 0xe5 */
  (unsigned char*)"\xee\xe8",  /* 0xf4 */
  (unsigned char*)"\xee\xe0\xeb\xf0\xe4\xe8.\xf3\xed\xe5",  /* 0xe3 */
  (unsigned char*)".\xee\xe0\xe8\xed",  /* 0xf5 */
  (unsigned char*)".\xeb\xf2\xed\xea\xec\xf1\xe2\xe7\xe5\xf5\xe4\xf7\xe9\xff\xf0\xf6\xe3\xe8\xf8\xe1\xee\xe6\xef\xe0\xfe",  /* 0xe8 */
  (unsigned char*)".\xf1\xf2\xed\xf7\xe4",  /* 0xe9 */
  (unsigned char*)"\xe0\xee.\xe8\xf3\xf0\xf2\xeb\xf1\xe5\xed",  /* 0xea */
  (unsigned char*)".\xe8\xee\xe0\xe5\xfc\xf1\xff\xf3\xfe\xfb\xea\xed\xeb",  /* 0xeb */
  (unsigned char*)".\xee\xe5\xe0\xe8\xf3\xed\xfb\xff",  /* 0xec */
  (unsigned char*)"\xe0\xee\xe5\xe8.\xfb\xf3\xed\xff\xfc\xf2\xe4\xf1\xea\xf6",  /* 0xed */
  (unsigned char*)".\xe2\xf0\xf2\xeb\xf1\xed\xec\xe4\xe3\xe9\xe1\xea\xe6\xf7\xe5\xef\xe7\xf8\xe8\xff\xf5\xee\xf9\xfe",  /* 0xee */
  (unsigned char*)"\xee\xf0\xe5\xe0\xe8\xeb\xf3\xfb\xff",  /* 0xef */
  (unsigned char*)".\xf2\xeb\xe4\xed\xf1\xec\xe2\xe7\xf9",  /* 0xff */
  (unsigned char*)"\xee\xe0\xe5\xe8\xf3.\xfb\xed\xff\xf2\xfc\xe2\xec\xe4\xea\xe6\xf1\xfe",  /* 0xf0 */
  (unsigned char*)"\xf2\xff\xea\xe5.\xfc\xee\xeb\xe8\xef\xe0\xed\xe2\xec\xf1\xf3\xfb\xf7",  /* 0xf1 */
  (unsigned char*)"\xee.\xe0\xe5\xfc\xe8\xf0\xe2\xfb\xf3\xf1\xed\xea\xff\xeb",  /* 0xf2 */
  (unsigned char*)".\xeb\xe4\xf2\xf1\xec\xe6\xe3\xfe\xf7\xf0\xea\xe1\xef\xf8\xe2\xed\xf5\xe7\xf9",  /* 0xf3 */
  (unsigned char*)"\xe5\xe8\xe0\xed\xe4.\xf3",  /* 0xe6 */
  (unsigned char*)"\xe0\xee.\xe5\xe8\xfb\xf1\xed\xf0\xf3\xeb\xf8\xe7\xf2\xe4\xff\xea",  /* 0xe2 */
  (unsigned char*)".\xed\xea\xf1\xf8\xe5\xfe\xff",  /* 0xfc */
  (unsigned char*)".\xeb\xe9\xe5\xec\xf5\xe2\xf2\xf1\xf8\xf0\xe1",  /* 0xfb */
  (unsigned char*)"\xe0\xed.\xe4\xe2\xee\xe8\xe5\xf3\xfb\xec\xf0\xff\xe3\xeb",  /* 0xe7 */
  (unsigned char*)"\xe5\xe8\xe0\xfc\xea\xeb\xed\xee\xf3",  /* 0xf8 */
  (unsigned char*)"\xf2",  /* 0xfd */
  (unsigned char*)"\xe5\xe8\xe0",  /* 0xf9 */
  (unsigned char*)"\xe5\xf2\xe0\xe8\xed\xf3\xea.\xfc",  /* 0xf7 */
  (unsigned char*)".",  /* 0xde */
  (unsigned char*)".\xcb\xd2\xca\xcd\xc7\xc2\xd1\xcc\xd0\xdf\xc4\xed",  /* 0xc0 */
  (unsigned char*)"\xdb\xce\xc5",  /* 0xc1 */
  (unsigned char*)"\xc5\xc0\xce\xe0\xc8\xd3.\xee\xcd",  /* 0xc4 */
  (unsigned char*)".\xd0\xcd\xcb\xd2\xd1\xcc\xc4\xc3\xc2\xc9\xc1",  /* 0xc5 */
  (unsigned char*)"\xce\xee",  /* 0xc3 */
  (unsigned char*)".\xce",  /* 0xd5 */
  (unsigned char*)".\xcb\xd2\xcd\xd1\xca\xcc\xc2\xc4\xc5\xc7\xd7",  /* 0xc8 */
  (unsigned char*)".",  /* 0xc9 */
  (unsigned char*)"\xc0\xce.\xc8\xe0\xee\xd3\xd0",  /* 0xca */
  (unsigned char*)".\xc8\xce\xc0\xc5\xdc\xd1",  /* 0xcb */
  (unsigned char*)".\xe0\xc5\xce\xc0\xc8\xd3\xee\xcd",  /* 0xcc */
  (unsigned char*)"\xc5\xc0\xce\xc8\xe5.\xe0\xdb\xd3\xee\xcd\xf3\xdf",  /* 0xcd */
  (unsigned char*)".\xc2\xed\xd2\xcd\xd1\xcb\xd0\xcc\xc4\xc3\xc9\xc1\xc6\xc5\xca\xd7\xcf",  /* 0xce */
  (unsigned char*)"\xce\xd0\xee\xf0\xc5\xe0\xc0",  /* 0xcf */
  (unsigned char*)".\xd2",  /* 0xdf */
  (unsigned char*)"\xce\xc0\xc5\xc8\xd3.\xf3\xe0",  /* 0xd0 */
  (unsigned char*)"\xd2.\xdf\xca\xc5\xdc\xcb\xce\xcf\xf2\xc8\xea",  /* 0xd1 */
  (unsigned char*)"\xce.\xc0\xdc\xc5\xc8\xd0\xee\xc2\xe0\xdb\xd3",  /* 0xd2 */
  (unsigned char*)".\xc4\xcb\xd2",  /* 0xd3 */
  (unsigned char*)"\xc5",  /* 0xc6 */
  (unsigned char*)".\xce\xc0\xc5\xc8\xfb\xdb\xee\xd1\xe8\xf1\xe0",  /* 0xc2 */
  (unsigned char*)".",  /* 0xdc */
  (unsigned char*)".\xcb\xc9",  /* 0xdb */
  (unsigned char*)"\xc0\xe0\xcd.",  /* 0xc7 */
  (unsigned char*)"\xc5\xc8",  /* 0xd8 */
  (unsigned char*)"\xf2\xd2",  /* 0xdd */
  (unsigned char*)"\xc5",  /* 0xd9 */
  (unsigned char*)"\xc5\xd2\xf2\xc0\xc8",  /* 0xd7 */
};


/* THIS IS A GENERATED TABLE, see data/basetoc.c. */
static const unsigned short int RAW_ISO88595[] = {
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x00 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x08 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x10 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x18 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x20 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x28 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x30 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x38 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x40 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x48 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x50 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x58 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x60 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x68 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x70 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x78 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x80 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x88 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x90 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x98 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xa0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xa8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xb0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xb8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xc0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xc8 */
  4711,  935, 2406,  896, 1917, 5075,  570,  969,  /* 0xd0 */
  3824,  819, 2062, 2651, 1688, 3538, 5972, 1529,  /* 0xd8 */
  2752, 2929, 3628, 1580,    0,  597,  244,  754,  /* 0xe0 */
   500,    0,    0, 1284, 1202,    0,  418, 1262,  /* 0xe8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xf0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char LETTER_ISO88595[] = {
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x00 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x08 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x10 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x18 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x20 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x28 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x30 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x38 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x40 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x48 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x50 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x58 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x60 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x68 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x70 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x78 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x80 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x88 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x90 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x98 */
    0, 255, 255, 255, 255, 255, 255, 255,  /* 0xa0 */
  255, 255, 255, 255, 255,   0, 255, 255,  /* 0xa8 */
   33,  34,  53,  37,  35,  36,  52,  56,  /* 0xb0 */
   39,  40,  41,  42,  43,  44,  45,  46,  /* 0xb8 */
   48,  49,  50,  51, 255,  38, 255,  60,  /* 0xc0 */
   57,  59, 255,  55,  54,  58,  32,  47,  /* 0xc8 */
    2,   3,  24,   8,   5,   6,  23,  27,  /* 0xd0 */
   10,  11,  12,  13,  14,  15,  16,  17,  /* 0xd8 */
   19,  20,  21,  22,   7,   9,   4,  31,  /* 0xe0 */
   28,  30, 255,  26,  25,  29,   1,  18,  /* 0xe8 */
    0, 255, 255, 255, 255, 255, 255, 255,  /* 0xf0 */
  255, 255, 255, 255, 255,   0, 255, 255,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char *PAIR_ISO88595[] = {

  (unsigned char*)"\xdf\xe1\xdd\xd2\xde\xd8\xe2\xda\xd4\xd1\xdc\xb2\xbd\xbf\xd7\xe0\xc1\xe7\xe3\xd3\xbe\xba\xb8\xc2\xdb\xbc\xb4\xd5\xb0\xed\xef\xc0\xb1\xd6\xd0\xb3\xb7\xcf\xc7\xe5\xc3\xcd\xbb\xe8\xb5\xc5\xe4\xb6\xc4\xe6\xc8",  /* FILLCHAR */
  (unsigned char*)".\xe2\xd4\xe9\xd1",  /* 0xee */
  (unsigned char*)".\xdb\xe2\xda\xdd\xd7\xe1\xdc\xd2\xe0\xd4\xef\xd5\xee\xd6\xe8\xe5\xd9\xd1\xe7\xdf\xd3\xe3\xe9\xe6",  /* 0xd0 */
  (unsigned char*)"\xeb\xde\xd5\xe0\xe3\xd0\xd8\xdb\xef.\xdd",  /* 0xd1 */
  (unsigned char*)"\xd5\xd8\xd0.\xde",  /* 0xe6 */
  (unsigned char*)"\xd5\xd0\xde\xd8\xe3\xdd\xe0.\xd2\xeb\xec\xdb\xef\xe1\xda\xe6",  /* 0xd4 */
  (unsigned char*)".\xdd\xe0\xdb\xe2\xe1\xdc\xd3\xd4\xd9\xda\xd2\xd7\xd1\xe7\xd5\xdf\xe8\xd6\xe9\xe5\xe6\xde",  /* 0xd5 */
  (unsigned char*)"\xde\xd8",  /* 0xe4 */
  (unsigned char*)"\xde\xd0\xdb\xe0\xd4\xd8.\xe3\xdd\xd5",  /* 0xd3 */
  (unsigned char*)".\xde\xd0\xd8\xdd",  /* 0xe5 */
  (unsigned char*)".\xdb\xe2\xdd\xda\xdc\xe1\xd2\xd7\xd5\xe5\xd4\xe7\xd9\xef\xe0\xe6\xd3\xd8\xe8\xd1\xde\xd6\xdf\xd0\xee",  /* 0xd8 */
  (unsigned char*)".\xe1\xe2\xdd\xe7\xd4",  /* 0xd9 */
  (unsigned char*)"\xd0\xde.\xd8\xe3\xe0\xe2\xdb\xe1\xd5\xdd",  /* 0xda */
  (unsigned char*)".\xd8\xde\xd0\xd5\xec\xe1\xef\xe3\xee\xeb\xda\xdd\xdb",  /* 0xdb */
  (unsigned char*)".\xde\xd5\xd0\xd8\xe3\xdd\xeb\xef",  /* 0xdc */
  (unsigned char*)"\xd0\xde\xd5\xd8.\xeb\xe3\xdd\xef\xec\xe2\xd4\xe1\xda\xe6",  /* 0xdd */
  (unsigned char*)".\xd2\xe0\xe2\xdb\xe1\xdd\xdc\xd4\xd3\xd9\xd1\xda\xd6\xe7\xd5\xdf\xd7\xe8\xd8\xef\xe5\xde\xe9\xee",  /* 0xde */
  (unsigned char*)"\xde\xe0\xd5\xd0\xd8\xdb\xe3\xeb\xef",  /* 0xdf */
  (unsigned char*)".\xe2\xdb\xd4\xdd\xe1\xdc\xd2\xd7\xe9",  /* 0xef */
  (unsigned char*)"\xde\xd0\xd5\xd8\xe3.\xeb\xdd\xef\xe2\xec\xd2\xdc\xd4\xda\xd6\xe1\xee",  /* 0xe0 */
  (unsigned char*)"\xe2\xef\xda\xd5.\xec\xde\xdb\xd8\xdf\xd0\xdd\xd2\xdc\xe1\xe3\xeb\xe7",  /* 0xe1 */
  (unsigned char*)"\xde.\xd0\xd5\xec\xd8\xe0\xd2\xeb\xe3\xe1\xdd\xda\xef\xdb",  /* 0xe2 */
  (unsigned char*)".\xdb\xd4\xe2\xe1\xdc\xd6\xd3\xee\xe7\xe0\xda\xd1\xdf\xe8\xd2\xdd\xe5\xd7\xe9",  /* 0xe3 */
  (unsigned char*)"\xd5\xd8\xd0\xdd\xd4.\xe3",  /* 0xd6 */
  (unsigned char*)"\xd0\xde.\xd5\xd8\xeb\xe1\xdd\xe0\xe3\xdb\xe8\xd7\xe2\xd4\xef\xda",  /* 0xd2 */
  (unsigned char*)".\xdd\xda\xe1\xe8\xd5\xee\xef",  /* 0xec */
  (unsigned char*)".\xdb\xd9\xd5\xdc\xe5\xd2\xe2\xe1\xe8\xe0\xd1",  /* 0xeb */
  (unsigned char*)"\xd0\xdd.\xd4\xd2\xde\xd8\xd5\xe3\xeb\xdc\xe0\xef\xd3\xdb",  /* 0xd7 */
  (unsigned char*)"\xd5\xd8\xd0\xec\xda\xdb\xdd\xde\xe3",  /* 0xe8 */
  (unsigned char*)"\xe2",  /* 0xed */
  (unsigned char*)"\xd5\xd8\xd0",  /* 0xe9 */
  (unsigned char*)"\xd5\xe2\xd0\xd8\xdd\xe3\xda.\xec",  /* 0xe7 */
  (unsigned char*)".",  /* 0xce */
  (unsigned char*)".\xbb\xc2\xba\xbd\xb7\xb2\xc1\xbc\xc0\xcf\xb4\xdd",  /* 0xb0 */
  (unsigned char*)"\xcb\xbe\xb5",  /* 0xb1 */
  (unsigned char*)"\xb5\xb0\xbe\xd0\xb8\xc3.\xde\xbd",  /* 0xb4 */
  (unsigned char*)".\xc0\xbd\xbb\xc2\xc1\xbc\xb4\xb3\xb2\xb9\xb1",  /* 0xb5 */
  (unsigned char*)"\xbe\xde",  /* 0xb3 */
  (unsigned char*)".\xbe",  /* 0xc5 */
  (unsigned char*)".\xbb\xc2\xbd\xc1\xba\xbc\xb2\xb4\xb5\xb7\xc7",  /* 0xb8 */
  (unsigned char*)".",  /* 0xb9 */
  (unsigned char*)"\xb0\xbe.\xb8\xd0\xde\xc3\xc0",  /* 0xba */
  (unsigned char*)".\xb8\xbe\xb0\xb5\xcc\xc1",  /* 0xbb */
  (unsigned char*)".\xd0\xb5\xbe\xb0\xb8\xc3\xde\xbd",  /* 0xbc */
  (unsigned char*)"\xb5\xb0\xbe\xb8\xd5.\xd0\xcb\xc3\xde\xbd\xe3\xcf",  /* 0xbd */
  (unsigned char*)".\xb2\xdd\xc2\xbd\xc1\xbb\xc0\xbc\xb4\xb3\xb9\xb1\xb6\xb5\xba\xc7\xbf",  /* 0xbe */
  (unsigned char*)"\xbe\xc0\xde\xe0\xb5\xd0\xb0",  /* 0xbf */
  (unsigned char*)".\xc2",  /* 0xcf */
  (unsigned char*)"\xbe\xb0\xb5\xb8\xc3.\xe3\xd0",  /* 0xc0 */
  (unsigned char*)"\xc2.\xcf\xba\xb5\xcc\xbb\xbe\xbf\xe2\xb8\xda",  /* 0xc1 */
  (unsigned char*)"\xbe.\xb0\xcc\xb5\xb8\xc0\xde\xb2\xd0\xcb\xc3",  /* 0xc2 */
  (unsigned char*)".\xb4\xbb\xc2",  /* 0xc3 */
  (unsigned char*)"\xb5",  /* 0xb6 */
  (unsigned char*)".\xbe\xb0\xb5\xb8\xeb\xcb\xde\xc1\xd8\xe1\xd0",  /* 0xb2 */
  (unsigned char*)".",  /* 0xcc */
  (unsigned char*)".\xbb\xb9",  /* 0xcb */
  (unsigned char*)"\xb0\xd0\xbd.",  /* 0xb7 */
  (unsigned char*)"\xb5\xb8",  /* 0xc8 */
  (unsigned char*)"\xe2\xc2",  /* 0xcd */
  (unsigned char*)"\xb5",  /* 0xc9 */
  (unsigned char*)"\xb5\xc2\xe2\xb0\xb8",  /* 0xc7 */
};


/* THIS IS A GENERATED TABLE, see data/basetoc.c. */
static const unsigned short int RAW_IBM866[] = {
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x00 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x08 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x10 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x18 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x20 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x28 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x30 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x38 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x40 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x48 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x50 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x58 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x60 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x68 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x70 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x78 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x80 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x88 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x90 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x98 */
  4711,  935, 2406,  896, 1917, 5075,  570,  969,  /* 0xa0 */
  3824,  819, 2062, 2651, 1688, 3538, 5972, 1529,  /* 0xa8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xb0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xb8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xc0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xc8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xd0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xd8 */
  2752, 2929, 3628, 1580,    0,  597,  244,  754,  /* 0xe0 */
   500,    0,    0, 1284, 1202,    0,  418, 1262,  /* 0xe8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xf0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char LETTER_IBM866[] = {
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x00 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x08 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x10 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x18 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x20 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x28 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x30 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x38 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x40 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x48 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x50 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x58 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x60 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x68 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x70 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x78 */
   33,  34,  53,  37,  35,  36,  52,  56,  /* 0x80 */
   39,  40,  41,  42,  43,  44,  45,  46,  /* 0x88 */
   48,  49,  50,  51, 255,  38, 255,  60,  /* 0x90 */
   57,  59, 255,  55,  54,  58,  32,  47,  /* 0x98 */
    2,   3,  24,   8,   5,   6,  23,  27,  /* 0xa0 */
   10,  11,  12,  13,  14,  15,  16,  17,  /* 0xa8 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0xb0 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0xb8 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0xc0 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0xc8 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0xd0 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0xd8 */
   19,  20,  21,  22,   7,   9,   4,  31,  /* 0xe0 */
   28,  30, 255,  26,  25,  29,   1,  18,  /* 0xe8 */
  255, 255, 255, 255, 255, 255, 255, 255,  /* 0xf0 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char *PAIR_IBM866[] = {

  (unsigned char*)"\xaf\xe1\xad\xa2\xae\xa8\xe2\xaa\xa4\xa1\xac\x82\x8d\x8f\xa7\xe0\x91\xe7\xe3\xa3\x8e\x8a\x88\x92\xab\x8c\x84\xa5\x80\xed\xef\x90\x81\xa6\xa0\x83\x87\x9f\x97\xe5\x93\x9d\x8b\xe8\x85\x95\xe4\x86\x94\xe6\x98",  /* FILLCHAR */
  (unsigned char*)".\xe2\xa4\xe9\xa1",  /* 0xee */
  (unsigned char*)".\xab\xe2\xaa\xad\xa7\xe1\xac\xa2\xe0\xa4\xef\xa5\xee\xa6\xe8\xe5\xa9\xa1\xe7\xaf\xa3\xe3\xe9\xe6",  /* 0xa0 */
  (unsigned char*)"\xeb\xae\xa5\xe0\xe3\xa0\xa8\xab\xef.\xad",  /* 0xa1 */
  (unsigned char*)"\xa5\xa8\xa0.\xae",  /* 0xe6 */
  (unsigned char*)"\xa5\xa0\xae\xa8\xe3\xad\xe0.\xa2\xeb\xec\xab\xef\xe1\xaa\xe6",  /* 0xa4 */
  (unsigned char*)".\xad\xe0\xab\xe2\xe1\xac\xa3\xa4\xa9\xaa\xa2\xa7\xa1\xe7\xa5\xaf\xe8\xa6\xe9\xe5\xe6\xae",  /* 0xa5 */
  (unsigned char*)"\xae\xa8",  /* 0xe4 */
  (unsigned char*)"\xae\xa0\xab\xe0\xa4\xa8.\xe3\xad\xa5",  /* 0xa3 */
  (unsigned char*)".\xae\xa0\xa8\xad",  /* 0xe5 */
  (unsigned char*)".\xab\xe2\xad\xaa\xac\xe1\xa2\xa7\xa5\xe5\xa4\xe7\xa9\xef\xe0\xe6\xa3\xa8\xe8\xa1\xae\xa6\xaf\xa0\xee",  /* 0xa8 */
  (unsigned char*)".\xe1\xe2\xad\xe7\xa4",  /* 0xa9 */
  (unsigned char*)"\xa0\xae.\xa8\xe3\xe0\xe2\xab\xe1\xa5\xad",  /* 0xaa */
  (unsigned char*)".\xa8\xae\xa0\xa5\xec\xe1\xef\xe3\xee\xeb\xaa\xad\xab",  /* 0xab */
  (unsigned char*)".\xae\xa5\xa0\xa8\xe3\xad\xeb\xef",  /* 0xac */
  (unsigned char*)"\xa0\xae\xa5\xa8.\xeb\xe3\xad\xef\xec\xe2\xa4\xe1\xaa\xe6",  /* 0xad */
  (unsigned char*)".\xa2\xe0\xe2\xab\xe1\xad\xac\xa4\xa3\xa9\xa1\xaa\xa6\xe7\xa5\xaf\xa7\xe8\xa8\xef\xe5\xae\xe9\xee",  /* 0xae */
  (unsigned char*)"\xae\xe0\xa5\xa0\xa8\xab\xe3\xeb\xef",  /* 0xaf */
  (unsigned char*)".\xe2\xab\xa4\xad\xe1\xac\xa2\xa7\xe9",  /* 0xef */
  (unsigned char*)"\xae\xa0\xa5\xa8\xe3.\xeb\xad\xef\xe2\xec\xa2\xac\xa4\xaa\xa6\xe1\xee",  /* 0xe0 */
  (unsigned char*)"\xe2\xef\xaa\xa5.\xec\xae\xab\xa8\xaf\xa0\xad\xa2\xac\xe1\xe3\xeb\xe7",  /* 0xe1 */
  (unsigned char*)"\xae.\xa0\xa5\xec\xa8\xe0\xa2\xeb\xe3\xe1\xad\xaa\xef\xab",  /* 0xe2 */
  (unsigned char*)".\xab\xa4\xe2\xe1\xac\xa6\xa3\xee\xe7\xe0\xaa\xa1\xaf\xe8\xa2\xad\xe5\xa7\xe9",  /* 0xe3 */
  (unsigned char*)"\xa5\xa8\xa0\xad\xa4.\xe3",  /* 0xa6 */
  (unsigned char*)"\xa0\xae.\xa5\xa8\xeb\xe1\xad\xe0\xe3\xab\xe8\xa7\xe2\xa4\xef\xaa",  /* 0xa2 */
  (unsigned char*)".\xad\xaa\xe1\xe8\xa5\xee\xef",  /* 0xec */
  (unsigned char*)".\xab\xa9\xa5\xac\xe5\xa2\xe2\xe1\xe8\xe0\xa1",  /* 0xeb */
  (unsigned char*)"\xa0\xad.\xa4\xa2\xae\xa8\xa5\xe3\xeb\xac\xe0\xef\xa3\xab",  /* 0xa7 */
  (unsigned char*)"\xa5\xa8\xa0\xec\xaa\xab\xad\xae\xe3",  /* 0xe8 */
  (unsigned char*)"\xe2",  /* 0xed */
  (unsigned char*)"\xa5\xa8\xa0",  /* 0xe9 */
  (unsigned char*)"\xa5\xe2\xa0\xa8\xad\xe3\xaa.\xec",  /* 0xe7 */
  (unsigned char*)".",  /* 0x9e */
  (unsigned char*)".\x8b\x92\x8a\x8d\x87\x82\x91\x8c\x90\x9f\x84\xad",  /* 0x80 */
  (unsigned char*)"\x9b\x8e\x85",  /* 0x81 */
  (unsigned char*)"\x85\x80\x8e\xa0\x88\x93.\xae\x8d",  /* 0x84 */
  (unsigned char*)".\x90\x8d\x8b\x92\x91\x8c\x84\x83\x82\x89\x81",  /* 0x85 */
  (unsigned char*)"\x8e\xae",  /* 0x83 */
  (unsigned char*)".\x8e",  /* 0x95 */
  (unsigned char*)".\x8b\x92\x8d\x91\x8a\x8c\x82\x84\x85\x87\x97",  /* 0x88 */
  (unsigned char*)".",  /* 0x89 */
  (unsigned char*)"\x80\x8e.\x88\xa0\xae\x93\x90",  /* 0x8a */
  (unsigned char*)".\x88\x8e\x80\x85\x9c\x91",  /* 0x8b */
  (unsigned char*)".\xa0\x85\x8e\x80\x88\x93\xae\x8d",  /* 0x8c */
  (unsigned char*)"\x85\x80\x8e\x88\xa5.\xa0\x9b\x93\xae\x8d\xe3\x9f",  /* 0x8d */
  (unsigned char*)".\x82\xad\x92\x8d\x91\x8b\x90\x8c\x84\x83\x89\x81\x86\x85\x8a\x97\x8f",  /* 0x8e */
  (unsigned char*)"\x8e\x90\xae\xe0\x85\xa0\x80",  /* 0x8f */
  (unsigned char*)".\x92",  /* 0x9f */
  (unsigned char*)"\x8e\x80\x85\x88\x93.\xe3\xa0",  /* 0x90 */
  (unsigned char*)"\x92.\x9f\x8a\x85\x9c\x8b\x8e\x8f\xe2\x88\xaa",  /* 0x91 */
  (unsigned char*)"\x8e.\x80\x9c\x85\x88\x90\xae\x82\xa0\x9b\x93",  /* 0x92 */
  (unsigned char*)".\x84\x8b\x92",  /* 0x93 */
  (unsigned char*)"\x85",  /* 0x86 */
  (unsigned char*)".\x8e\x80\x85\x88\xeb\x9b\xae\x91\xa8\xe1\xa0",  /* 0x82 */
  (unsigned char*)".",  /* 0x9c */
  (unsigned char*)".\x8b\x89",  /* 0x9b */
  (unsigned char*)"\x80\xa0\x8d.",  /* 0x87 */
  (unsigned char*)"\x85\x88",  /* 0x98 */
  (unsigned char*)"\xe2\x92",  /* 0x9d */
  (unsigned char*)"\x85",  /* 0x99 */
  (unsigned char*)"\x85\x92\xe2\x80\x88",  /* 0x97 */
};


/* THIS IS A GENERATED TABLE, see data/basetoc.c. */
static const unsigned short int RAW_MACCYR[] = {
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x00 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x08 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x10 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x18 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x20 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x28 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x30 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x38 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x40 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x48 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x50 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x58 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x60 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x68 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x70 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x78 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x80 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x88 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x90 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x98 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xa0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xa8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xb0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xb8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xc0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xc8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xd0 */
     0,    0,    0,    0,    0,    0,    0, 1262,  /* 0xd8 */
  4711,  935, 2406,  896, 1917, 5075,  570,  969,  /* 0xe0 */
  3824,  819, 2062, 2651, 1688, 3538, 5972, 1529,  /* 0xe8 */
  2752, 2929, 3628, 1580,    0,  597,  244,  754,  /* 0xf0 */
   500,    0,    0, 1284, 1202,    0,  418,    0,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char LETTER_MACCYR[] = {
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x00 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x08 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x10 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x18 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x20 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x28 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x30 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x38 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x40 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x48 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x50 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x58 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x60 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x68 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x70 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x78 */
   33,  34,  53,  37,  35,  36,  52,  56,  /* 0x80 */
   39,  40,  41,  42,  43,  44,  45,  46,  /* 0x88 */
   48,  49,  50,  51, 255,  38, 255,  60,  /* 0x90 */
   57,  59, 255,  55,  54,  58,  32,  47,  /* 0x98 */
    0,   0, 255,   0,   0,   0,   0, 255,  /* 0xa0 */
    0,   0,   0, 255, 255,   0, 255, 255,  /* 0xa8 */
    0,   0,   0,   0, 255,   0, 255, 255,  /* 0xb0 */
  255, 255, 255, 255, 255, 255, 255, 255,  /* 0xb8 */
  255, 255,   0,   0, 255,   0,   0,   0,  /* 0xc0 */
    0,   0,   0, 255, 255, 255, 255, 255,  /* 0xc8 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0xd0 */
  255, 255, 255, 255,   0, 255, 255,  18,  /* 0xd8 */
    2,   3,  24,   8,   5,   6,  23,  27,  /* 0xe0 */
   10,  11,  12,  13,  14,  15,  16,  17,  /* 0xe8 */
   19,  20,  21,  22,   7,   9,   4,  31,  /* 0xf0 */
   28,  30, 255,  26,  25,  29,   1,   0,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char *PAIR_MACCYR[] = {

  (unsigned char*)"\xef\xf1\xed\xe2\xee\xe8\xf2\xea\xe4\xe1\xec\x82\x8d\x8f\xe7\xf0\x91\xf7\xf3\xe3\x8e\x8a\x88\x92\xeb\x8c\x84\xe5\x80\xfd\xdf\x90\x81\xe6\xe0\x83\x87\x9f\x97\xf5\x93\x9d\x8b\xf8\x85\x95\xf4\x86\x94\xf6\x98",  /* FILLCHAR */
  (unsigned char*)".\xf2\xe4\xf9\xe1",  /* 0xfe */
  (unsigned char*)".\xeb\xf2\xea\xed\xe7\xf1\xec\xe2\xf0\xe4\xdf\xe5\xfe\xe6\xf8\xf5\xe9\xe1\xf7\xef\xe3\xf3\xf9\xf6",  /* 0xe0 */
  (unsigned char*)"\xfb\xee\xe5\xf0\xf3\xe0\xe8\xeb\xdf.\xed",  /* 0xe1 */
  (unsigned char*)"\xe5\xe8\xe0.\xee",  /* 0xf6 */
  (unsigned char*)"\xe5\xe0\xee\xe8\xf3\xed\xf0.\xe2\xfb\xfc\xeb\xdf\xf1\xea\xf6",  /* 0xe4 */
  (unsigned char*)".\xed\xf0\xeb\xf2\xf1\xec\xe3\xe4\xe9\xea\xe2\xe7\xe1\xf7\xe5\xef\xf8\xe6\xf9\xf5\xf6\xee",  /* 0xe5 */
  (unsigned char*)"\xee\xe8",  /* 0xf4 */
  (unsigned char*)"\xee\xe0\xeb\xf0\xe4\xe8.\xf3\xed\xe5",  /* 0xe3 */
  (unsigned char*)".\xee\xe0\xe8\xed",  /* 0xf5 */
  (unsigned char*)".\xeb\xf2\xed\xea\xec\xf1\xe2\xe7\xe5\xf5\xe4\xf7\xe9\xdf\xf0\xf6\xe3\xe8\xf8\xe1\xee\xe6\xef\xe0\xfe",  /* 0xe8 */
  (unsigned char*)".\xf1\xf2\xed\xf7\xe4",  /* 0xe9 */
  (unsigned char*)"\xe0\xee.\xe8\xf3\xf0\xf2\xeb\xf1\xe5\xed",  /* 0xea */
  (unsigned char*)".\xe8\xee\xe0\xe5\xfc\xf1\xdf\xf3\xfe\xfb\xea\xed\xeb",  /* 0xeb */
  (unsigned char*)".\xee\xe5\xe0\xe8\xf3\xed\xfb\xdf",  /* 0xec */
  (unsigned char*)"\xe0\xee\xe5\xe8.\xfb\xf3\xed\xdf\xfc\xf2\xe4\xf1\xea\xf6",  /* 0xed */
  (unsigned char*)".\xe2\xf0\xf2\xeb\xf1\xed\xec\xe4\xe3\xe9\xe1\xea\xe6\xf7\xe5\xef\xe7\xf8\xe8\xdf\xf5\xee\xf9\xfe",  /* 0xee */
  (unsigned char*)"\xee\xf0\xe5\xe0\xe8\xeb\xf3\xfb\xdf",  /* 0xef */
  (unsigned char*)".\xf2\xeb\xe4\xed\xf1\xec\xe2\xe7\xf9",  /* 0xdf */
  (unsigned char*)"\xee\xe0\xe5\xe8\xf3.\xfb\xed\xdf\xf2\xfc\xe2\xec\xe4\xea\xe6\xf1\xfe",  /* 0xf0 */
  (unsigned char*)"\xf2\xdf\xea\xe5.\xfc\xee\xeb\xe8\xef\xe0\xed\xe2\xec\xf1\xf3\xfb\xf7",  /* 0xf1 */
  (unsigned char*)"\xee.\xe0\xe5\xfc\xe8\xf0\xe2\xfb\xf3\xf1\xed\xea\xdf\xeb",  /* 0xf2 */
  (unsigned char*)".\xeb\xe4\xf2\xf1\xec\xe6\xe3\xfe\xf7\xf0\xea\xe1\xef\xf8\xe2\xed\xf5\xe7\xf9",  /* 0xf3 */
  (unsigned char*)"\xe5\xe8\xe0\xed\xe4.\xf3",  /* 0xe6 */
  (unsigned char*)"\xe0\xee.\xe5\xe8\xfb\xf1\xed\xf0\xf3\xeb\xf8\xe7\xf2\xe4\xdf\xea",  /* 0xe2 */
  (unsigned char*)".\xed\xea\xf1\xf8\xe5\xfe\xdf",  /* 0xfc */
  (unsigned char*)".\xeb\xe9\xe5\xec\xf5\xe2\xf2\xf1\xf8\xf0\xe1",  /* 0xfb */
  (unsigned char*)"\xe0\xed.\xe4\xe2\xee\xe8\xe5\xf3\xfb\xec\xf0\xdf\xe3\xeb",  /* 0xe7 */
  (unsigned char*)"\xe5\xe8\xe0\xfc\xea\xeb\xed\xee\xf3",  /* 0xf8 */
  (unsigned char*)"\xf2",  /* 0xfd */
  (unsigned char*)"\xe5\xe8\xe0",  /* 0xf9 */
  (unsigned char*)"\xe5\xf2\xe0\xe8\xed\xf3\xea.\xfc",  /* 0xf7 */
  (unsigned char*)".",  /* 0x9e */
  (unsigned char*)".\x8b\x92\x8a\x8d\x87\x82\x91\x8c\x90\x9f\x84\xed",  /* 0x80 */
  (unsigned char*)"\x9b\x8e\x85",  /* 0x81 */
  (unsigned char*)"\x85\x80\x8e\xe0\x88\x93.\xee\x8d",  /* 0x84 */
  (unsigned char*)".\x90\x8d\x8b\x92\x91\x8c\x84\x83\x82\x89\x81",  /* 0x85 */
  (unsigned char*)"\x8e\xee",  /* 0x83 */
  (unsigned char*)".\x8e",  /* 0x95 */
  (unsigned char*)".\x8b\x92\x8d\x91\x8a\x8c\x82\x84\x85\x87\x97",  /* 0x88 */
  (unsigned char*)".",  /* 0x89 */
  (unsigned char*)"\x80\x8e.\x88\xe0\xee\x93\x90",  /* 0x8a */
  (unsigned char*)".\x88\x8e\x80\x85\x9c\x91",  /* 0x8b */
  (unsigned char*)".\xe0\x85\x8e\x80\x88\x93\xee\x8d",  /* 0x8c */
  (unsigned char*)"\x85\x80\x8e\x88\xe5.\xe0\x9b\x93\xee\x8d\xf3\x9f",  /* 0x8d */
  (unsigned char*)".\x82\xed\x92\x8d\x91\x8b\x90\x8c\x84\x83\x89\x81\x86\x85\x8a\x97\x8f",  /* 0x8e */
  (unsigned char*)"\x8e\x90\xee\xf0\x85\xe0\x80",  /* 0x8f */
  (unsigned char*)".\x92",  /* 0x9f */
  (unsigned char*)"\x8e\x80\x85\x88\x93.\xf3\xe0",  /* 0x90 */
  (unsigned char*)"\x92.\x9f\x8a\x85\x9c\x8b\x8e\x8f\xf2\x88\xea",  /* 0x91 */
  (unsigned char*)"\x8e.\x80\x9c\x85\x88\x90\xee\x82\xe0\x9b\x93",  /* 0x92 */
  (unsigned char*)".\x84\x8b\x92",  /* 0x93 */
  (unsigned char*)"\x85",  /* 0x86 */
  (unsigned char*)".\x8e\x80\x85\x88\xfb\x9b\xee\x91\xe8\xf1\xe0",  /* 0x82 */
  (unsigned char*)".",  /* 0x9c */
  (unsigned char*)".\x8b\x89",  /* 0x9b */
  (unsigned char*)"\x80\xe0\x8d.",  /* 0x87 */
  (unsigned char*)"\x85\x88",  /* 0x98 */
  (unsigned char*)"\xf2\x92",  /* 0x9d */
  (unsigned char*)"\x85",  /* 0x99 */
  (unsigned char*)"\x85\x92\xf2\x80\x88",  /* 0x97 */
};


/* THIS IS A GENERATED TABLE, see data/totals.pl. */
static const unsigned short int SIGNIFICANT[] = {
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x00 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x08 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x10 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x18 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x20 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x28 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x30 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x38 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x40 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x48 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x50 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x58 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x60 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x68 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x70 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x78 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x80 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x88 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x90 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x98 */
   4711,   935,  2406,   896,  1917,  5075,   570,   969,  /* 0xa0 */
   3824,   819,  2062,  2651,  1688,  3538,  5972,  1529,  /* 0xa8 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0xb0 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0xb8 */
    418,  4711,   935,   244,  1917,  5075,     0,   896,  /* 0xc0 */
    597,  3824,   819,  2062,  2651,  1688,  3538,  5972,  /* 0xc8 */
   6240,  2197,  5158,  3825,  5545,  6655,  1140,  3375,  /* 0xd0 */
   5026,  2103,  3031,  3151,  1688,  3538,  6726,  2791,  /* 0xd8 */
  14926,  7728, 12068,  4952,  3834, 11344,  1628,  3446,  /* 0xe0 */
   8648,  1638,  4124,  7870,  5780,  7076, 12780,  5582,  /* 0xe8 */
   5504,  5858,  7256,  3160,     0,  1194,   488,  1508,  /* 0xf0 */
   1000,     0,     0,  2568,  2404,     0,   836,  1262,  /* 0xf8 */
};

/* THIS IS A GENERATED VALUE, see data/totals.pl */
#define WEIGHT_SUM 56712

/* THIS IS A GENERATED TABLE, see data/totals.pl */
static const char *const CHARSET_NAMES[] = {
  "koi8r",
  "cp1251",
  "iso88595",
  "ibm866",
  "maccyr",
};

/* THIS IS A GENERATED TABLE, see data/totals.pl */
static const unsigned short int *const CHARSET_WEIGHTS[] = {
  RAW_KOI8R,
  RAW_CP1251,
  RAW_ISO88595,
  RAW_IBM866,
  RAW_MACCYR,
};

/* THIS IS A GENERATED TABLE, see data/totals.pl */
static const unsigned char *const CHARSET_LETTERS[] = {
  LETTER_KOI8R,
  LETTER_CP1251,
  LETTER_ISO88595,
  LETTER_IBM866,
  LETTER_MACCYR,
};

/* THIS IS A GENERATED TABLE, see data/totals.pl */
static const unsigned char **const CHARSET_PAIRS[] = {
  PAIR_KOI8R,
  PAIR_CP1251,
  PAIR_ISO88595,
  PAIR_IBM866,
  PAIR_MACCYR,
};

/* THIS IS A GENERATED VALUE, see data/totals.pl */
#define NCHARSETS 5
