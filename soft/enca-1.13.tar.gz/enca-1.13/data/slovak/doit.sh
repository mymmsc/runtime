#! /bin/bash
../doit.sh cp1250 iso88592 ibm852 keybcs2 macce koi8cs2 cork
