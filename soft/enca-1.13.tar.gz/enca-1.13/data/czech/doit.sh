#! /bin/bash
../doit.sh iso88592 cp1250 ibm852 keybcs2 macce koi8cs2 cork
