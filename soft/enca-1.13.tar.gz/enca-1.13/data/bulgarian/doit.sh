#! /bin/bash
../doit.sh cp1251 iso88595 ibm855 maccyr ecma113
