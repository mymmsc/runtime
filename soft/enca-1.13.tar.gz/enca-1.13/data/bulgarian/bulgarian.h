/*****  THIS IS A GENERATED FILE.  DO NOT TOUCH!  *****/
/* THIS IS A GENERATED TABLE, see data/basetoc.c. */
static const unsigned short int RAW_CP1251[] = {
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x00 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x08 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x10 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x18 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x20 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x28 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x30 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x38 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x40 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x48 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x50 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x58 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x60 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x68 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x70 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x78 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x80 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x88 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x90 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x98 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xa0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xa8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xb0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xb8 */
   125,    0,   97,    0,    0,    0,    0,    0,  /* 0xc0 */
   104,    0,    0,    0,    0,  170,    0,   98,  /* 0xc8 */
     0,  107,  135,    0,    0,    0,    0,    0,  /* 0xd0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xd8 */
  5956,  713, 2084,  731, 1638, 4455,  396, 1148,  /* 0xe0 */
  4081,  299, 1679, 1654, 1291, 3203, 4364, 1306,  /* 0xe8 */
  2168, 2364, 3471,  676,    0,  376,  224,  669,  /* 0xf0 */
   376,  324,  992,    0,    0,    0,    0,  893,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char LETTER_CP1251[] = {
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x00 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x08 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x10 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x18 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x20 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x28 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x30 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x38 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x40 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x48 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x50 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x58 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x60 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x68 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x70 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x78 */
  255, 255,   0, 255,   0,   0,   0,   0,  /* 0x80 */
    0,   0, 255,   0, 255, 255, 255, 255,  /* 0x88 */
  255,   0,   0,   0,   0,   0,   0,   0,  /* 0x90 */
    0,   0, 255,   0, 255, 255, 255, 255,  /* 0x98 */
    0, 255, 255, 255,   0, 255,   0,   0,  /* 0xa0 */
  255,   0, 255,   0,   0,   0,   0, 255,  /* 0xa8 */
    0,   0, 255, 255, 255,   0,   0,   0,  /* 0xb0 */
  255,   0, 255,   0, 255, 255, 255, 255,  /* 0xb8 */
    1, 255,   2, 255, 255, 255, 255,   3,  /* 0xc0 */
    4, 255,   5, 255,   6,   7, 255,   8,  /* 0xc8 */
  255, 255,   9, 255, 255, 255, 255, 255,  /* 0xd0 */
  255, 255, 255, 255, 255, 255, 255, 255,  /* 0xd8 */
   10,  11,  12,  13,  14,  15,  16,  17,  /* 0xe0 */
   18,  19,  20,  21,  22,  23,  24,  25,  /* 0xe8 */
   26,  27,  28,  29,  30,  31,  32,  33,  /* 0xf0 */
   34,  35,  36, 255, 255, 255, 255,  37,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char *PAIR_CP1251[] = {

  (unsigned char*)"\xf1\xed\xef\xe4\xe8\xe2\xee\xf2\xea\xec\xe7\xe1\xe5\xe3\xf0\xf7\xcd\xe0\xeb\xf3\xd2\xcf\xd1\xc2\xc4\xc0\xca\xf9\xc8\xcc\xf5\xc7\xe6\xc1\xce\xff\xf6\xd0\xf4\xc3\xc5\xf8\xd5\xcb\xd7\xd3",  /* FILLCHAR */
  (unsigned char*)".",  /* 0xc0 */
  (unsigned char*)".\xe8",  /* 0xc2 */
  (unsigned char*)"\xe0",  /* 0xc7 */
  (unsigned char*)".",  /* 0xc8 */
  (unsigned char*)"\xe0\xee",  /* 0xca */
  (unsigned char*)"\xe0",  /* 0xcc */
  (unsigned char*)"\xe5\xe0\xee\xe8",  /* 0xcd */
  (unsigned char*)"\xee\xf0",  /* 0xcf */
  (unsigned char*)"\xee",  /* 0xd2 */
  (unsigned char*)".\xf2\xed\xe2\xeb\xea\xe7\xec\xf0\xf1\xe4\xf8\xe9\xef\xf5\xe1\xf7\xf9\xe3\xe6\xe5\xff\xf6",  /* 0xe0 */
  (unsigned char*)"\xe5\xe8\xf0\xee\xe0\xfa\xeb\xff\xe2\xf3",  /* 0xe1 */
  (unsigned char*)"\xe0\xe5\xe8\xee.\xfa\xf1\xf0\xed\xff\xeb\xf2",  /* 0xe2 */
  (unsigned char*)"\xee\xe0\xeb\xe8\xf0\xed.\xfa",  /* 0xe3 */
  (unsigned char*)"\xe0\xe5\xe8\xee.\xed\xf0\xfa\xe2\xf3\xff\xf1",  /* 0xe4 */
  (unsigned char*)".\xed\xf2\xe4\xeb\xf1\xf0\xec\xf8\xe7\xea\xe3\xf7\xf9\xe6\xe2\xef\xe1\xe9\xf5\xf6\xee",  /* 0xe5 */
  (unsigned char*)"\xe5\xe8\xe4\xe0\xed.",  /* 0xe6 */
  (unsigned char*)"\xe0\xe8\xe2\xed.\xef\xe5\xe4\xeb\xec\xee\xea\xe1\xe3\xf0",  /* 0xe7 */
  (unsigned char*)".\xf2\xed\xe7\xff\xeb\xe5\xf1\xf7\xec\xea\xe2\xf0\xe3\xf6\xe4\xf5\xf8\xe6\xf9\xee\xef",  /* 0xe8 */
  (unsigned char*)".\xf2\xed\xf1\xea",  /* 0xe9 */
  (unsigned char*)"\xe0\xee\xe8.\xfa\xf0\xe2\xf2\xeb\xf3\xed",  /* 0xea */
  (unsigned char*)"\xe8\xe5\xe0\xee.\xed\xff\xea\xf3\xfa\xfe",  /* 0xeb */
  (unsigned char*)"\xe5\xe0.\xe8\xee\xf3\xed\xfa\xff",  /* 0xec */
  (unsigned char*)"\xe0\xe8\xe5\xee.\xff\xf2\xf1\xed\xe4\xf6\xea",  /* 0xed */
  (unsigned char*)".\xf2\xe2\xf1\xf0\xeb\xe1\xe3\xe4\xe9\xed\xea\xe6\xec\xf7\xef\xff\xe7\xe8\xe5\xf9",  /* 0xee */
  (unsigned char*)"\xee\xf0\xe0\xe8\xfa\xe5\xeb\xf3",  /* 0xef */
  (unsigned char*)"\xe0\xe5\xe8\xee\xfa.\xf3\xff\xed\xe2\xf2\xe4\xf1\xec\xea",  /* 0xf0 */
  (unsigned char*)"\xf2\xe5\xe8.\xfa\xeb\xe0\xea\xe2\xed\xef\xec\xee\xff\xf0",  /* 0xf1 */
  (unsigned char*)"\xee\xe0\xe5.\xe8\xf0\xe2\xed\xfa\xff\xf3\xea\xf2\xeb",  /* 0xf2 */
  (unsigned char*)".\xf1\xe2\xf7\xec\xe4\xe3\xea\xf0\xef\xe1\xf8\xeb\xe6\xed\xf2",  /* 0xf3 */
  (unsigned char*)"\xe8",  /* 0xf4 */
  (unsigned char*)".\xe0\xee\xed\xe2",  /* 0xf5 */
  (unsigned char*)"\xe8\xe5\xe0",  /* 0xf6 */
  (unsigned char*)"\xe5\xe0\xe8\xed\xea\xf3\xee",  /* 0xf7 */
  (unsigned char*)"\xe5.\xe8\xe0",  /* 0xf8 */
  (unsigned char*)"\xe5\xee\xe0\xe8",  /* 0xf9 */
  (unsigned char*)"\xf0\xeb\xf2\xec\xf1\xea\xe7\xe4\xed\xe2\xf9\xef\xe6\xe3\xe1",  /* 0xfa */
  (unsigned char*)".\xf2\xea\xe2\xf5\xec\xeb\xf1\xe1\xed",  /* 0xff */
};


/* THIS IS A GENERATED TABLE, see data/basetoc.c. */
static const unsigned short int RAW_ISO88595[] = {
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x00 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x08 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x10 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x18 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x20 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x28 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x30 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x38 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x40 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x48 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x50 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x58 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x60 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x68 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x70 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x78 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x80 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x88 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x90 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x98 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xa0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xa8 */
   125,    0,   97,    0,    0,    0,    0,    0,  /* 0xb0 */
   104,    0,    0,    0,    0,  170,    0,   98,  /* 0xb8 */
     0,  107,  135,    0,    0,    0,    0,    0,  /* 0xc0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xc8 */
  5956,  713, 2084,  731, 1638, 4455,  396, 1148,  /* 0xd0 */
  4081,  299, 1679, 1654, 1291, 3203, 4364, 1306,  /* 0xd8 */
  2168, 2364, 3471,  676,    0,  376,  224,  669,  /* 0xe0 */
   376,  324,  992,    0,    0,    0,    0,  893,  /* 0xe8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xf0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char LETTER_ISO88595[] = {
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x00 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x08 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x10 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x18 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x20 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x28 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x30 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x38 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x40 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x48 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x50 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x58 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x60 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x68 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x70 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x78 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x80 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x88 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x90 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x98 */
    0, 255, 255, 255, 255, 255, 255, 255,  /* 0xa0 */
  255, 255, 255, 255, 255,   0, 255, 255,  /* 0xa8 */
    1, 255,   2, 255, 255, 255, 255,   3,  /* 0xb0 */
    4, 255,   5, 255,   6,   7, 255,   8,  /* 0xb8 */
  255, 255,   9, 255, 255, 255, 255, 255,  /* 0xc0 */
  255, 255, 255, 255, 255, 255, 255, 255,  /* 0xc8 */
   10,  11,  12,  13,  14,  15,  16,  17,  /* 0xd0 */
   18,  19,  20,  21,  22,  23,  24,  25,  /* 0xd8 */
   26,  27,  28,  29,  30,  31,  32,  33,  /* 0xe0 */
   34,  35,  36, 255, 255, 255, 255,  37,  /* 0xe8 */
    0, 255, 255, 255, 255, 255, 255, 255,  /* 0xf0 */
  255, 255, 255, 255, 255,   0, 255, 255,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char *PAIR_ISO88595[] = {

  (unsigned char*)"\xe1\xdd\xdf\xd4\xd8\xd2\xde\xe2\xda\xdc\xd7\xd1\xd5\xd3\xe0\xe7\xbd\xd0\xdb\xe3\xc2\xbf\xc1\xb2\xb4\xb0\xba\xe9\xb8\xbc\xe5\xb7\xd6\xb1\xbe\xef\xe6\xc0\xe4\xb3\xb5\xe8\xc5\xbb\xc7\xc3",  /* FILLCHAR */
  (unsigned char*)".",  /* 0xb0 */
  (unsigned char*)".\xd8",  /* 0xb2 */
  (unsigned char*)"\xd0",  /* 0xb7 */
  (unsigned char*)".",  /* 0xb8 */
  (unsigned char*)"\xd0\xde",  /* 0xba */
  (unsigned char*)"\xd0",  /* 0xbc */
  (unsigned char*)"\xd5\xd0\xde\xd8",  /* 0xbd */
  (unsigned char*)"\xde\xe0",  /* 0xbf */
  (unsigned char*)"\xde",  /* 0xc2 */
  (unsigned char*)".\xe2\xdd\xd2\xdb\xda\xd7\xdc\xe0\xe1\xd4\xe8\xd9\xdf\xe5\xd1\xe7\xe9\xd3\xd6\xd5\xef\xe6",  /* 0xd0 */
  (unsigned char*)"\xd5\xd8\xe0\xde\xd0\xea\xdb\xef\xd2\xe3",  /* 0xd1 */
  (unsigned char*)"\xd0\xd5\xd8\xde.\xea\xe1\xe0\xdd\xef\xdb\xe2",  /* 0xd2 */
  (unsigned char*)"\xde\xd0\xdb\xd8\xe0\xdd.\xea",  /* 0xd3 */
  (unsigned char*)"\xd0\xd5\xd8\xde.\xdd\xe0\xea\xd2\xe3\xef\xe1",  /* 0xd4 */
  (unsigned char*)".\xdd\xe2\xd4\xdb\xe1\xe0\xdc\xe8\xd7\xda\xd3\xe7\xe9\xd6\xd2\xdf\xd1\xd9\xe5\xe6\xde",  /* 0xd5 */
  (unsigned char*)"\xd5\xd8\xd4\xd0\xdd.",  /* 0xd6 */
  (unsigned char*)"\xd0\xd8\xd2\xdd.\xdf\xd5\xd4\xdb\xdc\xde\xda\xd1\xd3\xe0",  /* 0xd7 */
  (unsigned char*)".\xe2\xdd\xd7\xef\xdb\xd5\xe1\xe7\xdc\xda\xd2\xe0\xd3\xe6\xd4\xe5\xe8\xd6\xe9\xde\xdf",  /* 0xd8 */
  (unsigned char*)".\xe2\xdd\xe1\xda",  /* 0xd9 */
  (unsigned char*)"\xd0\xde\xd8.\xea\xe0\xd2\xe2\xdb\xe3\xdd",  /* 0xda */
  (unsigned char*)"\xd8\xd5\xd0\xde.\xdd\xef\xda\xe3\xea\xee",  /* 0xdb */
  (unsigned char*)"\xd5\xd0.\xd8\xde\xe3\xdd\xea\xef",  /* 0xdc */
  (unsigned char*)"\xd0\xd8\xd5\xde.\xef\xe2\xe1\xdd\xd4\xe6\xda",  /* 0xdd */
  (unsigned char*)".\xe2\xd2\xe1\xe0\xdb\xd1\xd3\xd4\xd9\xdd\xda\xd6\xdc\xe7\xdf\xef\xd7\xd8\xd5\xe9",  /* 0xde */
  (unsigned char*)"\xde\xe0\xd0\xd8\xea\xd5\xdb\xe3",  /* 0xdf */
  (unsigned char*)"\xd0\xd5\xd8\xde\xea.\xe3\xef\xdd\xd2\xe2\xd4\xe1\xdc\xda",  /* 0xe0 */
  (unsigned char*)"\xe2\xd5\xd8.\xea\xdb\xd0\xda\xd2\xdd\xdf\xdc\xde\xef\xe0",  /* 0xe1 */
  (unsigned char*)"\xde\xd0\xd5.\xd8\xe0\xd2\xdd\xea\xef\xe3\xda\xe2\xdb",  /* 0xe2 */
  (unsigned char*)".\xe1\xd2\xe7\xdc\xd4\xd3\xda\xe0\xdf\xd1\xe8\xdb\xd6\xdd\xe2",  /* 0xe3 */
  (unsigned char*)"\xd8",  /* 0xe4 */
  (unsigned char*)".\xd0\xde\xdd\xd2",  /* 0xe5 */
  (unsigned char*)"\xd8\xd5\xd0",  /* 0xe6 */
  (unsigned char*)"\xd5\xd0\xd8\xdd\xda\xe3\xde",  /* 0xe7 */
  (unsigned char*)"\xd5.\xd8\xd0",  /* 0xe8 */
  (unsigned char*)"\xd5\xde\xd0\xd8",  /* 0xe9 */
  (unsigned char*)"\xe0\xdb\xe2\xdc\xe1\xda\xd7\xd4\xdd\xd2\xe9\xdf\xd6\xd3\xd1",  /* 0xea */
  (unsigned char*)".\xe2\xda\xd2\xe5\xdc\xdb\xe1\xd1\xdd",  /* 0xef */
};


/* THIS IS A GENERATED TABLE, see data/basetoc.c. */
static const unsigned short int RAW_IBM855[] = {
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x00 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x08 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x10 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x18 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x20 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x28 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x30 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x38 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x40 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x48 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x50 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x58 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x60 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x68 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x70 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x78 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x80 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x88 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x90 */
     0,    0,    0,    0,    0,    0,  992,    0,  /* 0x98 */
  5956,  125,  713,    0,  224,    0, 1638,    0,  /* 0xa0 */
  4455,    0,    0,    0,  731,    0,    0,    0,  /* 0xa8 */
     0,    0,    0,    0,    0,  376,    0, 4081,  /* 0xb0 */
   104,    0,    0,    0,    0,  299,    0,    0,  /* 0xb8 */
     0,    0,    0,    0,    0,    0, 1679,    0,  /* 0xc0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xc8 */
  1654,    0, 1291,    0, 3203,  170, 4364,    0,  /* 0xd0 */
  1306,    0,    0,    0,    0,   98,  893,    0,  /* 0xd8 */
     0, 2168,    0, 2364,  107, 3471,  135,  676,  /* 0xe0 */
     0,  396,    0, 2084,   97,    0,    0,    0,  /* 0xe8 */
     0,    0,    0, 1148,    0,  376,    0,    0,  /* 0xf0 */
     0,  324,    0,  669,    0,    0,    0,    0,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char LETTER_IBM855[] = {
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x00 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x08 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x10 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x18 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x20 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x28 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x30 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x38 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x40 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x48 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x50 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x58 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x60 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x68 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x70 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x78 */
  255, 255, 255, 255, 255, 255, 255, 255,  /* 0x80 */
  255, 255, 255, 255, 255, 255, 255, 255,  /* 0x88 */
  255, 255, 255, 255, 255,   0, 255, 255,  /* 0x90 */
  255, 255, 255, 255, 255, 255,  36, 255,  /* 0x98 */
   10,   1,  11, 255,  32, 255,  14, 255,  /* 0xa0 */
   15, 255,  30, 255,  13, 255,   0,   0,  /* 0xa8 */
    0,   0,   0,   0,   0,  31, 255,  18,  /* 0xb0 */
    4,   0,   0,   0,   0,  19, 255,   0,  /* 0xb8 */
    0,   0,   0,   0,   0,   0,  20,   5,  /* 0xc0 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0xc8 */
   21, 255,  22,   6,  23,   7,  24, 255,  /* 0xd0 */
   25,   0,   0,   0,   0,   8,  37,   0,  /* 0xd8 */
  255,  26, 255,  27, 255,  28,   9,  29,  /* 0xe0 */
  255,  16, 255,  12,   2, 255, 255,   0,  /* 0xe8 */
    0, 255, 255,  17,   3,  34, 255, 255,  /* 0xf0 */
  255,  35, 255,  33, 255,   0,   0,   0,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char *PAIR_IBM855[] = {

  (unsigned char*)"\xe3\xd4\xd8\xa6\xb7\xeb\xd6\xe5\xc6\xd2\xf3\xa2\xa8\xac\xe1\xfb\xd5\xa0\xd0\xe7\xe6\xdd\xe4\xec\xa7\xa1\xc7\xf9\xb8\xd3\xb5\xf4\xe9\xa3\xd7\xde\xa4\xe2\xaa\xad\xa9\xf5\xb6\xd1\xfc\xe8",  /* FILLCHAR */
  (unsigned char*)".",  /* 0xa1 */
  (unsigned char*)".\xb7",  /* 0xec */
  (unsigned char*)"\xa0",  /* 0xf4 */
  (unsigned char*)".",  /* 0xb8 */
  (unsigned char*)"\xa0\xd6",  /* 0xc7 */
  (unsigned char*)"\xa0",  /* 0xd3 */
  (unsigned char*)"\xa8\xa0\xd6\xb7",  /* 0xd5 */
  (unsigned char*)"\xd6\xe1",  /* 0xdd */
  (unsigned char*)"\xd6",  /* 0xe6 */
  (unsigned char*)".\xe5\xd4\xeb\xd0\xc6\xf3\xd2\xe1\xe3\xa6\xf5\xbd\xd8\xb5\xa2\xfb\xf9\xac\xe9\xa8\xde\xa4",  /* 0xa0 */
  (unsigned char*)"\xa8\xb7\xe1\xd6\xa0\x9e\xd0\xde\xeb\xe7",  /* 0xa2 */
  (unsigned char*)"\xa0\xa8\xb7\xd6.\x9e\xe3\xe1\xd4\xde\xd0\xe5",  /* 0xeb */
  (unsigned char*)"\xd6\xa0\xd0\xb7\xe1\xd4.\x9e",  /* 0xac */
  (unsigned char*)"\xa0\xa8\xb7\xd6.\xd4\xe1\x9e\xeb\xe7\xde\xe3",  /* 0xa6 */
  (unsigned char*)".\xd4\xe5\xa6\xd0\xe3\xe1\xd2\xf5\xf3\xc6\xac\xfb\xf9\xe9\xeb\xd8\xa2\xbd\xb5\xa4\xd6",  /* 0xa8 */
  (unsigned char*)"\xa8\xb7\xa6\xa0\xd4.",  /* 0xe9 */
  (unsigned char*)"\xa0\xb7\xeb\xd4.\xd8\xa8\xa6\xd0\xd2\xd6\xc6\xa2\xac\xe1",  /* 0xf3 */
  (unsigned char*)".\xe5\xd4\xf3\xde\xd0\xa8\xe3\xfb\xd2\xc6\xeb\xe1\xac\xa4\xa6\xb5\xf5\xe9\xf9\xd6\xd8",  /* 0xb7 */
  (unsigned char*)".\xe5\xd4\xe3\xc6",  /* 0xbd */
  (unsigned char*)"\xa0\xd6\xb7.\x9e\xe1\xeb\xe5\xd0\xe7\xd4",  /* 0xc6 */
  (unsigned char*)"\xb7\xa8\xa0\xd6.\xd4\xde\xc6\xe7\x9e\x9c",  /* 0xd0 */
  (unsigned char*)"\xa8\xa0.\xb7\xd6\xe7\xd4\x9e\xde",  /* 0xd2 */
  (unsigned char*)"\xa0\xb7\xa8\xd6.\xde\xe5\xe3\xd4\xa6\xa4\xc6",  /* 0xd4 */
  (unsigned char*)".\xe5\xeb\xe3\xe1\xd0\xa2\xac\xa6\xbd\xd4\xc6\xe9\xd2\xfb\xd8\xde\xf3\xb7\xa8\xf9",  /* 0xd6 */
  (unsigned char*)"\xd6\xe1\xa0\xb7\x9e\xa8\xd0\xe7",  /* 0xd8 */
  (unsigned char*)"\xa0\xa8\xb7\xd6\x9e.\xe7\xde\xd4\xeb\xe5\xa6\xe3\xd2\xc6",  /* 0xe1 */
  (unsigned char*)"\xe5\xa8\xb7.\x9e\xd0\xa0\xc6\xeb\xd4\xd8\xd2\xd6\xde\xe1",  /* 0xe3 */
  (unsigned char*)"\xd6\xa0\xa8.\xb7\xe1\xeb\xd4\x9e\xde\xe7\xc6\xe5\xd0",  /* 0xe5 */
  (unsigned char*)".\xe3\xeb\xfb\xd2\xa6\xac\xc6\xe1\xd8\xa2\xf5\xd0\xe9\xd4\xe5",  /* 0xe7 */
  (unsigned char*)"\xb7",  /* 0xaa */
  (unsigned char*)".\xa0\xd6\xd4\xeb",  /* 0xb5 */
  (unsigned char*)"\xb7\xa8\xa0",  /* 0xa4 */
  (unsigned char*)"\xa8\xa0\xb7\xd4\xc6\xe7\xd6",  /* 0xfb */
  (unsigned char*)"\xa8.\xb7\xa0",  /* 0xf5 */
  (unsigned char*)"\xa8\xd6\xa0\xb7",  /* 0xf9 */
  (unsigned char*)"\xe1\xd0\xe5\xd2\xe3\xc6\xf3\xa6\xd4\xeb\xf9\xd8\xe9\xac\xa2",  /* 0x9e */
  (unsigned char*)".\xe5\xc6\xeb\xb5\xd2\xd0\xe3\xa2\xd4",  /* 0xde */
};


/* THIS IS A GENERATED TABLE, see data/basetoc.c. */
static const unsigned short int RAW_MACCYR[] = {
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x00 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x08 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x10 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x18 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x20 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x28 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x30 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x38 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x40 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x48 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x50 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x58 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x60 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x68 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x70 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x78 */
   125,    0,   97,    0,    0,    0,    0,    0,  /* 0x80 */
   104,    0,    0,    0,    0,  170,    0,   98,  /* 0x88 */
     0,  107,  135,    0,    0,    0,    0,    0,  /* 0x90 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x98 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xa0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xa8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xb0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xb8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xc0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xc8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xd0 */
     0,    0,    0,    0,    0,    0,    0,  893,  /* 0xd8 */
  5956,  713, 2084,  731, 1638, 4455,  396, 1148,  /* 0xe0 */
  4081,  299, 1679, 1654, 1291, 3203, 4364, 1306,  /* 0xe8 */
  2168, 2364, 3471,  676,    0,  376,  224,  669,  /* 0xf0 */
   376,  324,  992,    0,    0,    0,    0,    0,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char LETTER_MACCYR[] = {
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x00 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x08 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x10 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x18 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x20 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x28 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x30 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x38 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x40 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x48 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x50 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x58 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x60 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x68 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x70 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x78 */
    1, 255,   2, 255, 255, 255, 255,   3,  /* 0x80 */
    4, 255,   5, 255,   6,   7, 255,   8,  /* 0x88 */
  255, 255,   9, 255, 255, 255, 255, 255,  /* 0x90 */
  255, 255, 255, 255, 255, 255, 255, 255,  /* 0x98 */
    0,   0, 255,   0,   0,   0,   0, 255,  /* 0xa0 */
    0,   0,   0, 255, 255,   0, 255, 255,  /* 0xa8 */
    0,   0,   0,   0, 255,   0, 255, 255,  /* 0xb0 */
  255, 255, 255, 255, 255, 255, 255, 255,  /* 0xb8 */
  255, 255,   0,   0, 255,   0,   0,   0,  /* 0xc0 */
    0,   0,   0, 255, 255, 255, 255, 255,  /* 0xc8 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0xd0 */
  255, 255, 255, 255,   0, 255, 255,  37,  /* 0xd8 */
   10,  11,  12,  13,  14,  15,  16,  17,  /* 0xe0 */
   18,  19,  20,  21,  22,  23,  24,  25,  /* 0xe8 */
   26,  27,  28,  29,  30,  31,  32,  33,  /* 0xf0 */
   34,  35,  36, 255, 255, 255, 255,   0,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char *PAIR_MACCYR[] = {

  (unsigned char*)"\xf1\xed\xef\xe4\xe8\xe2\xee\xf2\xea\xec\xe7\xe1\xe5\xe3\xf0\xf7\x8d\xe0\xeb\xf3\x92\x8f\x91\x82\x84\x80\x8a\xf9\x88\x8c\xf5\x87\xe6\x81\x8e\xdf\xf6\x90\xf4\x83\x85\xf8\x95\x8b\x97\x93",  /* FILLCHAR */
  (unsigned char*)".",  /* 0x80 */
  (unsigned char*)".\xe8",  /* 0x82 */
  (unsigned char*)"\xe0",  /* 0x87 */
  (unsigned char*)".",  /* 0x88 */
  (unsigned char*)"\xe0\xee",  /* 0x8a */
  (unsigned char*)"\xe0",  /* 0x8c */
  (unsigned char*)"\xe5\xe0\xee\xe8",  /* 0x8d */
  (unsigned char*)"\xee\xf0",  /* 0x8f */
  (unsigned char*)"\xee",  /* 0x92 */
  (unsigned char*)".\xf2\xed\xe2\xeb\xea\xe7\xec\xf0\xf1\xe4\xf8\xe9\xef\xf5\xe1\xf7\xf9\xe3\xe6\xe5\xdf\xf6",  /* 0xe0 */
  (unsigned char*)"\xe5\xe8\xf0\xee\xe0\xfa\xeb\xdf\xe2\xf3",  /* 0xe1 */
  (unsigned char*)"\xe0\xe5\xe8\xee.\xfa\xf1\xf0\xed\xdf\xeb\xf2",  /* 0xe2 */
  (unsigned char*)"\xee\xe0\xeb\xe8\xf0\xed.\xfa",  /* 0xe3 */
  (unsigned char*)"\xe0\xe5\xe8\xee.\xed\xf0\xfa\xe2\xf3\xdf\xf1",  /* 0xe4 */
  (unsigned char*)".\xed\xf2\xe4\xeb\xf1\xf0\xec\xf8\xe7\xea\xe3\xf7\xf9\xe6\xe2\xef\xe1\xe9\xf5\xf6\xee",  /* 0xe5 */
  (unsigned char*)"\xe5\xe8\xe4\xe0\xed.",  /* 0xe6 */
  (unsigned char*)"\xe0\xe8\xe2\xed.\xef\xe5\xe4\xeb\xec\xee\xea\xe1\xe3\xf0",  /* 0xe7 */
  (unsigned char*)".\xf2\xed\xe7\xdf\xeb\xe5\xf1\xf7\xec\xea\xe2\xf0\xe3\xf6\xe4\xf5\xf8\xe6\xf9\xee\xef",  /* 0xe8 */
  (unsigned char*)".\xf2\xed\xf1\xea",  /* 0xe9 */
  (unsigned char*)"\xe0\xee\xe8.\xfa\xf0\xe2\xf2\xeb\xf3\xed",  /* 0xea */
  (unsigned char*)"\xe8\xe5\xe0\xee.\xed\xdf\xea\xf3\xfa\xfe",  /* 0xeb */
  (unsigned char*)"\xe5\xe0.\xe8\xee\xf3\xed\xfa\xdf",  /* 0xec */
  (unsigned char*)"\xe0\xe8\xe5\xee.\xdf\xf2\xf1\xed\xe4\xf6\xea",  /* 0xed */
  (unsigned char*)".\xf2\xe2\xf1\xf0\xeb\xe1\xe3\xe4\xe9\xed\xea\xe6\xec\xf7\xef\xdf\xe7\xe8\xe5\xf9",  /* 0xee */
  (unsigned char*)"\xee\xf0\xe0\xe8\xfa\xe5\xeb\xf3",  /* 0xef */
  (unsigned char*)"\xe0\xe5\xe8\xee\xfa.\xf3\xdf\xed\xe2\xf2\xe4\xf1\xec\xea",  /* 0xf0 */
  (unsigned char*)"\xf2\xe5\xe8.\xfa\xeb\xe0\xea\xe2\xed\xef\xec\xee\xdf\xf0",  /* 0xf1 */
  (unsigned char*)"\xee\xe0\xe5.\xe8\xf0\xe2\xed\xfa\xdf\xf3\xea\xf2\xeb",  /* 0xf2 */
  (unsigned char*)".\xf1\xe2\xf7\xec\xe4\xe3\xea\xf0\xef\xe1\xf8\xeb\xe6\xed\xf2",  /* 0xf3 */
  (unsigned char*)"\xe8",  /* 0xf4 */
  (unsigned char*)".\xe0\xee\xed\xe2",  /* 0xf5 */
  (unsigned char*)"\xe8\xe5\xe0",  /* 0xf6 */
  (unsigned char*)"\xe5\xe0\xe8\xed\xea\xf3\xee",  /* 0xf7 */
  (unsigned char*)"\xe5.\xe8\xe0",  /* 0xf8 */
  (unsigned char*)"\xe5\xee\xe0\xe8",  /* 0xf9 */
  (unsigned char*)"\xf0\xeb\xf2\xec\xf1\xea\xe7\xe4\xed\xe2\xf9\xef\xe6\xe3\xe1",  /* 0xfa */
  (unsigned char*)".\xf2\xea\xe2\xf5\xec\xeb\xf1\xe1\xed",  /* 0xdf */
};


/* THIS IS A GENERATED TABLE, see data/basetoc.c. */
static const unsigned short int RAW_ECMA113[] = {
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x00 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x08 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x10 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x18 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x20 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x28 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x30 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x38 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x40 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x48 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x50 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x58 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x60 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x68 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x70 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x78 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x80 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x88 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x90 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x98 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xa0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xa8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xb0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xb8 */
     0, 5956,  713,  224, 1638, 4455,    0,  731,  /* 0xc0 */
   376, 4081,  299, 1679, 1654, 1291, 3203, 4364,  /* 0xc8 */
  1306,  893, 2168, 2364, 3471,  676,  396, 2084,  /* 0xd0 */
     0,    0, 1148,  376,    0,  324,  669,  992,  /* 0xd8 */
     0,  125,    0,    0,    0,    0,    0,    0,  /* 0xe0 */
     0,  104,    0,    0,    0,    0,  170,    0,  /* 0xe8 */
    98,    0,    0,  107,  135,    0,    0,   97,  /* 0xf0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char LETTER_ECMA113[] = {
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x00 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x08 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x10 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x18 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x20 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x28 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x30 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x38 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x40 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x48 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x50 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x58 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x60 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x68 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x70 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x78 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x80 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x88 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x90 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x98 */
    0, 255, 255, 255, 255, 255, 255, 255,  /* 0xa0 */
  255, 255, 255, 255, 255,   0, 255, 255,  /* 0xa8 */
    0, 255, 255, 255, 255, 255, 255, 255,  /* 0xb0 */
  255, 255, 255, 255, 255,   0, 255, 255,  /* 0xb8 */
  255,  10,  11,  32,  14,  15,  30,  13,  /* 0xc0 */
   31,  18,  19,  20,  21,  22,  23,  24,  /* 0xc8 */
   25,  37,  26,  27,  28,  29,  16,  12,  /* 0xd0 */
  255, 255,  17,  34, 255,  35,  33,  36,  /* 0xd8 */
  255,   1, 255, 255, 255, 255, 255, 255,  /* 0xe0 */
  255,   4, 255,   5, 255,   6,   7, 255,  /* 0xe8 */
    8, 255, 255, 255,   9, 255, 255,   2,  /* 0xf0 */
  255, 255,   3, 255, 255, 255, 255, 255,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char *PAIR_ECMA113[] = {

  (unsigned char*)"\xd3\xce\xd0\xc4\xc9\xd7\xcf\xd4\xcb\xcd\xda\xc2\xc5\xc7\xd2\xde\xee\xc1\xcc\xd5\xf4\xf0\xf3\xf7\xe4\xe1\xeb\xdd\xe9\xed\xc8\xfa\xd6\xe2\xef\xd1\xc3\xf2\xc6\xe7\xe5\xdb\xe8\xec\xfe\xf5",  /* FILLCHAR */
  (unsigned char*)".",  /* 0xe1 */
  (unsigned char*)".\xc9",  /* 0xf7 */
  (unsigned char*)"\xc1",  /* 0xfa */
  (unsigned char*)".",  /* 0xe9 */
  (unsigned char*)"\xc1\xcf",  /* 0xeb */
  (unsigned char*)"\xc1",  /* 0xed */
  (unsigned char*)"\xc5\xc1\xcf\xc9",  /* 0xee */
  (unsigned char*)"\xcf\xd2",  /* 0xf0 */
  (unsigned char*)"\xcf",  /* 0xf4 */
  (unsigned char*)".\xd4\xce\xd7\xcc\xcb\xda\xcd\xd2\xd3\xc4\xdb\xca\xd0\xc8\xc2\xde\xdd\xc7\xd6\xc5\xd1\xc3",  /* 0xc1 */
  (unsigned char*)"\xc5\xc9\xd2\xcf\xc1\xdf\xcc\xd1\xd7\xd5",  /* 0xc2 */
  (unsigned char*)"\xc1\xc5\xc9\xcf.\xdf\xd3\xd2\xce\xd1\xcc\xd4",  /* 0xd7 */
  (unsigned char*)"\xcf\xc1\xcc\xc9\xd2\xce.\xdf",  /* 0xc7 */
  (unsigned char*)"\xc1\xc5\xc9\xcf.\xce\xd2\xdf\xd7\xd5\xd1\xd3",  /* 0xc4 */
  (unsigned char*)".\xce\xd4\xc4\xcc\xd3\xd2\xcd\xdb\xda\xcb\xc7\xde\xdd\xd6\xd7\xd0\xc2\xca\xc8\xc3\xcf",  /* 0xc5 */
  (unsigned char*)"\xc5\xc9\xc4\xc1\xce.",  /* 0xd6 */
  (unsigned char*)"\xc1\xc9\xd7\xce.\xd0\xc5\xc4\xcc\xcd\xcf\xcb\xc2\xc7\xd2",  /* 0xda */
  (unsigned char*)".\xd4\xce\xda\xd1\xcc\xc5\xd3\xde\xcd\xcb\xd7\xd2\xc7\xc3\xc4\xc8\xdb\xd6\xdd\xcf\xd0",  /* 0xc9 */
  (unsigned char*)".\xd4\xce\xd3\xcb",  /* 0xca */
  (unsigned char*)"\xc1\xcf\xc9.\xdf\xd2\xd7\xd4\xcc\xd5\xce",  /* 0xcb */
  (unsigned char*)"\xc9\xc5\xc1\xcf.\xce\xd1\xcb\xd5\xdf\xc0",  /* 0xcc */
  (unsigned char*)"\xc5\xc1.\xc9\xcf\xd5\xce\xdf\xd1",  /* 0xcd */
  (unsigned char*)"\xc1\xc9\xc5\xcf.\xd1\xd4\xd3\xce\xc4\xc3\xcb",  /* 0xce */
  (unsigned char*)".\xd4\xd7\xd3\xd2\xcc\xc2\xc7\xc4\xca\xce\xcb\xd6\xcd\xde\xd0\xd1\xda\xc9\xc5\xdd",  /* 0xcf */
  (unsigned char*)"\xcf\xd2\xc1\xc9\xdf\xc5\xcc\xd5",  /* 0xd0 */
  (unsigned char*)"\xc1\xc5\xc9\xcf\xdf.\xd5\xd1\xce\xd7\xd4\xc4\xd3\xcd\xcb",  /* 0xd2 */
  (unsigned char*)"\xd4\xc5\xc9.\xdf\xcc\xc1\xcb\xd7\xce\xd0\xcd\xcf\xd1\xd2",  /* 0xd3 */
  (unsigned char*)"\xcf\xc1\xc5.\xc9\xd2\xd7\xce\xdf\xd1\xd5\xcb\xd4\xcc",  /* 0xd4 */
  (unsigned char*)".\xd3\xd7\xde\xcd\xc4\xc7\xcb\xd2\xd0\xc2\xdb\xcc\xd6\xce\xd4",  /* 0xd5 */
  (unsigned char*)"\xc9",  /* 0xc6 */
  (unsigned char*)".\xc1\xcf\xce\xd7",  /* 0xc8 */
  (unsigned char*)"\xc9\xc5\xc1",  /* 0xc3 */
  (unsigned char*)"\xc5\xc1\xc9\xce\xcb\xd5\xcf",  /* 0xde */
  (unsigned char*)"\xc5.\xc9\xc1",  /* 0xdb */
  (unsigned char*)"\xc5\xcf\xc1\xc9",  /* 0xdd */
  (unsigned char*)"\xd2\xcc\xd4\xcd\xd3\xcb\xda\xc4\xce\xd7\xdd\xd0\xd6\xc7\xc2",  /* 0xdf */
  (unsigned char*)".\xd4\xcb\xd7\xc8\xcd\xcc\xd3\xc2\xce",  /* 0xd1 */
};


/* THIS IS A GENERATED TABLE, see data/totals.pl. */
static const unsigned short int SIGNIFICANT[] = {
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x00 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x08 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x10 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x18 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x20 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x28 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x30 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x38 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x40 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x48 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x50 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x58 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x60 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x68 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x70 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x78 */
    125,     0,    97,     0,     0,     0,     0,     0,  /* 0x80 */
    104,     0,     0,     0,     0,   170,     0,    98,  /* 0x88 */
      0,   107,   135,     0,     0,     0,     0,     0,  /* 0x90 */
      0,     0,     0,     0,     0,     0,   992,     0,  /* 0x98 */
   5956,   125,   713,     0,   224,     0,  1638,     0,  /* 0xa0 */
   4455,     0,     0,     0,   731,     0,     0,     0,  /* 0xa8 */
    125,     0,    97,     0,     0,   376,     0,  4081,  /* 0xb0 */
    208,     0,     0,     0,     0,   469,     0,    98,  /* 0xb8 */
    125,  6063,   945,   224,  1638,  4455,  1679,   731,  /* 0xc0 */
    480,  4081,   299,  1679,  1654,  1461,  3203,  4462,  /* 0xc8 */
   8916,  1713,  5678,  3095,  8312,  5301,  5156,  3232,  /* 0xd0 */
   5387,   299,  2827,  2030,  1291,  3625,  5926,  3191,  /* 0xd8 */
  14080,  6083,  7639,  4502,  3383, 12757,  1151,  3641,  /* 0xe0 */
   8538,  1422,  4350,  5392,  2679,  6406,  8898,  3505,  /* 0xe8 */
   4434,  4728,  6942,  2607,   135,  1128,   448,  1435,  /* 0xf0 */
    752,   972,  1984,   669,     0,     0,     0,   893,  /* 0xf8 */
};

/* THIS IS A GENERATED VALUE, see data/totals.pl */
#define WEIGHT_SUM 48367

/* THIS IS A GENERATED TABLE, see data/totals.pl */
static const char *const CHARSET_NAMES[] = {
  "cp1251",
  "iso88595",
  "ibm855",
  "maccyr",
  "ecma113",
};

/* THIS IS A GENERATED TABLE, see data/totals.pl */
static const unsigned short int *const CHARSET_WEIGHTS[] = {
  RAW_CP1251,
  RAW_ISO88595,
  RAW_IBM855,
  RAW_MACCYR,
  RAW_ECMA113,
};

/* THIS IS A GENERATED TABLE, see data/totals.pl */
static const unsigned char *const CHARSET_LETTERS[] = {
  LETTER_CP1251,
  LETTER_ISO88595,
  LETTER_IBM855,
  LETTER_MACCYR,
  LETTER_ECMA113,
};

/* THIS IS A GENERATED TABLE, see data/totals.pl */
static const unsigned char **const CHARSET_PAIRS[] = {
  PAIR_CP1251,
  PAIR_ISO88595,
  PAIR_IBM855,
  PAIR_MACCYR,
  PAIR_ECMA113,
};

/* THIS IS A GENERATED VALUE, see data/totals.pl */
#define NCHARSETS 5
