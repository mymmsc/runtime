#! /bin/bash
../doit.sh cp1251 ibm855 iso88595 cp1125 koi8u maccyr
