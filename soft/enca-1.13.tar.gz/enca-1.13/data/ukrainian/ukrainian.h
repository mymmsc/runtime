/*****  THIS IS A GENERATED FILE.  DO NOT TOUCH!  *****/
/* THIS IS A GENERATED TABLE, see data/basetoc.c. */
static const unsigned short int RAW_CP1251[] = {
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x00 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x08 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x10 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x18 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x20 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x28 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x30 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x38 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x40 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x48 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x50 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x58 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x60 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x68 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x70 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x78 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x80 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x88 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x90 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x98 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xa0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xa8 */
     0,    0,    0, 3416,    0,    0,    0,    0,  /* 0xb0 */
     0,    0,    0,    0,    0,    0,    0,  587,  /* 0xb8 */
     0,    0,  274,    0,    0,    0,    0,    0,  /* 0xc0 */
     0,    0,    0,    0,    0,    0,    0,  254,  /* 0xc8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xd0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xd8 */
  5321,  774, 3238,  922, 1857, 3140,  485, 1219,  /* 0xe0 */
  3981,  688, 2410, 2105, 1772, 4802, 5884, 1587,  /* 0xe8 */
  3331, 2738, 3518, 1924,  275,  596,  507,  762,  /* 0xf0 */
   362,    0,    0,    0, 1116,    0,  424, 1401,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char LETTER_CP1251[] = {
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x00 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x08 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x10 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x18 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x20 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x28 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x30 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x38 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x40 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x48 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x50 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x58 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x60 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x68 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x70 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x78 */
  255, 255,   0, 255,   0,   0,   0,   0,  /* 0x80 */
    0,   0, 255,   0, 255, 255, 255, 255,  /* 0x88 */
  255,   0,   0,   0,   0,   0,   0,   0,  /* 0x90 */
    0,   0, 255,   0, 255, 255, 255, 255,  /* 0x98 */
    0, 255, 255, 255,   0, 255,   0,   0,  /* 0xa0 */
  255,   0, 255,   0,   0,   0,   0, 255,  /* 0xa8 */
    0,   0,   1,   2, 255,   0,   0,   0,  /* 0xb0 */
  255,   0,   3,   0, 255, 255, 255,   4,  /* 0xb8 */
    5,   6,   7, 255,   8,   9, 255,  10,  /* 0xc0 */
  255, 255,  11, 255,  12,  13, 255,  14,  /* 0xc8 */
   15,  16,  17,  18, 255, 255, 255, 255,  /* 0xd0 */
  255, 255, 255, 255, 255, 255, 255,  19,  /* 0xd8 */
   20,  21,  22,  23,  24,  25,  26,  27,  /* 0xe0 */
   28,  29,  30,  31,  32,  33,  34,  35,  /* 0xe8 */
   36,  37,  38,  39,  40,  41,  42,  43,  /* 0xf0 */
   44,  45, 255, 255,  46, 255,  47,  48,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char *PAIR_CP1251[] = {

  (unsigned char*)"\xe2\xef\xed\xf1\xe7\xf2\xe4\xec\xea\xe1\xf0\xee\xe3\xb3\xe9\xff\xf3\xeb\xf7\xf9\xc2\xe0\xcf\xf6\xf5\xe6\xcd\xc0\xcc\xd2\xce\xd1\xbf\xca\xc1\xb2\xd0\xf8\xc4\xc3\xc7\xf4\xd3\xdf\xd5\xba\xd7\xc5\xe5\xd8\xcb\xd6\xd4",  /* FILLCHAR */
  (unsigned char*)".",  /* 0xb2 */
  (unsigned char*)".\xe4\xe2\xeb\xed\xf2\xf1\xe9\xe7\xec\xea\xff\xf7\xf0\xf8\xbf\xba\xf5\xe1\xe6\xe3\xee\xfe\xe0",  /* 0xb3 */
  (unsigned char*)".\xf2",  /* 0xba */
  (unsigned char*)".\xed\xf5\xbf",  /* 0xbf */
  (unsigned char*)".\xeb",  /* 0xc0 */
  (unsigned char*)"\xe0",  /* 0xc1 */
  (unsigned char*)"\xe8\xee\xb3.",  /* 0xc2 */
  (unsigned char*)"\xee",  /* 0xc4 */
  (unsigned char*)"\xeb",  /* 0xc5 */
  (unsigned char*)"\xe0",  /* 0xc7 */
  (unsigned char*)"\xee",  /* 0xca */
  (unsigned char*)"\xe0\xee",  /* 0xcc */
  (unsigned char*)"\xe0\xe5",  /* 0xcd */
  (unsigned char*)"\xf0\xee",  /* 0xcf */
  (unsigned char*)"\xf3",  /* 0xd0 */
  (unsigned char*)"\xee",  /* 0xd1 */
  (unsigned char*)"\xe0\xf0",  /* 0xd2 */
  (unsigned char*)"\xea",  /* 0xd3 */
  (unsigned char*)".",  /* 0xdf */
  (unsigned char*)".\xeb\xed\xf2\xe2\xf0\xec\xea\xf1\xe4\xba\xe7\xe9\xf8\xf5\xf7\xe1\xfe\xef\xe3\xe6\xf6\xbf\xf4",  /* 0xe0 */
  (unsigned char*)"\xf3\xe0\xee\xb3\xe8\xe5\xeb\xf0.\xed",  /* 0xe1 */
  (unsigned char*)".\xe8\xe0\xb3\xee\xe5\xf1\xed\xf3\xeb\xe6\xf7\xf2\xf8\xe4\xea",  /* 0xe2 */
  (unsigned char*)"\xee\xe0\xf0\xf3\xeb\xb3\xe8.\xe5",  /* 0xe3 */
  (unsigned char*)"\xee\xe8\xe0\xe5\xed.\xb3\xf3\xf0\xe2\xea\xeb\xff\xf1\xe6",  /* 0xe4 */
  (unsigned char*)".\xf0\xed\xf1\xeb\xf2\xec\xe7\xea\xe4\xe2\xef\xe1\xe9\xf7\xe6\xf6\xe3\xee",  /* 0xe5 */
  (unsigned char*)"\xe5\xed.\xe8\xe0\xf3",  /* 0xe6 */
  (unsigned char*)"\xe0.\xed\xe2\xf3\xe8\xee\xe4\xe5\xb3\xec\xf0\xeb",  /* 0xe7 */
  (unsigned char*)".\xf2\xed\xf1\xec\xe9\xe2\xf5\xea\xeb\xf7\xf0\xe4\xf6\xf8\xef\xe1\xe7\xe3",  /* 0xe8 */
  (unsigned char*)".\xee\xed\xf1\xf2",  /* 0xe9 */
  (unsigned char*)"\xee\xe0\xe8.\xf3\xf0\xb3\xeb\xf2\xe5\xf1\xed",  /* 0xea */
  (unsigned char*)"\xe8\xe0\xee\xfc\xe5\xb3\xff\xfe\xf3.",  /* 0xeb */
  (unsigned char*)".\xe0\xe8\xee\xb3\xf3\xe5\xed",  /* 0xec */
  (unsigned char*)"\xe0\xee\xe5\xe8\xb3\xff\xed\xf3.\xfc\xea\xf2\xf6\xf1\xe4\xfe",  /* 0xed */
  (unsigned char*)".\xe2\xf0\xe3\xeb\xec\xe4\xf1\xed\xe1\xea\xf2\xe7\xf7\xbf\xfe\xe6\xef\xf5\xf8\xf6",  /* 0xee */
  (unsigned char*)"\xee\xf0\xe0\xe5\xb3\xe8\xeb\xf3.",  /* 0xef */
  (unsigned char*)"\xee\xe0\xe8\xe5\xf3\xb3.\xf2\xed\xff\xea\xf1\xe3\xec\xe2",  /* 0xf0 */
  (unsigned char*)"\xf2\xff\xfc\xe8\xb3\xee\xea\xe0\xef\xe5\xe2\xeb.\xed\xf3\xec",  /* 0xf1 */
  (unsigned char*)"\xe8\xe0\xfc\xee\xe5\xb3\xf0\xf3.\xe2\xff\xed\xea\xf2\xeb",  /* 0xf2 */
  (unsigned char*)".\xe2\xe4\xf2\xf1\xea\xeb\xec\xf0\xf5\xba\xef\xf8\xe6\xf7\xe3\xed\xe1\xe7\xfe",  /* 0xf3 */
  (unsigned char*)"\xb3.\xee\xe0",  /* 0xf4 */
  (unsigned char*)".\xee\xe0\xe8\xb3\xf3",  /* 0xf5 */
  (unsigned char*)"\xb3\xe5\xfc\xff\xfe",  /* 0xf6 */
  (unsigned char*)"\xe8\xe5\xe0\xed\xee\xb3\xf3\xea.",  /* 0xf7 */
  (unsigned char*)"\xe8\xe5\xe0\xea\xed.\xf3\xee\xb3\xf2\xeb",  /* 0xf8 */
  (unsigned char*)"\xee\xe5\xe0",  /* 0xf9 */
  (unsigned char*)".\xea\xf1\xed\xee\xf4",  /* 0xfc */
  (unsigned char*)".\xf2\xf7\xe4",  /* 0xfe */
  (unsigned char*)".\xea\xf2\xf7\xec\xe4\xed\xe2\xe3\xba",  /* 0xff */
};


/* THIS IS A GENERATED TABLE, see data/basetoc.c. */
static const unsigned short int RAW_IBM855[] = {
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x00 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x08 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x10 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x18 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x20 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x28 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x30 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x38 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x40 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x48 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x50 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x58 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x60 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x68 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x70 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x78 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x80 */
     0,    0, 3416,    0,  587,    0,    0,    0,  /* 0x88 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x90 */
     0,    0,    0,    0,  424,    0,    0,    0,  /* 0x98 */
  5321,    0,  774,    0,  507,    0, 1857,    0,  /* 0xa0 */
  3140,    0,  275,    0,  922,    0,    0,    0,  /* 0xa8 */
     0,    0,    0,    0,    0,  596,    0, 3981,  /* 0xb0 */
     0,    0,    0,    0,    0,  688,    0,    0,  /* 0xb8 */
     0,    0,    0,    0,    0,    0, 2410,    0,  /* 0xc0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xc8 */
  2105,    0, 1772,    0, 4802,    0, 5884,    0,  /* 0xd0 */
  1587,    0,    0,    0,    0,  254, 1401,    0,  /* 0xd8 */
     0, 3331,    0, 2738,    0, 3518,    0, 1924,  /* 0xe0 */
     0,  485,    0, 3238,  274, 1116,    0,    0,  /* 0xe8 */
     0,    0,    0, 1219,    0,  362,    0,    0,  /* 0xf0 */
     0,    0,    0,  762,    0,    0,    0,    0,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char LETTER_IBM855[] = {
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x00 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x08 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x10 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x18 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x20 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x28 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x30 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x38 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x40 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x48 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x50 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x58 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x60 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x68 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x70 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x78 */
  255, 255, 255, 255, 255, 255,   3, 255,  /* 0x80 */
  255, 255,   2,   1,   4, 255, 255, 255,  /* 0x88 */
  255, 255, 255, 255, 255,   0, 255, 255,  /* 0x90 */
  255, 255, 255, 255,  47, 255, 255, 255,  /* 0x98 */
   20,   5,  21,   6,  42, 255,  24,   8,  /* 0xa0 */
   25,   9,  40, 255,  23, 255,   0,   0,  /* 0xa8 */
    0,   0,   0,   0,   0,  41, 255,  28,  /* 0xb0 */
  255,   0,   0,   0,   0,  29, 255,   0,  /* 0xb8 */
    0,   0,   0,   0,   0,   0,  30,  11,  /* 0xc0 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0xc8 */
   31, 255,  32,  12,  33,  13,  34, 255,  /* 0xd0 */
   35,   0,   0,   0,   0,  14,  48,   0,  /* 0xd8 */
   19,  36,  15,  37,  16,  38,  17,  39,  /* 0xe0 */
   18,  26, 255,  22,   7,  46, 255,   0,  /* 0xe8 */
    0, 255, 255,  27,  10,  44, 255, 255,  /* 0xf0 */
  255,  45, 255,  43, 255,   0,   0,   0,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char *PAIR_IBM855[] = {

  (unsigned char*)"\xeb\xd8\xd4\xe3\xf3\xe5\xa6\xd2\xc6\xa2\xe1\xd6\xac\x8a\xbd\xde\xe7\xd0\xfb\xf9\xec\xa0\xdd\xa4\xb5\xe9\xd5\xa1\xd3\xe6\xd7\xe4\x8c\xc7\xa3\x8b\xe2\xf5\xa7\xad\xf4\xaa\xe8\xe0\xb6\x86\xfc\xa9\xa8\xf6\xd1\xa5\xab",  /* FILLCHAR */
  (unsigned char*)".",  /* 0x8b */
  (unsigned char*)".\xa6\xeb\xd0\xd4\xe5\xe3\xbd\xf3\xd2\xc6\xde\xfb\xe1\xf5\x8c\x86\xb5\xa2\xe9\xac\xd6\x9c\xa0",  /* 0x8a */
  (unsigned char*)".\xe5",  /* 0x86 */
  (unsigned char*)".\xd4\xb5\x8c",  /* 0x8c */
  (unsigned char*)".\xd0",  /* 0xa1 */
  (unsigned char*)"\xa0",  /* 0xa3 */
  (unsigned char*)"\xb7\xd6\x8a.",  /* 0xec */
  (unsigned char*)"\xd6",  /* 0xa7 */
  (unsigned char*)"\xd0",  /* 0xa9 */
  (unsigned char*)"\xa0",  /* 0xf4 */
  (unsigned char*)"\xd6",  /* 0xc7 */
  (unsigned char*)"\xa0\xd6",  /* 0xd3 */
  (unsigned char*)"\xa0\xa8",  /* 0xd5 */
  (unsigned char*)"\xe1\xd6",  /* 0xdd */
  (unsigned char*)"\xe7",  /* 0xe2 */
  (unsigned char*)"\xd6",  /* 0xe4 */
  (unsigned char*)"\xa0\xe1",  /* 0xe6 */
  (unsigned char*)"\xc6",  /* 0xe8 */
  (unsigned char*)".",  /* 0xe0 */
  (unsigned char*)".\xd0\xd4\xe5\xeb\xe1\xd2\xc6\xe3\xa6\x86\xf3\xbd\xf5\xb5\xfb\xa2\x9c\xd8\xac\xe9\xa4\x8c\xaa",  /* 0xa0 */
  (unsigned char*)"\xe7\xa0\xd6\x8a\xb7\xa8\xd0\xe1.\xd4",  /* 0xa2 */
  (unsigned char*)".\xb7\xa0\x8a\xd6\xa8\xe3\xd4\xe7\xd0\xe9\xfb\xe5\xf5\xa6\xc6",  /* 0xeb */
  (unsigned char*)"\xd6\xa0\xe1\xe7\xd0\x8a\xb7.\xa8",  /* 0xac */
  (unsigned char*)"\xd6\xb7\xa0\xa8\xd4.\x8a\xe7\xe1\xeb\xc6\xd0\xde\xe3\xe9",  /* 0xa6 */
  (unsigned char*)".\xe1\xd4\xe3\xd0\xe5\xd2\xf3\xc6\xa6\xeb\xd8\xa2\xbd\xfb\xe9\xa4\xac\xd6",  /* 0xa8 */
  (unsigned char*)"\xa8\xd4.\xb7\xa0\xe7",  /* 0xe9 */
  (unsigned char*)"\xa0.\xd4\xeb\xe7\xb7\xd6\xa6\xa8\x8a\xd2\xe1\xd0",  /* 0xf3 */
  (unsigned char*)".\xe5\xd4\xe3\xd2\xbd\xeb\xb5\xc6\xd0\xfb\xe1\xa6\xa4\xf5\xd8\xa2\xf3\xac",  /* 0xb7 */
  (unsigned char*)".\xd6\xd4\xe3\xe5",  /* 0xbd */
  (unsigned char*)"\xd6\xa0\xb7.\xe7\xe1\x8a\xd0\xe5\xa8\xe3\xd4",  /* 0xc6 */
  (unsigned char*)"\xb7\xa0\xd6\xed\xa8\x8a\xde\x9c\xe7.",  /* 0xd0 */
  (unsigned char*)".\xa0\xb7\xd6\x8a\xe7\xa8\xd4",  /* 0xd2 */
  (unsigned char*)"\xa0\xd6\xa8\xb7\x8a\xde\xd4\xe7.\xed\xc6\xe5\xa4\xe3\xa6\x9c",  /* 0xd4 */
  (unsigned char*)".\xeb\xe1\xac\xd0\xd2\xa6\xe3\xd4\xa2\xc6\xe5\xf3\xfb\x8c\x9c\xe9\xd8\xb5\xf5\xa4",  /* 0xd6 */
  (unsigned char*)"\xd6\xe1\xa0\xa8\x8a\xb7\xd0\xe7.",  /* 0xd8 */
  (unsigned char*)"\xd6\xa0\xb7\xa8\xe7\x8a.\xe5\xd4\xde\xc6\xe3\xac\xd2\xeb",  /* 0xe1 */
  (unsigned char*)"\xe5\xde\xed\xb7\x8a\xd6\xc6\xa0\xd8\xa8\xeb\xd0.\xd4\xe7\xd2",  /* 0xe3 */
  (unsigned char*)"\xb7\xa0\xed\xd6\xa8\x8a\xe1\xe7.\xeb\xde\xd4\xc6\xe5\xd0",  /* 0xe5 */
  (unsigned char*)".\xeb\xa6\xe5\xe3\xc6\xd0\xd2\xe1\xb5\x86\xd8\xf5\xe9\xfb\xac\xd4\xa2\xf3\x9c",  /* 0xe7 */
  (unsigned char*)"\x8a.\xd6\xa0",  /* 0xaa */
  (unsigned char*)".\xd6\xa0\xb7\x8a\xe7",  /* 0xb5 */
  (unsigned char*)"\x8a\xa8\xed\xde\x9c",  /* 0xa4 */
  (unsigned char*)"\xb7\xa8\xa0\xd4\xd6\x8a\xe7\xc6.",  /* 0xfb */
  (unsigned char*)"\xb7\xa8\xa0\xc6\xd4.\xe7\xd6\x8a\xe5\xd0",  /* 0xf5 */
  (unsigned char*)"\xd6\xa8\xa0",  /* 0xf9 */
  (unsigned char*)".\xc6\xe3\xd4\xd6\xaa",  /* 0xed */
  (unsigned char*)".\xe5\xfb\xa6",  /* 0x9c */
  (unsigned char*)".\xc6\xe5\xfb\xd2\xa6\xd4\xeb\xac\x86",  /* 0xde */
};


/* THIS IS A GENERATED TABLE, see data/basetoc.c. */
static const unsigned short int RAW_ISO88595[] = {
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x00 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x08 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x10 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x18 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x20 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x28 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x30 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x38 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x40 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x48 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x50 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x58 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x60 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x68 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x70 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x78 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x80 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x88 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x90 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x98 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xa0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xa8 */
     0,    0,  274,    0,    0,    0,    0,    0,  /* 0xb0 */
     0,    0,    0,    0,    0,    0,    0,  254,  /* 0xb8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xc0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xc8 */
  5321,  774, 3238,  922, 1857, 3140,  485, 1219,  /* 0xd0 */
  3981,  688, 2410, 2105, 1772, 4802, 5884, 1587,  /* 0xd8 */
  3331, 2738, 3518, 1924,  275,  596,  507,  762,  /* 0xe0 */
   362,    0,    0,    0, 1116,    0,  424, 1401,  /* 0xe8 */
     0,    0,    0,    0,    0,    0, 3416,  587,  /* 0xf0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char LETTER_ISO88595[] = {
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x00 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x08 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x10 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x18 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x20 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x28 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x30 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x38 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x40 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x48 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x50 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x58 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x60 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x68 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x70 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x78 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x80 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x88 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x90 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x98 */
    0, 255, 255, 255, 255, 255,   1, 255,  /* 0xa0 */
  255, 255, 255, 255, 255,   0, 255, 255,  /* 0xa8 */
    5,   6,   7, 255,   8,   9, 255,  10,  /* 0xb0 */
  255, 255,  11, 255,  12,  13, 255,  14,  /* 0xb8 */
   15,  16,  17,  18, 255, 255, 255, 255,  /* 0xc0 */
  255, 255, 255, 255, 255, 255, 255,  19,  /* 0xc8 */
   20,  21,  22,  23,  24,  25,  26,  27,  /* 0xd0 */
   28,  29,  30,  31,  32,  33,  34,  35,  /* 0xd8 */
   36,  37,  38,  39,  40,  41,  42,  43,  /* 0xe0 */
   44,  45, 255, 255,  46, 255,  47,  48,  /* 0xe8 */
    0, 255, 255, 255,   3, 255,   2,   4,  /* 0xf0 */
  255, 255, 255, 255, 255,   0, 255, 255,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char *PAIR_ISO88595[] = {

  (unsigned char*)"\xd2\xdf\xdd\xe1\xd7\xe2\xd4\xdc\xda\xd1\xe0\xde\xd3\xf6\xd9\xef\xe3\xdb\xe7\xe9\xb2\xd0\xbf\xe6\xe5\xd6\xbd\xb0\xbc\xc2\xbe\xc1\xf7\xba\xb1\xa6\xc0\xe8\xb4\xb3\xb7\xe4\xc3\xcf\xc5\xf4\xc7\xb5\xd5\xc8\xbb\xc6\xc4",  /* FILLCHAR */
  (unsigned char*)".",  /* 0xa6 */
  (unsigned char*)".\xd4\xd2\xdb\xdd\xe2\xe1\xd9\xd7\xdc\xda\xef\xe7\xe0\xe8\xf7\xf4\xe5\xd1\xd6\xd3\xde\xee\xd0",  /* 0xf6 */
  (unsigned char*)".\xe2",  /* 0xf4 */
  (unsigned char*)".\xdd\xe5\xf7",  /* 0xf7 */
  (unsigned char*)".\xdb",  /* 0xb0 */
  (unsigned char*)"\xd0",  /* 0xb1 */
  (unsigned char*)"\xd8\xde\xf6.",  /* 0xb2 */
  (unsigned char*)"\xde",  /* 0xb4 */
  (unsigned char*)"\xdb",  /* 0xb5 */
  (unsigned char*)"\xd0",  /* 0xb7 */
  (unsigned char*)"\xde",  /* 0xba */
  (unsigned char*)"\xd0\xde",  /* 0xbc */
  (unsigned char*)"\xd0\xd5",  /* 0xbd */
  (unsigned char*)"\xe0\xde",  /* 0xbf */
  (unsigned char*)"\xe3",  /* 0xc0 */
  (unsigned char*)"\xde",  /* 0xc1 */
  (unsigned char*)"\xd0\xe0",  /* 0xc2 */
  (unsigned char*)"\xda",  /* 0xc3 */
  (unsigned char*)".",  /* 0xcf */
  (unsigned char*)".\xdb\xdd\xe2\xd2\xe0\xdc\xda\xe1\xd4\xf4\xd7\xd9\xe8\xe5\xe7\xd1\xee\xdf\xd3\xd6\xe6\xf7\xe4",  /* 0xd0 */
  (unsigned char*)"\xe3\xd0\xde\xf6\xd8\xd5\xdb\xe0.\xdd",  /* 0xd1 */
  (unsigned char*)".\xd8\xd0\xf6\xde\xd5\xe1\xdd\xe3\xdb\xd6\xe7\xe2\xe8\xd4\xda",  /* 0xd2 */
  (unsigned char*)"\xde\xd0\xe0\xe3\xdb\xf6\xd8.\xd5",  /* 0xd3 */
  (unsigned char*)"\xde\xd8\xd0\xd5\xdd.\xf6\xe3\xe0\xd2\xda\xdb\xef\xe1\xd6",  /* 0xd4 */
  (unsigned char*)".\xe0\xdd\xe1\xdb\xe2\xdc\xd7\xda\xd4\xd2\xdf\xd1\xd9\xe7\xd6\xe6\xd3\xde",  /* 0xd5 */
  (unsigned char*)"\xd5\xdd.\xd8\xd0\xe3",  /* 0xd6 */
  (unsigned char*)"\xd0.\xdd\xd2\xe3\xd8\xde\xd4\xd5\xf6\xdc\xe0\xdb",  /* 0xd7 */
  (unsigned char*)".\xe2\xdd\xe1\xdc\xd9\xd2\xe5\xda\xdb\xe7\xe0\xd4\xe6\xe8\xdf\xd1\xd7\xd3",  /* 0xd8 */
  (unsigned char*)".\xde\xdd\xe1\xe2",  /* 0xd9 */
  (unsigned char*)"\xde\xd0\xd8.\xe3\xe0\xf6\xdb\xe2\xd5\xe1\xdd",  /* 0xda */
  (unsigned char*)"\xd8\xd0\xde\xec\xd5\xf6\xef\xee\xe3.",  /* 0xdb */
  (unsigned char*)".\xd0\xd8\xde\xf6\xe3\xd5\xdd",  /* 0xdc */
  (unsigned char*)"\xd0\xde\xd5\xd8\xf6\xef\xdd\xe3.\xec\xda\xe2\xe6\xe1\xd4\xee",  /* 0xdd */
  (unsigned char*)".\xd2\xe0\xd3\xdb\xdc\xd4\xe1\xdd\xd1\xda\xe2\xd7\xe7\xf7\xee\xd6\xdf\xe5\xe8\xe6",  /* 0xde */
  (unsigned char*)"\xde\xe0\xd0\xd5\xf6\xd8\xdb\xe3.",  /* 0xdf */
  (unsigned char*)"\xde\xd0\xd8\xd5\xe3\xf6.\xe2\xdd\xef\xda\xe1\xd3\xdc\xd2",  /* 0xe0 */
  (unsigned char*)"\xe2\xef\xec\xd8\xf6\xde\xda\xd0\xdf\xd5\xd2\xdb.\xdd\xe3\xdc",  /* 0xe1 */
  (unsigned char*)"\xd8\xd0\xec\xde\xd5\xf6\xe0\xe3.\xd2\xef\xdd\xda\xe2\xdb",  /* 0xe2 */
  (unsigned char*)".\xd2\xd4\xe2\xe1\xda\xdb\xdc\xe0\xe5\xf4\xdf\xe8\xd6\xe7\xd3\xdd\xd1\xd7\xee",  /* 0xe3 */
  (unsigned char*)"\xf6.\xde\xd0",  /* 0xe4 */
  (unsigned char*)".\xde\xd0\xd8\xf6\xe3",  /* 0xe5 */
  (unsigned char*)"\xf6\xd5\xec\xef\xee",  /* 0xe6 */
  (unsigned char*)"\xd8\xd5\xd0\xdd\xde\xf6\xe3\xda.",  /* 0xe7 */
  (unsigned char*)"\xd8\xd5\xd0\xda\xdd.\xe3\xde\xf6\xe2\xdb",  /* 0xe8 */
  (unsigned char*)"\xde\xd5\xd0",  /* 0xe9 */
  (unsigned char*)".\xda\xe1\xdd\xde\xe4",  /* 0xec */
  (unsigned char*)".\xe2\xe7\xd4",  /* 0xee */
  (unsigned char*)".\xda\xe2\xe7\xdc\xd4\xdd\xd2\xd3\xf4",  /* 0xef */
};


/* THIS IS A GENERATED TABLE, see data/basetoc.c. */
static const unsigned short int RAW_CP1125[] = {
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x00 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x08 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x10 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x18 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x20 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x28 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x30 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x38 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x40 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x48 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x50 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x58 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x60 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x68 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x70 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x78 */
     0,    0,  274,    0,    0,    0,    0,    0,  /* 0x80 */
     0,    0,    0,    0,    0,    0,    0,  254,  /* 0x88 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x90 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x98 */
  5321,  774, 3238,  922, 1857, 3140,  485, 1219,  /* 0xa0 */
  3981,  688, 2410, 2105, 1772, 4802, 5884, 1587,  /* 0xa8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xb0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xb8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xc0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xc8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xd0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xd8 */
  3331, 2738, 3518, 1924,  275,  596,  507,  762,  /* 0xe0 */
   362,    0,    0,    0, 1116,    0,  424, 1401,  /* 0xe8 */
     0,    0,    0,    0,    0,    0,    0, 3416,  /* 0xf0 */
     0,  587,    0,    0,    0,    0,    0,    0,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char LETTER_CP1125[] = {
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x00 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x08 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x10 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x18 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x20 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x28 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x30 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x38 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x40 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x48 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x50 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x58 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x60 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x68 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x70 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x78 */
    5,   6,   7, 255,   8,   9, 255,  10,  /* 0x80 */
  255, 255,  11, 255,  12,  13, 255,  14,  /* 0x88 */
   15,  16,  17,  18, 255, 255, 255, 255,  /* 0x90 */
  255, 255, 255, 255, 255, 255, 255,  19,  /* 0x98 */
   20,  21,  22,  23,  24,  25,  26,  27,  /* 0xa0 */
   28,  29,  30,  31,  32,  33,  34,  35,  /* 0xa8 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0xb0 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0xb8 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0xc0 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0xc8 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0xd0 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0xd8 */
   36,  37,  38,  39,  40,  41,  42,  43,  /* 0xe0 */
   44,  45, 255, 255,  46, 255,  47,  48,  /* 0xe8 */
  255, 255, 255, 255, 255,   3,   1,   2,  /* 0xf0 */
  255,   4,   0,   0,   0,   0,   0,   0,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char *PAIR_CP1125[] = {

  (unsigned char*)"\xa2\xaf\xad\xe1\xa7\xe2\xa4\xac\xaa\xa1\xe0\xae\xa3\xf7\xa9\xef\xe3\xab\xe7\xe9\x82\xa0\x8f\xe6\xe5\xa6\x8d\x80\x8c\x92\x8e\x91\xf9\x8a\x81\xf6\x90\xe8\x84\x83\x87\xe4\x93\x9f\x95\xf5\x97\x85\xa5\x98\x8b\x96\x94",  /* FILLCHAR */
  (unsigned char*)".",  /* 0xf6 */
  (unsigned char*)".\xa4\xa2\xab\xad\xe2\xe1\xa9\xa7\xac\xaa\xef\xe7\xe0\xe8\xf9\xf5\xe5\xa1\xa6\xa3\xae\xee\xa0",  /* 0xf7 */
  (unsigned char*)".\xe2",  /* 0xf5 */
  (unsigned char*)".\xad\xe5\xf9",  /* 0xf9 */
  (unsigned char*)".\xab",  /* 0x80 */
  (unsigned char*)"\xa0",  /* 0x81 */
  (unsigned char*)"\xa8\xae\xf7.",  /* 0x82 */
  (unsigned char*)"\xae",  /* 0x84 */
  (unsigned char*)"\xab",  /* 0x85 */
  (unsigned char*)"\xa0",  /* 0x87 */
  (unsigned char*)"\xae",  /* 0x8a */
  (unsigned char*)"\xa0\xae",  /* 0x8c */
  (unsigned char*)"\xa0\xa5",  /* 0x8d */
  (unsigned char*)"\xe0\xae",  /* 0x8f */
  (unsigned char*)"\xe3",  /* 0x90 */
  (unsigned char*)"\xae",  /* 0x91 */
  (unsigned char*)"\xa0\xe0",  /* 0x92 */
  (unsigned char*)"\xaa",  /* 0x93 */
  (unsigned char*)".",  /* 0x9f */
  (unsigned char*)".\xab\xad\xe2\xa2\xe0\xac\xaa\xe1\xa4\xf5\xa7\xa9\xe8\xe5\xe7\xa1\xee\xaf\xa3\xa6\xe6\xf9\xe4",  /* 0xa0 */
  (unsigned char*)"\xe3\xa0\xae\xf7\xa8\xa5\xab\xe0.\xad",  /* 0xa1 */
  (unsigned char*)".\xa8\xa0\xf7\xae\xa5\xe1\xad\xe3\xab\xa6\xe7\xe2\xe8\xa4\xaa",  /* 0xa2 */
  (unsigned char*)"\xae\xa0\xe0\xe3\xab\xf7\xa8.\xa5",  /* 0xa3 */
  (unsigned char*)"\xae\xa8\xa0\xa5\xad.\xf7\xe3\xe0\xa2\xaa\xab\xef\xe1\xa6",  /* 0xa4 */
  (unsigned char*)".\xe0\xad\xe1\xab\xe2\xac\xa7\xaa\xa4\xa2\xaf\xa1\xa9\xe7\xa6\xe6\xa3\xae",  /* 0xa5 */
  (unsigned char*)"\xa5\xad.\xa8\xa0\xe3",  /* 0xa6 */
  (unsigned char*)"\xa0.\xad\xa2\xe3\xa8\xae\xa4\xa5\xf7\xac\xe0\xab",  /* 0xa7 */
  (unsigned char*)".\xe2\xad\xe1\xac\xa9\xa2\xe5\xaa\xab\xe7\xe0\xa4\xe6\xe8\xaf\xa1\xa7\xa3",  /* 0xa8 */
  (unsigned char*)".\xae\xad\xe1\xe2",  /* 0xa9 */
  (unsigned char*)"\xae\xa0\xa8.\xe3\xe0\xf7\xab\xe2\xa5\xe1\xad",  /* 0xaa */
  (unsigned char*)"\xa8\xa0\xae\xec\xa5\xf7\xef\xee\xe3.",  /* 0xab */
  (unsigned char*)".\xa0\xa8\xae\xf7\xe3\xa5\xad",  /* 0xac */
  (unsigned char*)"\xa0\xae\xa5\xa8\xf7\xef\xad\xe3.\xec\xaa\xe2\xe6\xe1\xa4\xee",  /* 0xad */
  (unsigned char*)".\xa2\xe0\xa3\xab\xac\xa4\xe1\xad\xa1\xaa\xe2\xa7\xe7\xf9\xee\xa6\xaf\xe5\xe8\xe6",  /* 0xae */
  (unsigned char*)"\xae\xe0\xa0\xa5\xf7\xa8\xab\xe3.",  /* 0xaf */
  (unsigned char*)"\xae\xa0\xa8\xa5\xe3\xf7.\xe2\xad\xef\xaa\xe1\xa3\xac\xa2",  /* 0xe0 */
  (unsigned char*)"\xe2\xef\xec\xa8\xf7\xae\xaa\xa0\xaf\xa5\xa2\xab.\xad\xe3\xac",  /* 0xe1 */
  (unsigned char*)"\xa8\xa0\xec\xae\xa5\xf7\xe0\xe3.\xa2\xef\xad\xaa\xe2\xab",  /* 0xe2 */
  (unsigned char*)".\xa2\xa4\xe2\xe1\xaa\xab\xac\xe0\xe5\xf5\xaf\xe8\xa6\xe7\xa3\xad\xa1\xa7\xee",  /* 0xe3 */
  (unsigned char*)"\xf7.\xae\xa0",  /* 0xe4 */
  (unsigned char*)".\xae\xa0\xa8\xf7\xe3",  /* 0xe5 */
  (unsigned char*)"\xf7\xa5\xec\xef\xee",  /* 0xe6 */
  (unsigned char*)"\xa8\xa5\xa0\xad\xae\xf7\xe3\xaa.",  /* 0xe7 */
  (unsigned char*)"\xa8\xa5\xa0\xaa\xad.\xe3\xae\xf7\xe2\xab",  /* 0xe8 */
  (unsigned char*)"\xae\xa5\xa0",  /* 0xe9 */
  (unsigned char*)".\xaa\xe1\xad\xae\xe4",  /* 0xec */
  (unsigned char*)".\xe2\xe7\xa4",  /* 0xee */
  (unsigned char*)".\xaa\xe2\xe7\xac\xa4\xad\xa2\xa3\xf5",  /* 0xef */
};


/* THIS IS A GENERATED TABLE, see data/basetoc.c. */
static const unsigned short int RAW_KOI8U[] = {
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x00 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x08 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x10 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x18 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x20 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x28 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x30 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x38 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x40 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x48 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x50 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x58 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x60 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x68 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x70 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x78 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x80 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x88 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x90 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x98 */
     0,    0,    0,    0,    0,    0, 3416,  587,  /* 0xa0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xa8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xb0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xb8 */
   424, 5321,  774,  507, 1857, 3140,  275,  922,  /* 0xc0 */
   596, 3981,  688, 2410, 2105, 1772, 4802, 5884,  /* 0xc8 */
  1587, 1401, 3331, 2738, 3518, 1924,  485, 3238,  /* 0xd0 */
  1116,    0, 1219,  362,    0,    0,  762,    0,  /* 0xd8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xe0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xe8 */
   254,    0,    0,    0,    0,    0,    0,  274,  /* 0xf0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char LETTER_KOI8U[] = {
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x00 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x08 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x10 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x18 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x20 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x28 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x30 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x38 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x40 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x48 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x50 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x58 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x60 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x68 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x70 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x78 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x80 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x88 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x90 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x98 */
    0,   0,   0, 255,   3,   0,   2,   4,  /* 0xa0 */
    0,   0,   0,   0,   0, 255,   0,   0,  /* 0xa8 */
    0,   0,   0, 255, 255,   0,   1, 255,  /* 0xb0 */
    0,   0,   0,   0,   0, 255,   0,   0,  /* 0xb8 */
   47,  20,  21,  42,  24,  25,  40,  23,  /* 0xc0 */
   41,  28,  29,  30,  31,  32,  33,  34,  /* 0xc8 */
   35,  48,  36,  37,  38,  39,  26,  22,  /* 0xd0 */
   46, 255,  27,  44, 255,  45,  43, 255,  /* 0xd8 */
  255,   5,   6, 255,   8,   9, 255, 255,  /* 0xe0 */
  255, 255, 255,  11, 255,  12,  13, 255,  /* 0xe8 */
   14,  19,  15,  16,  17,  18, 255,   7,  /* 0xf0 */
  255, 255,  10, 255, 255, 255, 255, 255,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char *PAIR_KOI8U[] = {

  (unsigned char*)"\xd7\xd0\xce\xd3\xda\xd4\xc4\xcd\xcb\xc2\xd2\xcf\xc7\xa6\xca\xd1\xd5\xcc\xde\xdd\xf7\xc1\xf0\xc3\xc8\xd6\xee\xe1\xed\xf4\xef\xf3\xa7\xeb\xe2\xb6\xf2\xdb\xe4\xe7\xfa\xc6\xf5\xf1\xe8\xa4\xfe\xe5\xc5\xfb\xec\xe3\xe6",  /* FILLCHAR */
  (unsigned char*)".",  /* 0xb6 */
  (unsigned char*)".\xc4\xd7\xcc\xce\xd4\xd3\xca\xda\xcd\xcb\xd1\xde\xd2\xdb\xa7\xa4\xc8\xc2\xd6\xc7\xcf\xc0\xc1",  /* 0xa6 */
  (unsigned char*)".\xd4",  /* 0xa4 */
  (unsigned char*)".\xce\xc8\xa7",  /* 0xa7 */
  (unsigned char*)".\xcc",  /* 0xe1 */
  (unsigned char*)"\xc1",  /* 0xe2 */
  (unsigned char*)"\xc9\xcf\xa6.",  /* 0xf7 */
  (unsigned char*)"\xcf",  /* 0xe4 */
  (unsigned char*)"\xcc",  /* 0xe5 */
  (unsigned char*)"\xc1",  /* 0xfa */
  (unsigned char*)"\xcf",  /* 0xeb */
  (unsigned char*)"\xc1\xcf",  /* 0xed */
  (unsigned char*)"\xc1\xc5",  /* 0xee */
  (unsigned char*)"\xd2\xcf",  /* 0xf0 */
  (unsigned char*)"\xd5",  /* 0xf2 */
  (unsigned char*)"\xcf",  /* 0xf3 */
  (unsigned char*)"\xc1\xd2",  /* 0xf4 */
  (unsigned char*)"\xcb",  /* 0xf5 */
  (unsigned char*)".",  /* 0xf1 */
  (unsigned char*)".\xcc\xce\xd4\xd7\xd2\xcd\xcb\xd3\xc4\xa4\xda\xca\xdb\xc8\xde\xc2\xc0\xd0\xc7\xd6\xc3\xa7\xc6",  /* 0xc1 */
  (unsigned char*)"\xd5\xc1\xcf\xa6\xc9\xc5\xcc\xd2.\xce",  /* 0xc2 */
  (unsigned char*)".\xc9\xc1\xa6\xcf\xc5\xd3\xce\xd5\xcc\xd6\xde\xd4\xdb\xc4\xcb",  /* 0xd7 */
  (unsigned char*)"\xcf\xc1\xd2\xd5\xcc\xa6\xc9.\xc5",  /* 0xc7 */
  (unsigned char*)"\xcf\xc9\xc1\xc5\xce.\xa6\xd5\xd2\xd7\xcb\xcc\xd1\xd3\xd6",  /* 0xc4 */
  (unsigned char*)".\xd2\xce\xd3\xcc\xd4\xcd\xda\xcb\xc4\xd7\xd0\xc2\xca\xde\xd6\xc3\xc7\xcf",  /* 0xc5 */
  (unsigned char*)"\xc5\xce.\xc9\xc1\xd5",  /* 0xd6 */
  (unsigned char*)"\xc1.\xce\xd7\xd5\xc9\xcf\xc4\xc5\xa6\xcd\xd2\xcc",  /* 0xda */
  (unsigned char*)".\xd4\xce\xd3\xcd\xca\xd7\xc8\xcb\xcc\xde\xd2\xc4\xc3\xdb\xd0\xc2\xda\xc7",  /* 0xc9 */
  (unsigned char*)".\xcf\xce\xd3\xd4",  /* 0xca */
  (unsigned char*)"\xcf\xc1\xc9.\xd5\xd2\xa6\xcc\xd4\xc5\xd3\xce",  /* 0xcb */
  (unsigned char*)"\xc9\xc1\xcf\xd8\xc5\xa6\xd1\xc0\xd5.",  /* 0xcc */
  (unsigned char*)".\xc1\xc9\xcf\xa6\xd5\xc5\xce",  /* 0xcd */
  (unsigned char*)"\xc1\xcf\xc5\xc9\xa6\xd1\xce\xd5.\xd8\xcb\xd4\xc3\xd3\xc4\xc0",  /* 0xce */
  (unsigned char*)".\xd7\xd2\xc7\xcc\xcd\xc4\xd3\xce\xc2\xcb\xd4\xda\xde\xa7\xc0\xd6\xd0\xc8\xdb\xc3",  /* 0xcf */
  (unsigned char*)"\xcf\xd2\xc1\xc5\xa6\xc9\xcc\xd5.",  /* 0xd0 */
  (unsigned char*)"\xcf\xc1\xc9\xc5\xd5\xa6.\xd4\xce\xd1\xcb\xd3\xc7\xcd\xd7",  /* 0xd2 */
  (unsigned char*)"\xd4\xd1\xd8\xc9\xa6\xcf\xcb\xc1\xd0\xc5\xd7\xcc.\xce\xd5\xcd",  /* 0xd3 */
  (unsigned char*)"\xc9\xc1\xd8\xcf\xc5\xa6\xd2\xd5.\xd7\xd1\xce\xcb\xd4\xcc",  /* 0xd4 */
  (unsigned char*)".\xd7\xc4\xd4\xd3\xcb\xcc\xcd\xd2\xc8\xa4\xd0\xdb\xd6\xde\xc7\xce\xc2\xda\xc0",  /* 0xd5 */
  (unsigned char*)"\xa6.\xcf\xc1",  /* 0xc6 */
  (unsigned char*)".\xcf\xc1\xc9\xa6\xd5",  /* 0xc8 */
  (unsigned char*)"\xa6\xc5\xd8\xd1\xc0",  /* 0xc3 */
  (unsigned char*)"\xc9\xc5\xc1\xce\xcf\xa6\xd5\xcb.",  /* 0xde */
  (unsigned char*)"\xc9\xc5\xc1\xcb\xce.\xd5\xcf\xa6\xd4\xcc",  /* 0xdb */
  (unsigned char*)"\xcf\xc5\xc1",  /* 0xdd */
  (unsigned char*)".\xcb\xd3\xce\xcf\xc6",  /* 0xd8 */
  (unsigned char*)".\xd4\xde\xc4",  /* 0xc0 */
  (unsigned char*)".\xcb\xd4\xde\xcd\xc4\xce\xd7\xc7\xa4",  /* 0xd1 */
};


/* THIS IS A GENERATED TABLE, see data/basetoc.c. */
static const unsigned short int RAW_MACCYR[] = {
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x00 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x08 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x10 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x18 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x20 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x28 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x30 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x38 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x40 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x48 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x50 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x58 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x60 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x68 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x70 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x78 */
     0,    0,  274,    0,    0,    0,    0,    0,  /* 0x80 */
     0,    0,    0,    0,    0,    0,    0,  254,  /* 0x88 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x90 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x98 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xa0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xa8 */
     0,    0,    0,    0, 3416,    0,    0,    0,  /* 0xb0 */
     0,    0,    0,  587,    0,    0,    0,    0,  /* 0xb8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xc0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xc8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xd0 */
     0,    0,    0,    0,    0,    0,    0, 1401,  /* 0xd8 */
  5321,  774, 3238,  922, 1857, 3140,  485, 1219,  /* 0xe0 */
  3981,  688, 2410, 2105, 1772, 4802, 5884, 1587,  /* 0xe8 */
  3331, 2738, 3518, 1924,  275,  596,  507,  762,  /* 0xf0 */
   362,    0,    0,    0, 1116,    0,  424,    0,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char LETTER_MACCYR[] = {
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x00 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x08 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x10 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x18 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x20 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x28 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x30 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x38 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x40 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x48 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x50 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x58 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x60 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x68 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x70 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x78 */
    5,   6,   7, 255,   8,   9, 255,  10,  /* 0x80 */
  255, 255,  11, 255,  12,  13, 255,  14,  /* 0x88 */
   15,  16,  17,  18, 255, 255, 255, 255,  /* 0x90 */
  255, 255, 255, 255, 255, 255, 255,  19,  /* 0x98 */
    0,   0, 255,   0,   0,   0,   0,   1,  /* 0xa0 */
    0,   0,   0, 255, 255,   0, 255, 255,  /* 0xa8 */
    0,   0,   0,   0,   2,   0, 255, 255,  /* 0xb0 */
  255,   3, 255,   4, 255, 255, 255, 255,  /* 0xb8 */
  255, 255,   0,   0, 255,   0,   0,   0,  /* 0xc0 */
    0,   0,   0, 255, 255, 255, 255, 255,  /* 0xc8 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0xd0 */
  255, 255, 255, 255,   0, 255, 255,  48,  /* 0xd8 */
   20,  21,  22,  23,  24,  25,  26,  27,  /* 0xe0 */
   28,  29,  30,  31,  32,  33,  34,  35,  /* 0xe8 */
   36,  37,  38,  39,  40,  41,  42,  43,  /* 0xf0 */
   44,  45, 255, 255,  46, 255,  47,   0,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char *PAIR_MACCYR[] = {

  (unsigned char*)"\xe2\xef\xed\xf1\xe7\xf2\xe4\xec\xea\xe1\xf0\xee\xe3\xb4\xe9\xdf\xf3\xeb\xf7\xf9\x82\xe0\x8f\xf6\xf5\xe6\x8d\x80\x8c\x92\x8e\x91\xbb\x8a\x81\xa7\x90\xf8\x84\x83\x87\xf4\x93\x9f\x95\xb9\x97\x85\xe5\x98\x8b\x96\x94",  /* FILLCHAR */
  (unsigned char*)".",  /* 0xa7 */
  (unsigned char*)".\xe4\xe2\xeb\xed\xf2\xf1\xe9\xe7\xec\xea\xdf\xf7\xf0\xf8\xbb\xb9\xf5\xe1\xe6\xe3\xee\xfe\xe0",  /* 0xb4 */
  (unsigned char*)".\xf2",  /* 0xb9 */
  (unsigned char*)".\xed\xf5\xbb",  /* 0xbb */
  (unsigned char*)".\xeb",  /* 0x80 */
  (unsigned char*)"\xe0",  /* 0x81 */
  (unsigned char*)"\xe8\xee\xb4.",  /* 0x82 */
  (unsigned char*)"\xee",  /* 0x84 */
  (unsigned char*)"\xeb",  /* 0x85 */
  (unsigned char*)"\xe0",  /* 0x87 */
  (unsigned char*)"\xee",  /* 0x8a */
  (unsigned char*)"\xe0\xee",  /* 0x8c */
  (unsigned char*)"\xe0\xe5",  /* 0x8d */
  (unsigned char*)"\xf0\xee",  /* 0x8f */
  (unsigned char*)"\xf3",  /* 0x90 */
  (unsigned char*)"\xee",  /* 0x91 */
  (unsigned char*)"\xe0\xf0",  /* 0x92 */
  (unsigned char*)"\xea",  /* 0x93 */
  (unsigned char*)".",  /* 0x9f */
  (unsigned char*)".\xeb\xed\xf2\xe2\xf0\xec\xea\xf1\xe4\xb9\xe7\xe9\xf8\xf5\xf7\xe1\xfe\xef\xe3\xe6\xf6\xbb\xf4",  /* 0xe0 */
  (unsigned char*)"\xf3\xe0\xee\xb4\xe8\xe5\xeb\xf0.\xed",  /* 0xe1 */
  (unsigned char*)".\xe8\xe0\xb4\xee\xe5\xf1\xed\xf3\xeb\xe6\xf7\xf2\xf8\xe4\xea",  /* 0xe2 */
  (unsigned char*)"\xee\xe0\xf0\xf3\xeb\xb4\xe8.\xe5",  /* 0xe3 */
  (unsigned char*)"\xee\xe8\xe0\xe5\xed.\xb4\xf3\xf0\xe2\xea\xeb\xdf\xf1\xe6",  /* 0xe4 */
  (unsigned char*)".\xf0\xed\xf1\xeb\xf2\xec\xe7\xea\xe4\xe2\xef\xe1\xe9\xf7\xe6\xf6\xe3\xee",  /* 0xe5 */
  (unsigned char*)"\xe5\xed.\xe8\xe0\xf3",  /* 0xe6 */
  (unsigned char*)"\xe0.\xed\xe2\xf3\xe8\xee\xe4\xe5\xb4\xec\xf0\xeb",  /* 0xe7 */
  (unsigned char*)".\xf2\xed\xf1\xec\xe9\xe2\xf5\xea\xeb\xf7\xf0\xe4\xf6\xf8\xef\xe1\xe7\xe3",  /* 0xe8 */
  (unsigned char*)".\xee\xed\xf1\xf2",  /* 0xe9 */
  (unsigned char*)"\xee\xe0\xe8.\xf3\xf0\xb4\xeb\xf2\xe5\xf1\xed",  /* 0xea */
  (unsigned char*)"\xe8\xe0\xee\xfc\xe5\xb4\xdf\xfe\xf3.",  /* 0xeb */
  (unsigned char*)".\xe0\xe8\xee\xb4\xf3\xe5\xed",  /* 0xec */
  (unsigned char*)"\xe0\xee\xe5\xe8\xb4\xdf\xed\xf3.\xfc\xea\xf2\xf6\xf1\xe4\xfe",  /* 0xed */
  (unsigned char*)".\xe2\xf0\xe3\xeb\xec\xe4\xf1\xed\xe1\xea\xf2\xe7\xf7\xbb\xfe\xe6\xef\xf5\xf8\xf6",  /* 0xee */
  (unsigned char*)"\xee\xf0\xe0\xe5\xb4\xe8\xeb\xf3.",  /* 0xef */
  (unsigned char*)"\xee\xe0\xe8\xe5\xf3\xb4.\xf2\xed\xdf\xea\xf1\xe3\xec\xe2",  /* 0xf0 */
  (unsigned char*)"\xf2\xdf\xfc\xe8\xb4\xee\xea\xe0\xef\xe5\xe2\xeb.\xed\xf3\xec",  /* 0xf1 */
  (unsigned char*)"\xe8\xe0\xfc\xee\xe5\xb4\xf0\xf3.\xe2\xdf\xed\xea\xf2\xeb",  /* 0xf2 */
  (unsigned char*)".\xe2\xe4\xf2\xf1\xea\xeb\xec\xf0\xf5\xb9\xef\xf8\xe6\xf7\xe3\xed\xe1\xe7\xfe",  /* 0xf3 */
  (unsigned char*)"\xb4.\xee\xe0",  /* 0xf4 */
  (unsigned char*)".\xee\xe0\xe8\xb4\xf3",  /* 0xf5 */
  (unsigned char*)"\xb4\xe5\xfc\xdf\xfe",  /* 0xf6 */
  (unsigned char*)"\xe8\xe5\xe0\xed\xee\xb4\xf3\xea.",  /* 0xf7 */
  (unsigned char*)"\xe8\xe5\xe0\xea\xed.\xf3\xee\xb4\xf2\xeb",  /* 0xf8 */
  (unsigned char*)"\xee\xe5\xe0",  /* 0xf9 */
  (unsigned char*)".\xea\xf1\xed\xee\xf4",  /* 0xfc */
  (unsigned char*)".\xf2\xf7\xe4",  /* 0xfe */
  (unsigned char*)".\xea\xf2\xf7\xec\xe4\xed\xe2\xe3\xb9",  /* 0xdf */
};


/* THIS IS A GENERATED TABLE, see data/totals.pl. */
static const unsigned short int SIGNIFICANT[] = {
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x00 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x08 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x10 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x18 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x20 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x28 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x30 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x38 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x40 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x48 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x50 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x58 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x60 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x68 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x70 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x78 */
      0,     0,   548,     0,     0,     0,     0,     0,  /* 0x80 */
      0,     0,  3416,     0,   587,     0,     0,   508,  /* 0x88 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x90 */
      0,     0,     0,     0,   424,     0,     0,     0,  /* 0x98 */
  10642,   774,  4012,   922,  2364,  3140,  5758,  1806,  /* 0xa0 */
   7121,   688,  2685,  2105,  2694,  4802,  5884,  1587,  /* 0xa8 */
      0,     0,   274,  3416,  3416,   596,     0,  3981,  /* 0xb0 */
      0,     0,     0,   587,     0,   688,     0,   841,  /* 0xb8 */
    424,  5321,  1048,   507,  1857,  3140,  2685,   922,  /* 0xc0 */
    596,  3981,   688,  2410,  2105,  1772,  4802,  6138,  /* 0xc8 */
   9013,  2175,  8341,  3660, 10177,  5064,  6854,  4457,  /* 0xd0 */
   6684,   688,  3629,  2467,  1772,  5056,  8047,  2988,  /* 0xd8 */
  17304, 10355, 13512,  8430,  4264, 10990,  1984,  5886,  /* 0xe0 */
   8686,  1861,  4820,  7448,  6050, 10720, 12616,  5976,  /* 0xe8 */
   6916,  5476,  7036,  5067,   550,  1554,  4430,  5801,  /* 0xf0 */
    724,   587,     0,   762,  2232,     0,   848,  1401,  /* 0xf8 */
};

/* THIS IS A GENERATED VALUE, see data/totals.pl */
#define WEIGHT_SUM 61670

/* THIS IS A GENERATED TABLE, see data/totals.pl */
static const char *const CHARSET_NAMES[] = {
  "cp1251",
  "ibm855",
  "iso88595",
  "cp1125",
  "koi8u",
  "maccyr",
};

/* THIS IS A GENERATED TABLE, see data/totals.pl */
static const unsigned short int *const CHARSET_WEIGHTS[] = {
  RAW_CP1251,
  RAW_IBM855,
  RAW_ISO88595,
  RAW_CP1125,
  RAW_KOI8U,
  RAW_MACCYR,
};

/* THIS IS A GENERATED TABLE, see data/totals.pl */
static const unsigned char *const CHARSET_LETTERS[] = {
  LETTER_CP1251,
  LETTER_IBM855,
  LETTER_ISO88595,
  LETTER_CP1125,
  LETTER_KOI8U,
  LETTER_MACCYR,
};

/* THIS IS A GENERATED TABLE, see data/totals.pl */
static const unsigned char **const CHARSET_PAIRS[] = {
  PAIR_CP1251,
  PAIR_IBM855,
  PAIR_ISO88595,
  PAIR_CP1125,
  PAIR_KOI8U,
  PAIR_MACCYR,
};

/* THIS IS A GENERATED VALUE, see data/totals.pl */
#define NCHARSETS 6
