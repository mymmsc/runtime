/*****  THIS IS A GENERATED FILE.  DO NOT TOUCH!  *****/
/* THIS IS A GENERATED TABLE, see data/basetoc.c. */
static const unsigned short int RAW_CP1251[] = {
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x00 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x08 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x10 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x18 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x20 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x28 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x30 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x38 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x40 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x48 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x50 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x58 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x60 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x68 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x70 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x78 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x80 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x88 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x90 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x98 */
     0,    0,  939,    0,    0,    0,    0,    0,  /* 0xa0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xa8 */
     0,    0,    0, 1491,    0,    0,    0,    0,  /* 0xb0 */
   187,    0,    0,    0,    0,    0,    0,    0,  /* 0xb8 */
   137,    0,    0,    0,    0,    0,    0,    0,  /* 0xc0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xc8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xd0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xd8 */
  5987,  651, 1083,  728, 1220, 1497,  282, 1029,  /* 0xe0 */
     0,  380, 1400, 1540, 1111, 2360, 1390, 1015,  /* 0xe8 */
  1623, 1555, 1345, 1172,    0,  424,  896,  556,  /* 0xf0 */
   445,    0,    0, 1673,  602,  381,  227, 1394,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char LETTER_CP1251[] = {
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x00 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x08 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x10 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x18 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x20 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x28 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x30 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x38 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x40 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x48 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x50 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x58 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x60 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x68 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x70 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x78 */
  255, 255,   0, 255,   0,   0,   0,   0,  /* 0x80 */
    0,   0, 255,   0, 255, 255, 255, 255,  /* 0x88 */
  255,   0,   0,   0,   0,   0,   0,   0,  /* 0x90 */
    0,   0, 255,   0, 255, 255, 255, 255,  /* 0x98 */
    0, 255,   1, 255,   0, 255,   0,   0,  /* 0xa0 */
    2,   0, 255,   0,   0,   0,   0, 255,  /* 0xa8 */
    0,   0,   3,   4, 255,   0,   0,   0,  /* 0xb0 */
    5,   0, 255,   0, 255, 255, 255, 255,  /* 0xb8 */
    6,   7,   8,   9, 255, 255, 255,  10,  /* 0xc0 */
  255, 255,  11, 255,  12,  13, 255,  14,  /* 0xc8 */
   15, 255,  16,  17, 255, 255, 255, 255,  /* 0xd0 */
  255, 255, 255, 255, 255, 255, 255,  18,  /* 0xd8 */
   19,  20,  21,  22,  23,  24,  25,  26,  /* 0xe0 */
  255,  27,  28,  29,  30,  31,  32,  33,  /* 0xe8 */
   34,  35,  36,  37,  38,  39,  40,  41,  /* 0xf0 */
   42, 255, 255,  43,  44,  45,  46,  47,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char *PAIR_CP1251[] = {

  (unsigned char*)"\xef\xed\xf1\xe7\xe0\xe4\xff\xe2\xf2\xe1\xea\xec\xb3\xe3\xa2\xf0\xf3\xf8\xeb\xc0\xf7\xf6\xf5\xe6\xcf\xcd\xd1\xc1\xb8\xcc\xc2\xca\xdf\xd3\xc4\xc7\xd2\xc3\xb2\xd0\xd5\xcb\xf4\xd8\xe5\xd7\xa8",  /* FILLCHAR */
  (unsigned char*)".\xf1\xed\xeb\xe4\xf8\xe6\xe2\xe7\xea",  /* 0xa2 */
  (unsigned char*)"\xed",  /* 0xa8 */
  (unsigned char*)".",  /* 0xb2 */
  (unsigned char*)".\xed\xea\xeb\xf6\xf1\xec\xf5\xa2\xf0\xf7\xff\xe2\xf2\xe4\xe7\xf8",  /* 0xb3 */
  (unsigned char*)"\xed.\xe9",  /* 0xb8 */
  (unsigned char*)".\xeb",  /* 0xc0 */
  (unsigned char*)"\xe5\xe0",  /* 0xc1 */
  (unsigned char*)"\xee",  /* 0xc2 */
  (unsigned char*)"\xfd",  /* 0xc3 */
  (unsigned char*)"\xe0",  /* 0xc7 */
  (unsigned char*)"\xe0",  /* 0xca */
  (unsigned char*)"\xe0",  /* 0xcc */
  (unsigned char*)"\xe0\xe5",  /* 0xcd */
  (unsigned char*)"\xe0\xf0",  /* 0xcf */
  (unsigned char*)"\xe0",  /* 0xd0 */
  (unsigned char*)"\xe0",  /* 0xd2 */
  (unsigned char*)".",  /* 0xd3 */
  (unsigned char*)".",  /* 0xdf */
  (unsigned char*)".\xeb\xe4\xf0\xf1\xa2\xed\xec\xe2\xea\xe3\xf6\xe9\xe1\xe7\xf2\xef\xf7\xe5\xff\xf5\xfe\xf8\xe6\xb8\xf4\xb3",  /* 0xe0 */
  (unsigned char*)"\xfb\xe0\xe5\xee.\xf0\xf3\xb3\xeb\xff\xed",  /* 0xe1 */
  (unsigned char*)"\xe0\xfb\xe5\xee\xb3\xff\xf3.",  /* 0xe2 */
  (unsigned char*)"\xe0\xee\xfd.\xeb\xf3\xf0\xb3\xed\xe5",  /* 0xe3 */
  (unsigned char*)"\xe0\xe7.\xfb\xed\xf3\xee\xf0\xea\xe2\xeb\xe6\xf1\xfd\xf7",  /* 0xe4 */
  (unsigned char*)".\xf0\xed\xeb\xe4\xf1\xf6\xe9\xa2\xec\xea\xf2\xe7\xf8\xf7\xe2\xef\xe5\xe6\xe1",  /* 0xe5 */
  (unsigned char*)"\xe0\xfb.\xed\xee",  /* 0xe6 */
  (unsigned char*)"\xe0.\xe5\xb3\xed\xff\xe2\xfc\xf3\xe4\xf0\xec\xe1\xe3\xeb\xfb",  /* 0xe7 */
  (unsigned char*)".\xed\xf8\xf1",  /* 0xe9 */
  (unsigned char*)"\xe0.\xb3\xf3\xee\xf0\xeb\xf2\xf1\xed",  /* 0xea */
  (unsigned char*)"\xe0\xb3\xfc\xe5\xff\xee.\xfe\xfb\xf3\xb8",  /* 0xeb */
  (unsigned char*)".\xe0\xb3\xe5\xee\xf3\xff\xfb\xed\xeb",  /* 0xec */
  (unsigned char*)"\xe0\xe5\xfb\xb3.\xff\xf3\xed\xee\xfc\xf2\xf1\xea\xf6\xe4\xf8\xf7",  /* 0xed */
  (unsigned char*)".\xa2\xeb\xe4\xf0\xe2\xed\xf1\xe9\xe3\xec\xe6\xe1\xf2\xea\xf7\xe5\xe7\xef\xf8\xf6\xf5",  /* 0xee */
  (unsigned char*)"\xe0\xf0\xe5\xee\xeb\xb3\xfb\xf3.\xff",  /* 0xef */
  (unsigned char*)"\xe0\xfb\xee\xf3\xfd.\xed\xea\xf2\xf8\xec\xe3\xe2\xf1",  /* 0xf0 */
  (unsigned char*)"\xf2\xff\xea\xe0\xf6\xef\xfc.\xf3\xeb\xe2\xb3\xe5\xed\xb8\xee\xfb\xec",  /* 0xf1 */
  (unsigned char*)"\xe0\xee\xfb\xf0\xf3.\xe2\xea\xfd\xed",  /* 0xf2 */
  (unsigned char*)".\xf1\xe4\xeb\xec\xf2\xf0\xfe\xea\xef\xa2\xf6\xf7\xe6\xf8\xed\xf5\xe1\xe3\xe7\xe2",  /* 0xf3 */
  (unsigned char*)"\xe0",  /* 0xf4 */
  (unsigned char*)".\xe0\xee\xf2\xb3\xf3\xed",  /* 0xf5 */
  (unsigned char*)"\xfc\xe0\xfb\xb3\xf6\xe5\xff.\xea\xfd",  /* 0xf6 */
  (unsigned char*)"\xe0\xfb\xed\xfd\xf3.\xee\xea",  /* 0xf7 */
  (unsigned char*)"\xf2\xfb\xf7\xe0.\xea\xeb\xfd\xed",  /* 0xf8 */
  (unsigned char*)".\xec\xff\xeb\xf5\xed\xea\xf6\xa2\xf1\xe2\xf2\xf7\xf0\xe9\xef\xb3\xe1\xe3\xf8\xe4\xe7",  /* 0xfb */
  (unsigned char*)".\xed\xea\xf6\xec\xf8\xe2\xf1",  /* 0xfc */
  (unsigned char*)"\xf2\xed\xf0.\xeb\xe9\xe1\xf1",  /* 0xfd */
  (unsigned char*)".\xf7\xf6\xe4",  /* 0xfe */
  (unsigned char*)".\xea\xed\xe3\xf0\xeb\xe4\xa2\xec\xf6\xe5\xf8\xf1\xe2\xf2\xe1\xe7\xf7\xef\xf5",  /* 0xff */
};


/* THIS IS A GENERATED TABLE, see data/basetoc.c. */
static const unsigned short int RAW_IBM866[] = {
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x00 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x08 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x10 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x18 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x20 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x28 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x30 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x38 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x40 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x48 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x50 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x58 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x60 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x68 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x70 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x78 */
   143,    0,    0,    0,    0,    0,    0,    0,  /* 0x80 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x88 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x90 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x98 */
  6241,  679, 1128,  759, 1272, 1561,  293, 1073,  /* 0xa0 */
     0,  397, 1460, 1606, 1159, 2459, 1448, 1057,  /* 0xa8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xb0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xb8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xc0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xc8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xd0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xd8 */
  1692, 1621, 1401, 1222,    0,  441,  933,  580,  /* 0xe0 */
   463,    0,    0, 1744,  628,  398,  237, 1452,  /* 0xe8 */
     0,  194,    0,    0,    0,    0,    0,  979,  /* 0xf0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char LETTER_IBM866[] = {
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x00 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x08 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x10 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x18 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x20 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x28 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x30 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x38 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x40 */
    0,   1,   0,   0,   0,   0,   0,   0,  /* 0x48 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x50 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x58 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x60 */
    0,   2,   0,   0,   0,   0,   0,   0,  /* 0x68 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x70 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x78 */
    3,   4,   5,   6, 255, 255, 255,   7,  /* 0x80 */
  255, 255,   8, 255,   9,  10, 255,  11,  /* 0x88 */
   12, 255,  13,  14,  15, 255, 255,  16,  /* 0x90 */
  255, 255, 255, 255, 255, 255, 255,  17,  /* 0x98 */
   18,  19,  20,  21,  22,  23,  24,  25,  /* 0xa0 */
  255,  26,  27,  28,  29,  30,  31,  32,  /* 0xa8 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0xb0 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0xb8 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0xc0 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0xc8 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0xd0 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0xd8 */
   33,  34,  35,  36,  37,  38,  39,  40,  /* 0xe0 */
   41, 255, 255,  42,  43,  44,  45,  46,  /* 0xe8 */
   47,  48, 255, 255, 255, 255, 255,  49,  /* 0xf0 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char *PAIR_IBM866[] = {

  (unsigned char*)"\xaf\xad\x69\xe1\xa7\xa0\xa4\xef\xa2\xa1\xe2\xaa\xa3\xac\xf7\x97\xe0\xe3\xe8\x80\xab\xe7\xe6\xe5\x8f\xa6\x8d\x49\x91\x81\xf1\x93\x8c\x8a\x82\x9f\x84\x92\x83\x87\x90\x95\x8b\xe4\x96\x98\xf0\xa5",  /* FILLCHAR */
  (unsigned char*)".",  /* 0x49 */
  (unsigned char*)".\xad\xe1\xaa\xe6\xab\xe5\xac\xf7\xef\xe7\xe0\xe2\xa2\xa7\xa4\xe8",  /* 0x69 */
  (unsigned char*)".\xab",  /* 0x80 */
  (unsigned char*)"\xa5\xa0",  /* 0x81 */
  (unsigned char*)"\xae",  /* 0x82 */
  (unsigned char*)"\xed",  /* 0x83 */
  (unsigned char*)"\xa0",  /* 0x87 */
  (unsigned char*)"\xa0",  /* 0x8a */
  (unsigned char*)"\xa0",  /* 0x8c */
  (unsigned char*)"\xa0\xa5",  /* 0x8d */
  (unsigned char*)"\xa0\xe0",  /* 0x8f */
  (unsigned char*)"\xa0",  /* 0x90 */
  (unsigned char*)"\xa0",  /* 0x92 */
  (unsigned char*)".",  /* 0x93 */
  (unsigned char*)".",  /* 0x94 */
  (unsigned char*)".",  /* 0x97 */
  (unsigned char*)".",  /* 0x9f */
  (unsigned char*)".\xab\xa4\xe0\xe1\xf7\xad\xac\xa2\xaa\xa3\xe6\xa9\xa1\xa7\xe2\xaf\xe7\xa5\xef\xe5\xee\xe8\xa6\x69\xf1\xe4",  /* 0xa0 */
  (unsigned char*)"\xeb\xa0\xa5\xae\xe0\x69.\xe3\xab\xef\xad",  /* 0xa1 */
  (unsigned char*)"\xa0\xeb\xa5\x69\xae\xef\xe3",  /* 0xa2 */
  (unsigned char*)"\xa0\xae\xed\x69\xab\xe3\xe0.\xad\xa5",  /* 0xa3 */
  (unsigned char*)"\xa0\xa7.\xeb\xad\xe3\xae\xe0\xaa\xa2\xab\xa6\xe1\xed\xe7",  /* 0xa4 */
  (unsigned char*)".\xe0\xad\xab\xa4\xe1\xe6\xa9\xf7\xac\xaa\xe2\xa7\xe8\xe7\xa2\xaf\xa5\xa6\xa1",  /* 0xa5 */
  (unsigned char*)"\xa0\xeb.\xad\xae",  /* 0xa6 */
  (unsigned char*)"\xa0.\xa5\x69\xad\xef\xa2\xec\xe3\xa4\xe0\xac\xa1\xa3\xab\xeb",  /* 0xa7 */
  (unsigned char*)".\xad\xe8\xe1",  /* 0xa9 */
  (unsigned char*)"\xa0\x69.\xe3\xae\xe0\xab\xe2\xe1\xad",  /* 0xaa */
  (unsigned char*)"\x69\xa0\xec\xa5\xef\xae\xee\xeb\xe3.\xf1",  /* 0xab */
  (unsigned char*)".\xa0\x69\xa5\xae\xe3\xef\xeb\xad\xab",  /* 0xac */
  (unsigned char*)"\xa0\xa5\xeb\x69\xef.\xe3\xad\xae\xec\xe2\xe1\xaa\xe6\xa4\xe8\xe7",  /* 0xad */
  (unsigned char*)".\xf7\xab\xa4\xe0\xa2\xad\xe1\xa9\xa3\xac\xa6\xa1\xe2\xaa\xe7\xa5\xa7\xaf\xe8\xe6\xe5",  /* 0xae */
  (unsigned char*)"\xa0\xe0\xa5\xae\x69\xab\xeb\xe3\xef",  /* 0xaf */
  (unsigned char*)"\xa0\xeb\xae\xe3\xed.\xad\xaa\xe2\xe8\xac\xa3\xa2\xe1",  /* 0xe0 */
  (unsigned char*)"\xe2\xef\xaa\xa0\xe6\xaf\xec\x69\xe3\xab\xa2.\xa5\xad\xf1\xae\xeb\xac",  /* 0xe1 */
  (unsigned char*)"\xa0\xae\xeb\xe0\xe3.\xa2\xaa\xed\xad",  /* 0xe2 */
  (unsigned char*)".\xe1\xa4\xab\xac\xe2\xe0\xee\xaa\xaf\xf7\xe6\xe7\xa6\xe8\xad\xe5\xa1\xa3\xa7\xa2",  /* 0xe3 */
  (unsigned char*)"\xa0\x69",  /* 0xe4 */
  (unsigned char*)".\xa0\xae\x69\xe2\xe3\xad",  /* 0xe5 */
  (unsigned char*)"\xec\x69\xa0\xeb\xe6\xa5\xef\xaa\xed\xf1",  /* 0xe6 */
  (unsigned char*)"\xa0\xeb\xad\xed\xe3.\xae\xaa",  /* 0xe7 */
  (unsigned char*)"\xe2\xeb\xe7\xa0.\xaa\xab\xed\xad",  /* 0xe8 */
  (unsigned char*)".\xac\xef\xab\xe5\xad\xaa\xe6\xf7\xe1\xa2\xe2\xe7\x69\xe0\xa9\xaf\xa1\xa3\xe8\xa4\xa7",  /* 0xeb */
  (unsigned char*)".\xad\xaa\xe6\xac\xe8\xa2\xe1",  /* 0xec */
  (unsigned char*)"\xe2\xad\xe0.\xab\xa9\xa1\xe1",  /* 0xed */
  (unsigned char*)".\xe7\xe6\xa4",  /* 0xee */
  (unsigned char*)".\xaa\xad\xa3\xe0\xab\xa4\xf7\xac\xe6\xa5\xe8\xe1\xa2\xe2\xa1\xa7\xe7\xaf\xe5\xa6",  /* 0xef */
  (unsigned char*)"\xad",  /* 0xf0 */
  (unsigned char*)"\xad.\xa9",  /* 0xf1 */
  (unsigned char*)".\xe1\xad\xab\xa4\xe8\xa6\xa2\xa7\xaa",  /* 0xf7 */
};


/* THIS IS A GENERATED TABLE, see data/basetoc.c. */
static const unsigned short int RAW_ISO88595[] = {
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x00 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x08 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x10 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x18 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x20 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x28 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x30 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x38 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x40 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x48 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x50 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x58 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x60 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x68 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x70 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x78 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x80 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x88 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x90 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x98 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xa0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xa8 */
   137,    0,    0,    0,    0,    0,    0,    0,  /* 0xb0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xb8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xc0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xc8 */
  5987,  651, 1083,  728, 1220, 1497,  282, 1029,  /* 0xd0 */
     0,  380, 1400, 1540, 1111, 2360, 1390, 1015,  /* 0xd8 */
  1623, 1555, 1345, 1172,    0,  424,  896,  556,  /* 0xe0 */
   445,    0,    0, 1673,  602,  381,  227, 1394,  /* 0xe8 */
     0,  187,    0,    0,    0,    0, 1491,    0,  /* 0xf0 */
     0,    0,    0,    0,    0,    0,  939,    0,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char LETTER_ISO88595[] = {
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x00 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x08 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x10 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x18 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x20 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x28 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x30 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x38 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x40 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x48 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x50 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x58 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x60 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x68 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x70 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x78 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x80 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x88 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x90 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x98 */
    0,   2, 255, 255, 255, 255,   3, 255,  /* 0xa0 */
  255, 255, 255, 255, 255,   0, 255, 255,  /* 0xa8 */
    6,   7,   8,   9, 255, 255, 255,  10,  /* 0xb0 */
  255, 255,  11, 255,  12,  13, 255,  14,  /* 0xb8 */
   15, 255,  16,  17, 255, 255, 255, 255,  /* 0xc0 */
  255, 255, 255, 255, 255, 255, 255,  18,  /* 0xc8 */
   19,  20,  21,  22,  23,  24,  25,  26,  /* 0xd0 */
  255,  27,  28,  29,  30,  31,  32,  33,  /* 0xd8 */
   34,  35,  36,  37,  38,  39,  40,  41,  /* 0xe0 */
   42, 255, 255,  43,  44,  45,  46,  47,  /* 0xe8 */
    0,   5, 255, 255, 255, 255,   4, 255,  /* 0xf0 */
  255, 255, 255, 255, 255,   0,   1, 255,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char *PAIR_ISO88595[] = {

  (unsigned char*)"\xdf\xdd\xe1\xd7\xd0\xd4\xef\xd2\xe2\xd1\xda\xdc\xf6\xd3\xfe\xe0\xe3\xe8\xdb\xb0\xe7\xe6\xe5\xd6\xbf\xbd\xc1\xb1\xf1\xbc\xb2\xba\xcf\xc3\xb4\xb7\xc2\xb3\xa6\xc0\xc5\xbb\xe4\xc8\xd5\xc7\xa1",  /* FILLCHAR */
  (unsigned char*)".\xe1\xdd\xdb\xd4\xe8\xd6\xd2\xd7\xda",  /* 0xfe */
  (unsigned char*)"\xdd",  /* 0xa1 */
  (unsigned char*)".",  /* 0xa6 */
  (unsigned char*)".\xdd\xda\xdb\xe6\xe1\xdc\xe5\xfe\xe0\xe7\xef\xd2\xe2\xd4\xd7\xe8",  /* 0xf6 */
  (unsigned char*)"\xdd.\xd9",  /* 0xf1 */
  (unsigned char*)".\xdb",  /* 0xb0 */
  (unsigned char*)"\xd5\xd0",  /* 0xb1 */
  (unsigned char*)"\xde",  /* 0xb2 */
  (unsigned char*)"\xed",  /* 0xb3 */
  (unsigned char*)"\xd0",  /* 0xb7 */
  (unsigned char*)"\xd0",  /* 0xba */
  (unsigned char*)"\xd0",  /* 0xbc */
  (unsigned char*)"\xd0\xd5",  /* 0xbd */
  (unsigned char*)"\xd0\xe0",  /* 0xbf */
  (unsigned char*)"\xd0",  /* 0xc0 */
  (unsigned char*)"\xd0",  /* 0xc2 */
  (unsigned char*)".",  /* 0xc3 */
  (unsigned char*)".",  /* 0xcf */
  (unsigned char*)".\xdb\xd4\xe0\xe1\xfe\xdd\xdc\xd2\xda\xd3\xe6\xd9\xd1\xd7\xe2\xdf\xe7\xd5\xef\xe5\xee\xe8\xd6\xf1\xe4\xf6",  /* 0xd0 */
  (unsigned char*)"\xeb\xd0\xd5\xde.\xe0\xe3\xf6\xdb\xef\xdd",  /* 0xd1 */
  (unsigned char*)"\xd0\xeb\xd5\xde\xf6\xef\xe3.",  /* 0xd2 */
  (unsigned char*)"\xd0\xde\xed.\xdb\xe3\xe0\xf6\xdd\xd5",  /* 0xd3 */
  (unsigned char*)"\xd0\xd7.\xeb\xdd\xe3\xde\xe0\xda\xd2\xdb\xd6\xe1\xed\xe7",  /* 0xd4 */
  (unsigned char*)".\xe0\xdd\xdb\xd4\xe1\xe6\xd9\xfe\xdc\xda\xe2\xd7\xe8\xe7\xd2\xdf\xd5\xd6\xd1",  /* 0xd5 */
  (unsigned char*)"\xd0\xeb.\xdd\xde",  /* 0xd6 */
  (unsigned char*)"\xd0.\xd5\xf6\xdd\xef\xd2\xec\xe3\xd4\xe0\xdc\xd1\xd3\xdb\xeb",  /* 0xd7 */
  (unsigned char*)".\xdd\xe8\xe1",  /* 0xd9 */
  (unsigned char*)"\xd0.\xf6\xe3\xde\xe0\xdb\xe2\xe1\xdd",  /* 0xda */
  (unsigned char*)"\xd0\xf6\xec\xd5\xef\xde.\xee\xeb\xe3\xf1",  /* 0xdb */
  (unsigned char*)".\xd0\xf6\xd5\xde\xe3\xef\xeb\xdd\xdb",  /* 0xdc */
  (unsigned char*)"\xd0\xd5\xeb\xf6.\xef\xe3\xdd\xde\xec\xe2\xe1\xda\xe6\xd4\xe8\xe7",  /* 0xdd */
  (unsigned char*)".\xfe\xdb\xd4\xe0\xd2\xdd\xe1\xd9\xd3\xdc\xd6\xd1\xe2\xda\xe7\xd5\xd7\xdf\xe8\xe6\xe5",  /* 0xde */
  (unsigned char*)"\xd0\xe0\xd5\xde\xdb\xf6\xeb\xe3.\xef",  /* 0xdf */
  (unsigned char*)"\xd0\xeb\xde\xe3\xed.\xdd\xda\xe2\xe8\xdc\xd3\xd2\xe1",  /* 0xe0 */
  (unsigned char*)"\xe2\xef\xda\xd0\xe6\xdf\xec.\xe3\xdb\xd2\xf6\xd5\xdd\xf1\xde\xeb\xdc",  /* 0xe1 */
  (unsigned char*)"\xd0\xde\xeb\xe0\xe3.\xd2\xda\xed\xdd",  /* 0xe2 */
  (unsigned char*)".\xe1\xd4\xdb\xdc\xe2\xe0\xee\xda\xdf\xfe\xe6\xe7\xd6\xe8\xdd\xe5\xd1\xd3\xd7\xd2",  /* 0xe3 */
  (unsigned char*)"\xd0",  /* 0xe4 */
  (unsigned char*)".\xd0\xde\xe2\xf6\xe3\xdd",  /* 0xe5 */
  (unsigned char*)"\xec\xd0\xeb\xf6\xe6\xd5\xef.\xda\xed",  /* 0xe6 */
  (unsigned char*)"\xd0\xeb\xdd\xed\xe3.\xde\xda",  /* 0xe7 */
  (unsigned char*)"\xe2\xeb\xe7\xd0.\xda\xdb\xed\xdd",  /* 0xe8 */
  (unsigned char*)".\xdc\xef\xdb\xe5\xdd\xda\xe6\xfe\xe1\xd2\xe2\xe7\xe0\xd9\xdf\xf6\xd1\xd3\xe8\xd4\xd7",  /* 0xeb */
  (unsigned char*)".\xdd\xda\xe6\xdc\xe8\xd2\xe1",  /* 0xec */
  (unsigned char*)"\xe2\xdd\xe0.\xdb\xd9\xd1\xe1",  /* 0xed */
  (unsigned char*)".\xe7\xe6\xd4",  /* 0xee */
  (unsigned char*)".\xda\xdd\xd3\xe0\xdb\xd4\xfe\xdc\xe6\xd5\xe8\xe1\xd2\xe2\xd1\xd7\xe7\xdf\xe5",  /* 0xef */
};


/* THIS IS A GENERATED TABLE, see data/basetoc.c. */
static const unsigned short int RAW_KOI8UNI[] = {
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x00 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x08 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x10 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x18 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x20 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x28 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x30 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x38 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x40 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x48 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x50 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x58 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x60 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x68 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x70 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x78 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x80 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x88 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x90 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x98 */
     0,    0,    0,  187,    0,    0, 1491,    0,  /* 0xa0 */
     0,    0,    0,    0,    0,    0,  939,    0,  /* 0xa8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xb0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xb8 */
   227, 5987,  651,  896, 1220, 1497,    0,  728,  /* 0xc0 */
   424,    0,  380, 1400, 1540, 1111, 2360, 1390,  /* 0xc8 */
  1015, 1394, 1623, 1555, 1345, 1172,  282, 1083,  /* 0xd0 */
   602, 1673, 1029,  445,  381,    0,  556,    0,  /* 0xd8 */
     0,  137,    0,    0,    0,    0,    0,    0,  /* 0xe0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xe8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xf0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char LETTER_KOI8UNI[] = {
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x00 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x08 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x10 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x18 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x20 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x28 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x30 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x38 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x40 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x48 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x50 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x58 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x60 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x68 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x70 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x78 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x80 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x88 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x90 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x98 */
    0, 255, 255,   5, 255, 255,   4, 255,  /* 0xa0 */
  255, 255, 255, 255, 255, 255,   1, 255,  /* 0xa8 */
    0, 255, 255,   2, 255, 255,   3, 255,  /* 0xb0 */
  255, 255, 255, 255, 255, 255, 255, 255,  /* 0xb8 */
   46,  19,  20,  40,  23,  24,  38,  22,  /* 0xc0 */
   39, 255,  27,  28,  29,  30,  31,  32,  /* 0xc8 */
   33,  47,  34,  35,  36,  37,  25,  21,  /* 0xd0 */
   44,  43,  26,  42,  45, 255,  41, 255,  /* 0xd8 */
  255,   6,   7, 255, 255, 255, 255,   9,  /* 0xe0 */
  255, 255, 255,  11, 255,  12,  13, 255,  /* 0xe8 */
   14,  18,  15, 255,  16,  17, 255,   8,  /* 0xf0 */
  255, 255,  10, 255, 255, 255, 255, 255,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char *PAIR_KOI8UNI[] = {

  (unsigned char*)"\xd0\xce\xd3\xda\xc1\xc4\xd1\xd7\xd4\xc2\xcb\xcd\xa6\xc7\xae\xd2\xd5\xdb\xcc\xe1\xde\xc3\xc8\xd6\xf0\xee\xf3\xe2\xa3\xed\xf7\xeb\xf1\xf5\xe4\xfa\xf4\xe7\xb6\xf2\xe8\xec\xc6\xfb\xc5\xfe\xb3",  /* FILLCHAR */
  (unsigned char*)".\xd3\xce\xcc\xc4\xdb\xd6\xd7\xda\xcb",  /* 0xae */
  (unsigned char*)"\xce",  /* 0xb3 */
  (unsigned char*)".",  /* 0xb6 */
  (unsigned char*)".\xce\xcb\xcc\xc3\xd3\xcd\xc8\xae\xd2\xde\xd1\xd7\xd4\xc4\xda\xdb",  /* 0xa6 */
  (unsigned char*)"\xce.\xca",  /* 0xa3 */
  (unsigned char*)".\xcc",  /* 0xe1 */
  (unsigned char*)"\xc5\xc1",  /* 0xe2 */
  (unsigned char*)"\xcf",  /* 0xf7 */
  (unsigned char*)"\xdc",  /* 0xe7 */
  (unsigned char*)"\xc1",  /* 0xfa */
  (unsigned char*)"\xc1",  /* 0xeb */
  (unsigned char*)"\xc1",  /* 0xed */
  (unsigned char*)"\xc1\xc5",  /* 0xee */
  (unsigned char*)"\xc1\xd2",  /* 0xf0 */
  (unsigned char*)"\xc1",  /* 0xf2 */
  (unsigned char*)"\xc1",  /* 0xf4 */
  (unsigned char*)".",  /* 0xf5 */
  (unsigned char*)".",  /* 0xf1 */
  (unsigned char*)".\xcc\xc4\xd2\xd3\xae\xce\xcd\xd7\xcb\xc7\xc3\xca\xc2\xda\xd4\xd0\xde\xc5\xd1\xc8\xc0\xdb\xd6\xa3\xc6\xa6",  /* 0xc1 */
  (unsigned char*)"\xd9\xc1\xc5\xcf.\xd2\xd5\xa6\xcc\xd1\xce",  /* 0xc2 */
  (unsigned char*)"\xc1\xd9\xc5\xcf\xa6\xd1\xd5.",  /* 0xd7 */
  (unsigned char*)"\xc1\xcf\xdc.\xcc\xd5\xd2\xa6\xce\xc5",  /* 0xc7 */
  (unsigned char*)"\xc1\xda.\xd9\xce\xd5\xcf\xd2\xcb\xd7\xcc\xd6\xd3\xdc\xde",  /* 0xc4 */
  (unsigned char*)".\xd2\xce\xcc\xc4\xd3\xc3\xca\xae\xcd\xcb\xd4\xda\xdb\xde\xd7\xd0\xc5\xd6\xc2",  /* 0xc5 */
  (unsigned char*)"\xc1\xd9.\xce\xcf",  /* 0xd6 */
  (unsigned char*)"\xc1.\xc5\xa6\xce\xd1\xd7\xd8\xd5\xc4\xd2\xcd\xc2\xc7\xcc\xd9",  /* 0xda */
  (unsigned char*)".\xce\xdb\xd3",  /* 0xca */
  (unsigned char*)"\xc1.\xa6\xd5\xcf\xd2\xcc\xd4\xd3\xce",  /* 0xcb */
  (unsigned char*)"\xc1\xa6\xd8\xc5\xd1\xcf.\xc0\xd9\xd5\xa3",  /* 0xcc */
  (unsigned char*)".\xc1\xa6\xc5\xcf\xd5\xd1\xd9\xce\xcc",  /* 0xcd */
  (unsigned char*)"\xc1\xc5\xd9\xa6.\xd1\xd5\xce\xcf\xd8\xd4\xd3\xcb\xc3\xc4\xdb\xde",  /* 0xce */
  (unsigned char*)".\xae\xcc\xc4\xd2\xd7\xce\xd3\xca\xc7\xcd\xd6\xc2\xd4\xcb\xde\xc5\xda\xd0\xdb\xc3\xc8",  /* 0xcf */
  (unsigned char*)"\xc1\xd2\xc5\xcf\xcc\xa6\xd9\xd5.\xd1",  /* 0xd0 */
  (unsigned char*)"\xc1\xd9\xcf\xd5\xdc.\xce\xcb\xd4\xdb\xcd\xc7\xd7\xd3",  /* 0xd2 */
  (unsigned char*)"\xd4\xd1\xcb\xc1\xc3\xd0\xd8.\xd5\xcc\xd7\xa6\xc5\xce\xa3\xcf\xd9\xcd",  /* 0xd3 */
  (unsigned char*)"\xc1\xcf\xd9\xd2\xd5.\xd7\xcb\xdc\xce",  /* 0xd4 */
  (unsigned char*)".\xd3\xc4\xcc\xcd\xd4\xd2\xc0\xcb\xd0\xae\xc3\xde\xd6\xdb\xce\xc8\xc2\xc7\xda\xd7",  /* 0xd5 */
  (unsigned char*)"\xc1",  /* 0xc6 */
  (unsigned char*)".\xc1\xcf\xd4\xa6\xd5\xce",  /* 0xc8 */
  (unsigned char*)"\xd8\xc1\xd9\xa6\xc3\xc5\xd1.\xcb\xdc",  /* 0xc3 */
  (unsigned char*)"\xc1\xd9\xce\xdc\xd5.\xcf\xcb",  /* 0xde */
  (unsigned char*)"\xd4\xd9\xde\xc1.\xcb\xcc\xdc\xce",  /* 0xdb */
  (unsigned char*)".\xcd\xd1\xcc\xc8\xce\xcb\xc3\xae\xd3\xd7\xd4\xde\xd2\xca\xd0\xa6\xc2\xc7\xdb\xc4\xda",  /* 0xd9 */
  (unsigned char*)".\xce\xcb\xc3\xcd\xdb\xd7\xd3",  /* 0xd8 */
  (unsigned char*)"\xd4\xce\xd2.\xcc\xca\xc2\xd3",  /* 0xdc */
  (unsigned char*)".\xde\xc3\xc4",  /* 0xc0 */
  (unsigned char*)".\xcb\xce\xc7\xd2\xcc\xc4\xae\xcd\xc3\xc5\xdb\xd3\xd7\xd4\xc2\xda\xde\xd0\xc8",  /* 0xd1 */
};


/* THIS IS A GENERATED TABLE, see data/basetoc.c. */
static const unsigned short int RAW_MACCYR[] = {
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x00 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x08 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x10 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x18 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x20 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x28 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x30 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x38 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x40 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x48 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x50 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x58 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x60 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x68 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x70 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x78 */
   137,    0,    0,    0,    0,    0,    0,    0,  /* 0x80 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x88 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x90 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x98 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xa0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xa8 */
     0,    0,    0,    0, 1491,    0,    0,    0,  /* 0xb0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xb8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xc0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xc8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xd0 */
     0,  939,    0,    0,    0,    0,  187, 1394,  /* 0xd8 */
  5987,  651, 1083,  728, 1220, 1497,  282, 1029,  /* 0xe0 */
     0,  380, 1400, 1540, 1111, 2360, 1390, 1015,  /* 0xe8 */
  1623, 1555, 1345, 1172,    0,  424,  896,  556,  /* 0xf0 */
   445,    0,    0, 1673,  602,  381,  227,    0,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char LETTER_MACCYR[] = {
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x00 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x08 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x10 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x18 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x20 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x28 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x30 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x38 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x40 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x48 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x50 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x58 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x60 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x68 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x70 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x78 */
    6,   7,   8,   9, 255, 255, 255,  10,  /* 0x80 */
  255, 255,  11, 255,  12,  13, 255,  14,  /* 0x88 */
   15, 255,  16,  17, 255, 255, 255, 255,  /* 0x90 */
  255, 255, 255, 255, 255, 255, 255,  18,  /* 0x98 */
    0,   0, 255,   0,   0,   0,   0,   3,  /* 0xa0 */
    0,   0,   0, 255, 255,   0, 255, 255,  /* 0xa8 */
    0,   0,   0,   0,   4,   0, 255, 255,  /* 0xb0 */
  255, 255, 255, 255, 255, 255, 255, 255,  /* 0xb8 */
  255, 255,   0,   0, 255,   0,   0,   0,  /* 0xc0 */
    0,   0,   0, 255, 255, 255, 255, 255,  /* 0xc8 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0xd0 */
  255,   1, 255, 255,   0,   2,   5,  47,  /* 0xd8 */
   19,  20,  21,  22,  23,  24,  25,  26,  /* 0xe0 */
  255,  27,  28,  29,  30,  31,  32,  33,  /* 0xe8 */
   34,  35,  36,  37,  38,  39,  40,  41,  /* 0xf0 */
   42, 255, 255,  43,  44,  45,  46,   0,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char *PAIR_MACCYR[] = {

  (unsigned char*)"\xef\xed\xf1\xe7\xe0\xe4\xdf\xe2\xf2\xe1\xea\xec\xb4\xe3\xd9\xf0\xf3\xf8\xeb\x80\xf7\xf6\xf5\xe6\x8f\x8d\x91\x81\xde\x8c\x82\x8a\x9f\x93\x84\x87\x92\x83\xa7\x90\x95\x8b\xf4\x98\xe5\x97\xdd",  /* FILLCHAR */
  (unsigned char*)".\xf1\xed\xeb\xe4\xf8\xe6\xe2\xe7\xea",  /* 0xd9 */
  (unsigned char*)"\xed",  /* 0xdd */
  (unsigned char*)".",  /* 0xa7 */
  (unsigned char*)".\xed\xea\xeb\xf6\xf1\xec\xf5\xd9\xf0\xf7\xdf\xe2\xf2\xe4\xe7\xf8",  /* 0xb4 */
  (unsigned char*)"\xed.\xe9",  /* 0xde */
  (unsigned char*)".\xeb",  /* 0x80 */
  (unsigned char*)"\xe5\xe0",  /* 0x81 */
  (unsigned char*)"\xee",  /* 0x82 */
  (unsigned char*)"\xfd",  /* 0x83 */
  (unsigned char*)"\xe0",  /* 0x87 */
  (unsigned char*)"\xe0",  /* 0x8a */
  (unsigned char*)"\xe0",  /* 0x8c */
  (unsigned char*)"\xe0\xe5",  /* 0x8d */
  (unsigned char*)"\xe0\xf0",  /* 0x8f */
  (unsigned char*)"\xe0",  /* 0x90 */
  (unsigned char*)"\xe0",  /* 0x92 */
  (unsigned char*)".",  /* 0x93 */
  (unsigned char*)".",  /* 0x9f */
  (unsigned char*)".\xeb\xe4\xf0\xf1\xd9\xed\xec\xe2\xea\xe3\xf6\xe9\xe1\xe7\xf2\xef\xf7\xe5\xdf\xf5\xfe\xf8\xe6\xde\xf4\xb4",  /* 0xe0 */
  (unsigned char*)"\xfb\xe0\xe5\xee.\xf0\xf3\xb4\xeb\xdf\xed",  /* 0xe1 */
  (unsigned char*)"\xe0\xfb\xe5\xee\xb4\xdf\xf3.",  /* 0xe2 */
  (unsigned char*)"\xe0\xee\xfd.\xeb\xf3\xf0\xb4\xed\xe5",  /* 0xe3 */
  (unsigned char*)"\xe0\xe7.\xfb\xed\xf3\xee\xf0\xea\xe2\xeb\xe6\xf1\xfd\xf7",  /* 0xe4 */
  (unsigned char*)".\xf0\xed\xeb\xe4\xf1\xf6\xe9\xd9\xec\xea\xf2\xe7\xf8\xf7\xe2\xef\xe5\xe6\xe1",  /* 0xe5 */
  (unsigned char*)"\xe0\xfb.\xed\xee",  /* 0xe6 */
  (unsigned char*)"\xe0.\xe5\xb4\xed\xdf\xe2\xfc\xf3\xe4\xf0\xec\xe1\xe3\xeb\xfb",  /* 0xe7 */
  (unsigned char*)".\xed\xf8\xf1",  /* 0xe9 */
  (unsigned char*)"\xe0.\xb4\xf3\xee\xf0\xeb\xf2\xf1\xed",  /* 0xea */
  (unsigned char*)"\xe0\xb4\xfc\xe5\xdf\xee.\xfe\xfb\xf3\xde",  /* 0xeb */
  (unsigned char*)".\xe0\xb4\xe5\xee\xf3\xdf\xfb\xed\xeb",  /* 0xec */
  (unsigned char*)"\xe0\xe5\xfb\xb4.\xdf\xf3\xed\xee\xfc\xf2\xf1\xea\xf6\xe4\xf8\xf7",  /* 0xed */
  (unsigned char*)".\xd9\xeb\xe4\xf0\xe2\xed\xf1\xe9\xe3\xec\xe6\xe1\xf2\xea\xf7\xe5\xe7\xef\xf8\xf6\xf5",  /* 0xee */
  (unsigned char*)"\xe0\xf0\xe5\xee\xeb\xb4\xfb\xf3.\xdf",  /* 0xef */
  (unsigned char*)"\xe0\xfb\xee\xf3\xfd.\xed\xea\xf2\xf8\xec\xe3\xe2\xf1",  /* 0xf0 */
  (unsigned char*)"\xf2\xdf\xea\xe0\xf6\xef\xfc.\xf3\xeb\xe2\xb4\xe5\xed\xde\xee\xfb\xec",  /* 0xf1 */
  (unsigned char*)"\xe0\xee\xfb\xf0\xf3.\xe2\xea\xfd\xed",  /* 0xf2 */
  (unsigned char*)".\xf1\xe4\xeb\xec\xf2\xf0\xfe\xea\xef\xd9\xf6\xf7\xe6\xf8\xed\xf5\xe1\xe3\xe7\xe2",  /* 0xf3 */
  (unsigned char*)"\xe0",  /* 0xf4 */
  (unsigned char*)".\xe0\xee\xf2\xb4\xf3\xed",  /* 0xf5 */
  (unsigned char*)"\xfc\xe0\xfb\xb4\xf6\xe5\xdf.\xea\xfd",  /* 0xf6 */
  (unsigned char*)"\xe0\xfb\xed\xfd\xf3.\xee\xea",  /* 0xf7 */
  (unsigned char*)"\xf2\xfb\xf7\xe0.\xea\xeb\xfd\xed",  /* 0xf8 */
  (unsigned char*)".\xec\xdf\xeb\xf5\xed\xea\xf6\xd9\xf1\xe2\xf2\xf7\xf0\xe9\xef\xb4\xe1\xe3\xf8\xe4\xe7",  /* 0xfb */
  (unsigned char*)".\xed\xea\xf6\xec\xf8\xe2\xf1",  /* 0xfc */
  (unsigned char*)"\xf2\xed\xf0.\xeb\xe9\xe1\xf1",  /* 0xfd */
  (unsigned char*)".\xf7\xf6\xe4",  /* 0xfe */
  (unsigned char*)".\xea\xed\xe3\xf0\xeb\xe4\xd9\xec\xf6\xe5\xf8\xf1\xe2\xf2\xe1\xe7\xf7\xef\xf5",  /* 0xdf */
};


/* THIS IS A GENERATED TABLE, see data/basetoc.c. */
static const unsigned short int RAW_IBM855[] = {
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x00 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x08 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x10 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x18 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x20 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x28 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x30 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x38 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x40 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x48 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x50 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x58 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x60 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x68 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x70 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x78 */
     0,    0,    0,    0,  187,    0,    0,    0,  /* 0x80 */
     0,    0, 1491,    0,    0,    0,    0,    0,  /* 0x88 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x90 */
   939,    0,    0,    0,  227,    0,    0,    0,  /* 0x98 */
  5987,  137,  651,    0,  896,    0, 1220,    0,  /* 0xa0 */
  1497,    0,    0,    0,  728,    0,    0,    0,  /* 0xa8 */
     0,    0,    0,    0,    0,  424,    0,    0,  /* 0xb0 */
     0,    0,    0,    0,    0,  380,    0,    0,  /* 0xb8 */
     0,    0,    0,    0,    0,    0, 1400,    0,  /* 0xc0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xc8 */
  1540,    0, 1111,    0, 2360,    0, 1390,    0,  /* 0xd0 */
  1015,    0,    0,    0,    0,    0, 1394,    0,  /* 0xd8 */
     0, 1623,    0, 1555,    0, 1345,    0, 1172,  /* 0xe0 */
     0,  282,    0, 1083,    0,  602,    0,    0,  /* 0xe8 */
     0, 1673,    0, 1029,    0,  445,    0,  381,  /* 0xf0 */
     0,    0,    0,  556,    0,    0,    0,    0,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char LETTER_IBM855[] = {
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x00 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x08 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x10 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x18 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x20 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x28 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x30 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x38 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x40 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x48 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x50 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x58 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x60 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x68 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x70 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x78 */
  255, 255, 255, 255,   5,   2, 255, 255,  /* 0x80 */
  255, 255,   4,   3, 255, 255, 255, 255,  /* 0x88 */
  255, 255, 255, 255, 255,   0, 255, 255,  /* 0x90 */
    1, 255, 255, 255,  46, 255, 255, 255,  /* 0x98 */
   19,   6,  20,   7,  40, 255,  23, 255,  /* 0xa0 */
   24, 255,  38, 255,  22,   9,   0,   0,  /* 0xa8 */
    0,   0,   0,   0,   0,  39, 255, 255,  /* 0xb0 */
  255,   0,   0,   0,   0,  27, 255,   0,  /* 0xb8 */
    0,   0,   0,   0,   0,   0,  28,  11,  /* 0xc0 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0xc8 */
   29, 255,  30,  12,  31,  13,  32, 255,  /* 0xd0 */
   33,   0,   0,   0,   0,  14,  47,   0,  /* 0xd8 */
   18,  34,  15,  35, 255,  36,  16,  37,  /* 0xe0 */
   17,  25, 255,  21,   8,  44, 255,   0,  /* 0xe8 */
    0,  43, 255,  26,  10,  42, 255,  45,  /* 0xf0 */
  255, 255, 255,  41, 255,   0,   0,   0,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char *PAIR_IBM855[] = {

  (unsigned char*)"\xd8\xd4\xe3\xf3\xa0\xa6\xde\xeb\xe5\xa2\xc6\xd2\x8a\xac\x98\xe1\xe7\xf5\xd0\xa1\xfb\xa4\xb5\xe9\xdd\xd5\xe4\xa3\x84\xd3\xec\xc7\xe0\xe8\xa7\xf4\xe6\xad\x8b\xe2\xb6\xd1\xaa\xf6\xa8\xfc\x85",  /* FILLCHAR */
  (unsigned char*)".\xe3\xd4\xd0\xa6\xf5\xe9\xeb\xf3\xc6",  /* 0x98 */
  (unsigned char*)"\xd4",  /* 0x85 */
  (unsigned char*)".",  /* 0x8b */
  (unsigned char*)".\xd4\xc6\xd0\xa4\xe3\xd2\xb5\x98\xe1\xfb\xde\xeb\xe5\xa6\xf3\xf5",  /* 0x8a */
  (unsigned char*)"\xd4.\xbd",  /* 0x84 */
  (unsigned char*)".\xd0",  /* 0xa1 */
  (unsigned char*)"\xa8\xa0",  /* 0xa3 */
  (unsigned char*)"\xd6",  /* 0xec */
  (unsigned char*)"\xf7",  /* 0xad */
  (unsigned char*)"\xa0",  /* 0xf4 */
  (unsigned char*)"\xa0",  /* 0xc7 */
  (unsigned char*)"\xa0",  /* 0xd3 */
  (unsigned char*)"\xa0\xa8",  /* 0xd5 */
  (unsigned char*)"\xa0\xe1",  /* 0xdd */
  (unsigned char*)"\xa0",  /* 0xe2 */
  (unsigned char*)"\xa0",  /* 0xe6 */
  (unsigned char*)".",  /* 0xe8 */
  (unsigned char*)".",  /* 0xe0 */
  (unsigned char*)".\xd0\xa6\xe1\xe3\x98\xd4\xd2\xeb\xc6\xac\xa4\xbd\xa2\xf3\xe5\xd8\xfb\xa8\xde\xb5\x9c\xf5\xe9\x84\xaa\x8a",  /* 0xa0 */
  (unsigned char*)"\xf1\xa0\xa8\xd6.\xe1\xe7\x8a\xd0\xde\xd4",  /* 0xa2 */
  (unsigned char*)"\xa0\xf1\xa8\xd6\x8a\xde\xe7.",  /* 0xeb */
  (unsigned char*)"\xa0\xd6\xf7.\xd0\xe7\xe1\x8a\xd4\xa8",  /* 0xac */
  (unsigned char*)"\xa0\xf3.\xf1\xd4\xe7\xd6\xe1\xc6\xeb\xd0\xe9\xe3\xf7\xfb",  /* 0xa6 */
  (unsigned char*)".\xe1\xd4\xd0\xa6\xe3\xa4\xbd\x98\xd2\xc6\xe5\xf3\xf5\xfb\xeb\xd8\xa8\xe9\xa2",  /* 0xa8 */
  (unsigned char*)"\xa0\xf1.\xd4\xd6",  /* 0xe9 */
  (unsigned char*)"\xa0.\xa8\x8a\xd4\xde\xeb\xed\xe7\xa6\xe1\xd2\xa2\xac\xd0\xf1",  /* 0xf3 */
  (unsigned char*)".\xd4\xf5\xe3",  /* 0xbd */
  (unsigned char*)"\xa0.\x8a\xe7\xd6\xe1\xd0\xe5\xe3\xd4",  /* 0xc6 */
  (unsigned char*)"\xa0\x8a\xed\xa8\xde\xd6.\x9c\xf1\xe7\x84",  /* 0xd0 */
  (unsigned char*)".\xa0\x8a\xa8\xd6\xe7\xde\xf1\xd4\xd0",  /* 0xd2 */
  (unsigned char*)"\xa0\xa8\xf1\x8a.\xde\xe7\xd4\xd6\xed\xe5\xe3\xc6\xa4\xa6\xf5\xfb",  /* 0xd4 */
  (unsigned char*)".\x98\xd0\xa6\xe1\xeb\xd4\xe3\xbd\xac\xd2\xe9\xa2\xe5\xc6\xfb\xa8\xf3\xd8\xf5\xa4\xb5",  /* 0xd6 */
  (unsigned char*)"\xa0\xe1\xa8\xd6\xd0\x8a\xf1\xe7.\xde",  /* 0xd8 */
  (unsigned char*)"\xa0\xf1\xd6\xe7\xf7.\xd4\xc6\xe5\xf5\xd2\xac\xeb\xe3",  /* 0xe1 */
  (unsigned char*)"\xe5\xde\xc6\xa0\xa4\xd8\xed.\xe7\xd0\xeb\x8a\xa8\xd4\x84\xd6\xf1\xd2",  /* 0xe3 */
  (unsigned char*)"\xa0\xd6\xf1\xe1\xe7.\xeb\xc6\xf7\xd4",  /* 0xe5 */
  (unsigned char*)".\xe3\xa6\xd0\xd2\xe5\xe1\x9c\xc6\xd8\x98\xa4\xfb\xe9\xf5\xd4\xb5\xa2\xac\xf3\xeb",  /* 0xe7 */
  (unsigned char*)"\xa0",  /* 0xaa */
  (unsigned char*)".\xa0\xd6\xe5\x8a\xe7\xd4",  /* 0xb5 */
  (unsigned char*)"\xed\xa0\xf1\x8a\xa4\xa8\xde.\xc6\xf7",  /* 0xa4 */
  (unsigned char*)"\xa0\xf1\xd4\xf7\xe7.\xd6\xc6",  /* 0xfb */
  (unsigned char*)"\xe5\xf1\xfb\xa0.\xc6\xd0\xf7\xd4",  /* 0xf5 */
  (unsigned char*)".\xd2\xde\xd0\xb5\xd4\xc6\xa4\x98\xe3\xeb\xe5\xfb\xe1\xbd\xd8\x8a\xa2\xac\xf5\xa6\xf3",  /* 0xf1 */
  (unsigned char*)".\xd4\xc6\xa4\xd2\xf5\xeb\xe3",  /* 0xed */
  (unsigned char*)"\xe5\xd4\xe1.\xd0\xbd\xa2\xe3",  /* 0xf7 */
  (unsigned char*)".\xfb\xa4\xa6",  /* 0x9c */
  (unsigned char*)".\xc6\xd4\xac\xe1\xd0\xa6\x98\xd2\xa4\xa8\xf5\xe3\xeb\xe5\xa2\xf3\xfb\xd8\xb5",  /* 0xde */
};


/* THIS IS A GENERATED TABLE, see data/basetoc.c. */
static const unsigned short int RAW_KOI8U[] = {
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x00 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x08 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x10 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x18 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x20 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x28 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x30 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x38 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x40 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x48 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x50 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x58 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x60 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x68 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x70 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x78 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x80 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x88 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x90 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0x98 */
     0,    0,  939,  187,    0,    0, 1491,    0,  /* 0xa0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xa8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xb0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xb8 */
   227, 5987,  651,  896, 1220, 1497,    0,  728,  /* 0xc0 */
   424,    0,  380, 1400, 1540, 1111, 2360, 1390,  /* 0xc8 */
  1015, 1394, 1623, 1555, 1345, 1172,  282, 1083,  /* 0xd0 */
   602, 1673, 1029,  445,  381,    0,  556,    0,  /* 0xd8 */
     0,  137,    0,    0,    0,    0,    0,    0,  /* 0xe0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xe8 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xf0 */
     0,    0,    0,    0,    0,    0,    0,    0,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char LETTER_KOI8U[] = {
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x00 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x08 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x10 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x18 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x20 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x28 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x30 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x38 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x40 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x48 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x50 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x58 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x60 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x68 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x70 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x78 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x80 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x88 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x90 */
    0,   0,   0,   0,   0,   0,   0,   0,  /* 0x98 */
    0,   0,   1,   5, 255,   0,   4, 255,  /* 0xa0 */
    0,   0,   0,   0,   0, 255,   0,   0,  /* 0xa8 */
    0,   0,   0,   2, 255,   0,   3, 255,  /* 0xb0 */
    0,   0,   0,   0,   0, 255,   0,   0,  /* 0xb8 */
   46,  19,  20,  40,  23,  24,  38,  22,  /* 0xc0 */
   39, 255,  27,  28,  29,  30,  31,  32,  /* 0xc8 */
   33,  47,  34,  35,  36,  37,  25,  21,  /* 0xd0 */
   44,  43,  26,  42,  45, 255,  41, 255,  /* 0xd8 */
  255,   6,   7, 255, 255, 255, 255,   9,  /* 0xe0 */
  255, 255, 255,  11, 255,  12,  13, 255,  /* 0xe8 */
   14,  18,  15, 255,  16,  17, 255,   8,  /* 0xf0 */
  255, 255,  10, 255, 255, 255, 255, 255,  /* 0xf8 */
};

/* THIS IS A GENERATED TABLE, see data/pairtoc.c. */
static const unsigned char *PAIR_KOI8U[] = {

  (unsigned char*)"\xd0\xce\xd3\xda\xc1\xc4\xd1\xd7\xd4\xc2\xcb\xcd\xa6\xc7\xa2\xd2\xd5\xdb\xcc\xe1\xde\xc3\xc8\xd6\xf0\xee\xf3\xe2\xa3\xed\xf7\xeb\xf1\xf5\xe4\xfa\xf4\xe7\xb6\xf2\xe8\xec\xc6\xfb\xc5\xfe\xb3",  /* FILLCHAR */
  (unsigned char*)".\xd3\xce\xcc\xc4\xdb\xd6\xd7\xda\xcb",  /* 0xa2 */
  (unsigned char*)"\xce",  /* 0xb3 */
  (unsigned char*)".",  /* 0xb6 */
  (unsigned char*)".\xce\xcb\xcc\xc3\xd3\xcd\xc8\xa2\xd2\xde\xd1\xd7\xd4\xc4\xda\xdb",  /* 0xa6 */
  (unsigned char*)"\xce.\xca",  /* 0xa3 */
  (unsigned char*)".\xcc",  /* 0xe1 */
  (unsigned char*)"\xc5\xc1",  /* 0xe2 */
  (unsigned char*)"\xcf",  /* 0xf7 */
  (unsigned char*)"\xdc",  /* 0xe7 */
  (unsigned char*)"\xc1",  /* 0xfa */
  (unsigned char*)"\xc1",  /* 0xeb */
  (unsigned char*)"\xc1",  /* 0xed */
  (unsigned char*)"\xc1\xc5",  /* 0xee */
  (unsigned char*)"\xc1\xd2",  /* 0xf0 */
  (unsigned char*)"\xc1",  /* 0xf2 */
  (unsigned char*)"\xc1",  /* 0xf4 */
  (unsigned char*)".",  /* 0xf5 */
  (unsigned char*)".",  /* 0xf1 */
  (unsigned char*)".\xcc\xc4\xd2\xd3\xa2\xce\xcd\xd7\xcb\xc7\xc3\xca\xc2\xda\xd4\xd0\xde\xc5\xd1\xc8\xc0\xdb\xd6\xa3\xc6\xa6",  /* 0xc1 */
  (unsigned char*)"\xd9\xc1\xc5\xcf.\xd2\xd5\xa6\xcc\xd1\xce",  /* 0xc2 */
  (unsigned char*)"\xc1\xd9\xc5\xcf\xa6\xd1\xd5.",  /* 0xd7 */
  (unsigned char*)"\xc1\xcf\xdc.\xcc\xd5\xd2\xa6\xce\xc5",  /* 0xc7 */
  (unsigned char*)"\xc1\xda.\xd9\xce\xd5\xcf\xd2\xcb\xd7\xcc\xd6\xd3\xdc\xde",  /* 0xc4 */
  (unsigned char*)".\xd2\xce\xcc\xc4\xd3\xc3\xca\xa2\xcd\xcb\xd4\xda\xdb\xde\xd7\xd0\xc5\xd6\xc2",  /* 0xc5 */
  (unsigned char*)"\xc1\xd9.\xce\xcf",  /* 0xd6 */
  (unsigned char*)"\xc1.\xc5\xa6\xce\xd1\xd7\xd8\xd5\xc4\xd2\xcd\xc2\xc7\xcc\xd9",  /* 0xda */
  (unsigned char*)".\xce\xdb\xd3",  /* 0xca */
  (unsigned char*)"\xc1.\xa6\xd5\xcf\xd2\xcc\xd4\xd3\xce",  /* 0xcb */
  (unsigned char*)"\xc1\xa6\xd8\xc5\xd1\xcf.\xc0\xd9\xd5\xa3",  /* 0xcc */
  (unsigned char*)".\xc1\xa6\xc5\xcf\xd5\xd1\xd9\xce\xcc",  /* 0xcd */
  (unsigned char*)"\xc1\xc5\xd9\xa6.\xd1\xd5\xce\xcf\xd8\xd4\xd3\xcb\xc3\xc4\xdb\xde",  /* 0xce */
  (unsigned char*)".\xa2\xcc\xc4\xd2\xd7\xce\xd3\xca\xc7\xcd\xd6\xc2\xd4\xcb\xde\xc5\xda\xd0\xdb\xc3\xc8",  /* 0xcf */
  (unsigned char*)"\xc1\xd2\xc5\xcf\xcc\xa6\xd9\xd5.\xd1",  /* 0xd0 */
  (unsigned char*)"\xc1\xd9\xcf\xd5\xdc.\xce\xcb\xd4\xdb\xcd\xc7\xd7\xd3",  /* 0xd2 */
  (unsigned char*)"\xd4\xd1\xcb\xc1\xc3\xd0\xd8.\xd5\xcc\xd7\xa6\xc5\xce\xa3\xcf\xd9\xcd",  /* 0xd3 */
  (unsigned char*)"\xc1\xcf\xd9\xd2\xd5.\xd7\xcb\xdc\xce",  /* 0xd4 */
  (unsigned char*)".\xd3\xc4\xcc\xcd\xd4\xd2\xc0\xcb\xd0\xa2\xc3\xde\xd6\xdb\xce\xc8\xc2\xc7\xda\xd7",  /* 0xd5 */
  (unsigned char*)"\xc1",  /* 0xc6 */
  (unsigned char*)".\xc1\xcf\xd4\xa6\xd5\xce",  /* 0xc8 */
  (unsigned char*)"\xd8\xc1\xd9\xa6\xc3\xc5\xd1.\xcb\xdc",  /* 0xc3 */
  (unsigned char*)"\xc1\xd9\xce\xdc\xd5.\xcf\xcb",  /* 0xde */
  (unsigned char*)"\xd4\xd9\xde\xc1.\xcb\xcc\xdc\xce",  /* 0xdb */
  (unsigned char*)".\xcd\xd1\xcc\xc8\xce\xcb\xc3\xa2\xd3\xd7\xd4\xde\xd2\xca\xd0\xa6\xc2\xc7\xdb\xc4\xda",  /* 0xd9 */
  (unsigned char*)".\xce\xcb\xc3\xcd\xdb\xd7\xd3",  /* 0xd8 */
  (unsigned char*)"\xd4\xce\xd2.\xcc\xca\xc2\xd3",  /* 0xdc */
  (unsigned char*)".\xde\xc3\xc4",  /* 0xc0 */
  (unsigned char*)".\xcb\xce\xc7\xd2\xcc\xc4\xa2\xcd\xc3\xc5\xdb\xd3\xd7\xd4\xc2\xda\xde\xd0\xc8",  /* 0xd1 */
};


/* THIS IS A GENERATED TABLE, see data/totals.pl. */
static const unsigned short int SIGNIFICANT[] = {
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x00 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x08 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x10 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x18 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x20 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x28 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x30 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x38 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x40 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x48 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x50 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x58 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x60 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x68 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x70 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x78 */
    280,     0,     0,     0,   187,     0,     0,     0,  /* 0x80 */
      0,     0,  1491,     0,     0,     0,     0,     0,  /* 0x88 */
      0,     0,     0,     0,     0,     0,     0,     0,  /* 0x90 */
    939,     0,     0,     0,   227,     0,     0,     0,  /* 0x98 */
  12228,   816,  3657,  1133,  2168,  1561,  4495,  1073,  /* 0xa0 */
   1497,   397,  1460,  1606,  1887,  2459,  2387,  1057,  /* 0xa8 */
    137,     0,     0,  1491,  1491,   424,     0,     0,  /* 0xb0 */
    187,     0,     0,     0,     0,   380,     0,     0,  /* 0xb8 */
    591, 11974,  1302,  1792,  2440,  2994,  1400,  1456,  /* 0xc0 */
    848,     0,   760,  2800,  3080,  2222,  4720,  2780,  /* 0xc8 */
   9557,  3439,  5440,  3838,  6270,  3841,  2236,  3195,  /* 0xd0 */
   2219,  4665,  3458,  2430,  1873,  2360,  4083,  2409,  /* 0xd8 */
  15289,  6375,  4912,  5405,  2440,  5204,  2393,  4366,  /* 0xe0 */
    908,  1042,  2800,  7580,  3452,  6101,  3244,  4876,  /* 0xe8 */
   3246,  5164,  2690,  3373,     0,  1293,  3283,  2472,  /* 0xf0 */
    890,     0,     0,  3902,  1204,   762,  1393,  1394,  /* 0xf8 */
};

/* THIS IS A GENERATED VALUE, see data/totals.pl */
#define WEIGHT_SUM 36720

/* THIS IS A GENERATED TABLE, see data/totals.pl */
static const char *const CHARSET_NAMES[] = {
  "cp1251",
  "ibm866",
  "iso88595",
  "koi8uni",
  "maccyr",
  "ibm855",
  "koi8u",
};

/* THIS IS A GENERATED TABLE, see data/totals.pl */
static const unsigned short int *const CHARSET_WEIGHTS[] = {
  RAW_CP1251,
  RAW_IBM866,
  RAW_ISO88595,
  RAW_KOI8UNI,
  RAW_MACCYR,
  RAW_IBM855,
  RAW_KOI8U,
};

/* THIS IS A GENERATED TABLE, see data/totals.pl */
static const unsigned char *const CHARSET_LETTERS[] = {
  LETTER_CP1251,
  LETTER_IBM866,
  LETTER_ISO88595,
  LETTER_KOI8UNI,
  LETTER_MACCYR,
  LETTER_IBM855,
  LETTER_KOI8U,
};

/* THIS IS A GENERATED TABLE, see data/totals.pl */
static const unsigned char **const CHARSET_PAIRS[] = {
  PAIR_CP1251,
  PAIR_IBM866,
  PAIR_ISO88595,
  PAIR_KOI8UNI,
  PAIR_MACCYR,
  PAIR_IBM855,
  PAIR_KOI8U,
};

/* THIS IS A GENERATED VALUE, see data/totals.pl */
#define NCHARSETS 7
