#! /bin/bash
../doit.sh iso88592 cp1250 ibm852 macce iso885913 iso885916 baltic cork
