#! /bin/bash
../doit.sh cp1257 iso88594 ibm775 iso885913 macce baltic
