#! /bin/bash
../doit.sh cp1250 iso88592 ibm852 macce cork
